# Prerequisites
- [ ] The branch build is green, conflicts are resolved, and the code is ready to be merged
- [ ] Ensure that cross-module dependencies do not violate the rules (app <- feature <- shared <- atomic components)
- [ ] Components shared across modules should be promoted to /packages/shared
- [ ] Any functionality changes that affect multiple features is validated and tested to identify and mitigate impacts across the platform
- [ ] Ensure that the only changes on your branch are related to your work -- check commits for git history issues

# UI-specific
- [ ] Core logic is unit tested with a focus on state management and state accessors
- [ ] All of the functionality is usable on a 1080px wide screen
- [ ] All core design system component additions are added to Storybook
- [ ] All display strings are managed in string bundles and have both an English and German entry
- [ ] Light theme & dark themes are both supported to the extent that designs define
- [ ] Typography, elevation, media-query, and other design decisions leverage design tokens (/packages/tokens/*)
- [ ] All styles reference theme files for applying colors, and theme files reference design tokens for color palette definitions
- [ ] All console logging is run through the useLogger() hook to centralize log processing
- [ ] Any authorization-based rendering is implemented according to requirements

# BFF-specific
- [ ] All handlers should have a test event associated with them
- [ ] Validate route naming adheres to convention
- [ ] All defined routes should have a response schema defined in the template
- [ ] Ensure adequate logging in handlers for debugging

# Best practices
- [ ] Check for empty useCallback / etc dependency array that would trigger re-renders
- [ ] Prefer `async / await` to `Promise` chaining.
- [ ] All string keys are managed in constants and referenced as enums for control flow
- [ ] For data that is allowed or expected to return undefined, ensure optional chains are applied to accessors
- [ ] Any copy/paste code duplication should be hoisted into a shared function to keep things DRY and maintainable

# Blocking reviews
- [ ] Any changes to core design system (/packages/components) should be reviewed by Crux
