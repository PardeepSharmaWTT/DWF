import os
import sys
import json
import logging
import base64
import hashlib
import hmac

import boto3

def deleteStacks(branchName):
    
    print('Removing AWS assets for branch: ' + branchName)
    
    niceBranchName = branchName.replace('/', '-')
    
    authStack = niceBranchName + '-auth'
    authSwaggerStack = niceBranchName + '-auth-swagger'
    apiStack = niceBranchName + '-api'
    dbStack = niceBranchName + '-api-db'
    uiS3Stack = niceBranchName + '-ui-s3'
    uiCfStack = niceBranchName + '-ui-cf'
    connStack = niceBranchName + '-conn'
    wsStack = niceBranchName + '-ws'
    openApiStack = niceBranchName + '-openapi'
    servicesApiStack = niceBranchName + '-servicesapi'
    
    client = boto3.client('cloudformation')
    
    response = client.describe_stacks()
    for record in response['Stacks']:
        
        existingStack = record['StackName']
        print('Existing stack ' + existingStack)
        
        if existingStack == authStack or existingStack == authSwaggerStack or existingStack == apiStack or existingStack == dbStack or existingStack == uiS3Stack or existingStack == uiCfStack or existingStack == connStack or existingStack == wsStack or existingStack == openApiStack or existingStack == servicesApiStack:
               
            if existingStack == uiS3Stack:
                s3 = boto3.resource('s3')
                bucket = 'gedwf-' + niceBranchName
                print('Deleting contents of bucket: ' + bucket)
                bucket = s3.Bucket(bucket)
                for obj in bucket.objects.filter():
                    s3.Object(bucket.name, obj.key).delete()

            print('Removing stack: ' + existingStack)
            client.delete_stack(StackName=existingStack)
            print('Stack deleted')

def verifySignature(signature, payload):
    
    secret = os.environ['CLIENT_SECRET'].encode('ascii')
    encodedPayload = payload.encode('ascii')
    
    computed_hash = hmac.new(secret, encodedPayload, hashlib.sha1)
    computed_signature = '='.join(['sha1', computed_hash.hexdigest()])
    
    return hmac.compare_digest(computed_signature.encode('ascii'), signature.encode('ascii'))
    

def call(event, context):
    
#    print("Received event: " + json.dumps(event, indent=2))
    
    githubSignature = event['headers']['X-Hub-Signature']
    payload = event['body']
    
    verified = verifySignature(githubSignature, payload)
    print('Signature verified: {}'.format(verified))
    
    if not verified:
        return {
            'statusCode': 400,
            'body': json.dumps('Bad Request')
        }
        
    branchEvent = event['headers']['X-GitHub-Event']
    
    if branchEvent != 'delete':
        print('Unable to process event: ' + branchEvent)
        return {
            'statusCode': 400,
            'body': json.dumps('Bad Request')
        }
    
    body = json.loads(payload)
    branchName = body['ref']
    
    deleteStacks(branchName)

    return {
        'statusCode': 200,
        'body': json.dumps('Success')
    }