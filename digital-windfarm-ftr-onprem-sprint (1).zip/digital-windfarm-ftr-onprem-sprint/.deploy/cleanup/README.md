# Deployment Cleanup
Because an individual deployment of the DWF consists of a set of CloudFormation stacks, the cleanup requires only the removal of the stacks within CloudFormation with the exception of the UI S3 bucket which much be emptied before deleting the ui-s3 stack.

For example, the CI/CD pipeline should have created the following stacks for a branch named "bug-fixes":
bug-fixes-ui-s3
bug-fixes-api
bug-fixes-api-db
bug-fixes-servicesapi
bug-fixes-openapi
bug-fixes-ws
bug-fixes-auth-swagger
bug-fixes-auth
bug-fixes-conn
bug-fixes-ui-cf

The cleanup job is triggered when the "bug-fixes" branch is deleted and executes the following logic:
1. Remove all contents of the bug-fixes-ui-s3 bucket
2. Delete all stacks associated with "bug-fixes-"

## Cleanup Function
The python cleanup function sits behind a protected API Gateway endpoint and is called by a GitHub Webhook when a branch is deleted.  The following 

The GitHub webhook is created with the following configuration:
* Payload URL: https://asdf1235.execute-api.us-east-1.amazonaws.com/dev/branchdelete
  (The endpoint exposed by API Gateway for the cleanup function)
* Content type: application/json
* Secret: ****
  (Must be the same in the cleanup function)
* Let me select individual events
  'Branch or tag deletion'