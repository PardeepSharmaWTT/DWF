import {
  getROCActionTakenOptions,
  createROCActionLog,
} from '@ge/sam-rtmc-api/src/roc-action-log/handler';
const { getHandler, postHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/rtmc/roc-action-taken-options', getROCActionTakenOptions]];
const postApiArr = [['/rtmc/create-roc-action-log', createROCActionLog]];

export default function (app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);
  postHandler(app, postApiArr);
}
