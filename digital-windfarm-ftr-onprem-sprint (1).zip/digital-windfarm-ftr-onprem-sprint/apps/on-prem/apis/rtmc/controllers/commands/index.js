import {
  postCommands,
  getCommandsList,
  getCommandsStatus,
  getAssetHistory,
  commandSafetyCheck,
  abortCommands,
} from '@ge/sam-rtmc-api/src/commands/handler';

const { getHandler, postHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/rtmc/commands/:id', getCommandsStatus],
  ['/rtmc/commands-asset-history/:siteId', getAssetHistory],
  ['/rtmc/command-safety-check/:siteId', commandSafetyCheck],
  ['/rtmc/commands-abort/:id', abortCommands],
];

const postApiArr = [
  ['/rtmc/commands', postCommands],
  ['/rtmc/commands-list', getCommandsList],
];

export default function (app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);

  ///////////////////////////////////////////
  postHandler(app, postApiArr);
}
