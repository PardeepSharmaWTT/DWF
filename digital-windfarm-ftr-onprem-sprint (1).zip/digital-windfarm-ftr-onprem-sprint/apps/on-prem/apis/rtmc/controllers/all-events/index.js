import { getAssetAllEvents } from '@ge/sam-rtmc-api/src/all-events/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/rtmc/asset/all-events', getAssetAllEvents]];

export default function(app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);
}
