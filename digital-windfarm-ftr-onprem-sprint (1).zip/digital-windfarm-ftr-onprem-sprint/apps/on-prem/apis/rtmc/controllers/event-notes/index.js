import {
  getEventNotes,
  addEventNote,
  editEventNote,
  deleteEventNote,
  escalateCase,
  bulkEscalateCase,
} from '@ge/sam-rtmc-api/src/event-notes/handler';

const {
  getHandler,
  postHandler,
  patchHandler,
  deleteHandler,
} = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/rtmc/event-notes', getEventNotes]];

const postApiArr = [
  ['/rtmc/event-notes', addEventNote],
  ['/rtmc/escalate-case', escalateCase, 'attachment'],
  ['/rtmc/bulk-escalate-case', bulkEscalateCase, 'attachment'],
];

const patchApiArr = [['/rtmc/event-notes/:id', editEventNote]];

const deleteApiArr = [['/rtmc/event-notes/:id', deleteEventNote]];

export default function(app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);

  ///////////////////////////////////////////
  postHandler(app, postApiArr);

  //////////////////////////////////////////
  patchHandler(app, patchApiArr);

  ///////////////////////////////////////////
  deleteHandler(app, deleteApiArr);
}
