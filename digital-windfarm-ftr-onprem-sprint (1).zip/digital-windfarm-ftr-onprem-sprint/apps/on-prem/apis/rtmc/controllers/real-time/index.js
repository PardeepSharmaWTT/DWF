import {
  getRealTimeValuesForWindTurbine,
  getRealTimeEventsForWindTurbine,
  getRealTimeDataForWindTurbine,
  getRealTimeValuesForSite,
  getRealTimeDataForSites,
  getRealTimeDataForSubstation,
  getRealTimeDataForSiteController,
} from '@ge/sam-rtmc-api/src/real-time/handler';

const { getHandler, postHandler } = require('@ge/on-prem/util/rest-handlers');

const apiArr = [
  ['/rtmc/asset/rt-values', getRealTimeValuesForWindTurbine],
  ['/rtmc/asset/rt-events', getRealTimeEventsForWindTurbine],
  ['/rtmc/asset/:id/rt-data', getRealTimeDataForWindTurbine],
  ['/rtmc/site-controller/:id/rt-data', getRealTimeDataForSiteController],
  ['/rtmc/substation/:id/rt-data', getRealTimeDataForSubstation],
  ['/rtmc/sites/rt-data', getRealTimeDataForSites],
];

export default function(app) {
  ///////////////////////////////////////////////////////
  getHandler(app, apiArr);
  postHandler(app, [['/rtmc/sites/:id/rt-values', getRealTimeValuesForSite]]);
}
