import {
  getCaseQueue,
  changeMonitorCasesStatus,
  editMonitorCasesQueue,
  getAssetCases,
  getActiveCaseCount,
} from '@ge/sam-rtmc-api/src/cases/handler';

const { getHandler, patchHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/rtmc/case-queue', getCaseQueue],
  ['/rtmc/asset/:id/cases', getAssetCases],
  ['/rtmc/active-case-count', getActiveCaseCount],
];

const patchApiArr = [
  ['/rtmc/change-cases-status', changeMonitorCasesStatus],
  ['/rtmc/edit-case-queue', editMonitorCasesQueue],
];

export default function (app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);

  ///////////////Patch API////////////////////
  patchHandler(app, patchApiArr);
}
