import { authorize } from "@ge/sam-rtmc-api/src/auth/iac/handler";

const buildReponse = require("@ge/on-prem/util/buildResponse");

// Event object which will be passed to handler function
const eventObj = require("@ge/on-prem/util/eventFormat.json");

module.exports = function (app) {
  let response;
  const callbackFn = (nullObj, respObj) => {
    response = respObj;
  };
  app.get("/rtmc/authorize", async function (req, res) {
    const reqObj = {
      ...eventObj,
      httpMethod: "GET",
      headers: { ...req.headers },
      authorizationToken: req.body.authorizationToken,
    };
    try {
      await authorize(reqObj, undefined, callbackFn);
      buildReponse(res, response);
    } catch (e) {
      response = {};
      buildReponse(res, response);
    }
  });
};
