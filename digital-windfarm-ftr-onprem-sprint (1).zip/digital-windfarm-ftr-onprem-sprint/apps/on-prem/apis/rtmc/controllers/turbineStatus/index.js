import { getTurbineFailedStatus } from '@ge/sam-rtmc-api/src/turbineStatus/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/rtmc/asset/rt-status', getTurbineFailedStatus]];

export default function(app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);
}
