import { getCaseProcForEventByAsset } from '@ge/sam-rtmc-api/src/case-procedures/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/rtmc/events/:assetId/case-procedures', getCaseProcForEventByAsset]];

export default function (app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);
}
