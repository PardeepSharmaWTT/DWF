import { getDistributionList } from '@ge/sam-cmn-api/src/distribution-list/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/cmn/distribution-list', getDistributionList]];

export default function(app) {
  /////////////////////GET routes///////////////////////
  getHandler(app, getApiArr);
}
