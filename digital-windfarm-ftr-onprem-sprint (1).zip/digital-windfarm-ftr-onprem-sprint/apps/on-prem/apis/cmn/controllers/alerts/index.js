import {
  getAlerts,
  postAlert,
  updateAlert,
  getAssetAlerts,
} from '@ge/sam-cmn-api/src/alerts/handler';

const { getHandler, postHandler, patchHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/cmn/monitor/alerts', getAlerts]];

const postApiArr = [
  ['/cmn/monitor/alerts', postAlert, 'attachment'],
  ['/cmn/monitor/asset-alerts', getAssetAlerts],
];

const patchApiArr = [['/cmn/monitor/alerts', updateAlert, 'attachment']];

export default function(app) {
  /////////////////////GET routes///////////////////////
  getHandler(app, getApiArr);

  //////////////////////POST routes////////////////////////
  postHandler(app, postApiArr);

  //////////////////////PATCH routes////////////////////////
  patchHandler(app, patchApiArr);
}
