import { AuthApi } from "@ge/serverless-http";
import { getHeader } from "@ge/serverless-utils/src/serverless-utils";

const { responses } = require("@ge/serverless-utils");

const oidcConfig = {
  baseUrl: process.env.KEYCLOAK_BASE_URL,
  clientId: process.env.KEYCLOAK_CLIENT_ID,
  idpName: process.env.KEYCLOAK_IDP_NAME,
  clientChallenge: process.env.KEYCLOAK_CLIENT_CHALLENGE,
};

export const authorize = AuthApi.authorize;

export const getOidcConfig = async (event) => {
  const origin = getHeader("origin", event.headers);

  const headers = {
    origin,
  };

  // Pass-through a call to the IAC to get the OIDC config data
  // for the user surfing from the specific origin.
  return responses.success(oidcConfig);
};
