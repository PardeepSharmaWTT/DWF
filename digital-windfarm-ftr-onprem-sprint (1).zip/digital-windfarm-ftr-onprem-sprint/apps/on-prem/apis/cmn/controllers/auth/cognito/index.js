import { authorizer } from "@ge/sam-cmn-api/src/auth/cognito/handler";

const buildReponse = require("@ge/on-prem/util/buildResponse");

// Event object which will be passed to handler function
const eventObj = require("@ge/on-prem/util/eventFormat.json");

module.exports = function (app) {
  let response;
  const callbackFn = (nullObj, respObj) => {
    response = respObj;
  };
  app.get("/cmn/authorize", async function (req, res) {
    const reqObj = {
      ...eventObj,
      httpMethod: "GET",
      headers: { ...req.headers },
      authorizationToken: req.body.authorizationToken,
    };

    try {
      await authorizer(reqObj, undefined, callbackFn);
    } catch (e) {
      response = {};
    }
    buildReponse(res, response);
  });
};
