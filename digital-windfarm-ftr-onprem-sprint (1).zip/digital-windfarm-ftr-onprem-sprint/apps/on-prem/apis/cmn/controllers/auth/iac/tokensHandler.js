// const { responses } = require("@ge/serverless-utils");
import { AuthApi } from '@ge/serverless-http';

export const getAccessTokens = AuthApi.getAccessTokens;
