import { getOidcConfig } from '@ge/on-prem/apis/cmn/controllers/auth/iac/handler';
// import { getAccessTokens } from '@ge/on-prem/apis/cmn/controllers/auth/iac/tokensHandler';
import { getAccessTokens } from '@ge/sam-cmn-api/src/auth/iac/tokensHandler';

const buildReponse = require('@ge/on-prem/util/buildResponse');

// Event object which will be passed to handler function
const eventObj = require('@ge/on-prem/util/eventFormat.json');

export default function (app) {
  app.get('/auth/oidc', async function (req, res) {
    const reqObj = {
      ...eventObj,
      httpMethod: 'GET',
      headers: { ...req.headers },
    };

    try {
      const response = await getOidcConfig(reqObj);
      res = buildReponse(res, response);
    } catch {
      response = {};
      buildReponse(res, response);
    }
  });

  app.get('/auth/access-tokens', async function (req, res) {
    const metadata = {
      dav: {
        // 'cases-and-recommendations': {
        //   ALL: ['view'],
        // },
        // 'core-kpis': {
        //   ALL: ['view'],
        // },
        // 'adv-kpis': {
        //   ALL: ['view'],
        // },
        // 'data-explorer': {
        //   ALL: ['edit'],
        // },
        // 'asset-management': {
        //   ALL: ['view'],
        // },
        // analytics: {
        //   ALL: ['view'],
        // },
      },
      rtmc: {
        'fault-handling-procedures': {
          ALL: ['admin'],
        },
        'causal-alarm': {
          ALL: ['edit'],
        },
        'roc-tasks': {
          ALL: ['admin'],
        },
        'rules-engine': {
          ALL: ['admin'],
        },
        cases: {
          ALL: ['admin'],
        },
        alerts: {
          ALL: ['admin'],
        },
        'notification-list': {
          ALL: ['admin'],
        },
        'alarm-management': {
          ALL: ['admin'],
        },
        'real-time-pages': {
          ALL: ['view'],
        },
        'roc-commands': {
          ALL: ['admin'],
        },
      },
      cmn: {
        'asset-management': {
          ALL: ['view'],
        },
        'alarm-management': {
          ALL: ['admin'],
        },
        'notes-and-attachments': {
          ALL: ['admin'],
        },
      },
      mwp: {
        // 'field-tasks': {
        //   ALL: ['create', 'edit'],
        // },
        // 'asset-management': {
        //   ALL: ['view'],
        // },
        // 'work-orders': {
        //   ALL: ['view'],
        // },
        // 'work-plan': {
        //   ALL: ['view'],
        // },
        // 'personnel-management': {
        //   ALL: ['view'],
        // },
      },
    };
    const reqObj = {
      ...eventObj,
      httpMethod: 'GET',
      headers: { ...req.headers },
    };
    let response;
    let newResp = { body: { metadata: {} } };

    try {
      response = await getAccessTokens(reqObj);
      console.log('here', response);
      // newResp.body = JSON.parse(JSON.stringify(response));
      // newResp.body.metaData = JSON.parse(JSON.stringify(metadata));
      console.log('response from auth/access ****', response);
      buildReponse(res, response);
    } catch (e) {
      response = {};
      buildReponse(res, response);
    }
  });
}
