import {
  getNotesAndSpecialInstructions,
  getNotes,
  getSpecialInstructions,
  editNotes,
  editSpecialInstructions,
  addNotes,
  addSpecialInstructions,
  deleteNote,
  getEntitiesNotes,
} from '@ge/sam-cmn-api/src/notes-specialinstructions/handler';

const {
  getHandler,
  postHandler,
  patchHandler,
  deleteHandler,
} = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/cmn/notes-si', getNotesAndSpecialInstructions],
  ['/cmn/notes', getNotes],
  ['/cmn/special-instructions', getSpecialInstructions],
];

const postApiArr = [
  ['/cmn/special-instructions', addSpecialInstructions],
  ['/cmn/entities-notes', getEntitiesNotes],
  ['/cmn/notes', addNotes],
];

const patchApiArr = [
  ['/cmn/special-instructions/:id', editSpecialInstructions],
  ['/cmn/notes/:id', editNotes],
];

const deleteApiArr = [['/cmn/notes/:id', deleteNote]];

export default function (app) {
  /////////////////////GET routes///////////////////////
  getHandler(app, getApiArr);

  //////////////////////POST routes////////////////////////
  postHandler(app, postApiArr);

  //////////////////////PATCH routes////////////////////////
  patchHandler(app, patchApiArr);

  ///////////////////////DELETE Routes////////////////////
  deleteHandler(app, deleteApiArr);
}
