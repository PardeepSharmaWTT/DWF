import { getViewSelectorContents } from '@ge/sam-cmn-api/src/view-selector/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/cmn/view-selector', getViewSelectorContents]];

export default function (app) {
  // /cmn/view-selector GET route getViewSelectorContents
  getHandler(app, getApiArr);
}
