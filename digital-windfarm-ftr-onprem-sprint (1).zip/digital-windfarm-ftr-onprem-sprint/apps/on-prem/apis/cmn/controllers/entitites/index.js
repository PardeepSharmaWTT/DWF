import {
  getWindTurbines,
  getSiteControllers,
  getSubstations,
  getRegions,
  getSites,
  getServiceGroups,
  getSiteById,
  getAssetComponentHierarchy,
  getAssetsDataAssignments,
  getRocStations,
} from '@ge/sam-cmn-api/src/entities/handler';

const { getHandler, postHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/cmn/regions', getRegions],
  ['/cmn/service-groups', getServiceGroups],
  ['/cmn/assets/:assetId/component-hierarchy', getAssetComponentHierarchy],
  ['/cmn/sites/assets-data-assignments', getAssetsDataAssignments],
  ['/cmn/rock-stations', getRocStations],
];

const postApiArr = [
  //["/cmn/assets", getAssets],
  ['/cmn/sites', getSites],
  ['/cmn/sites/:id', getSiteById],
  ['/cmn/assets/wind-turbines', getWindTurbines],
  ['/cmn/sites/wind-turbines/:siteId', getWindTurbines],
  ['/cmn/assets/site-controllers', getSiteControllers],
  ['/cmn/assets/substations', getSubstations],
];

export default function(app) {
  /////////////////////GET routes///////////////////////
  getHandler(app, getApiArr);

  //////////////////////POST routes////////////////////////
  postHandler(app, postApiArr);
}
