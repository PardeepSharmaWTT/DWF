import {
  getAdminUsers,
  updateUser,
  deleteUser,
  getAllTenants,
  getAllRoles,
  getAllPeople,
  createPerson,
  getLookupPerson,
  getAllRolePermissions,
  getAllLimitedRoles,
  getAuditPerson,
} from '@ge/sam-cmn-api/src/admin/handler';

const {
  getHandler,
  postHandler,
  deleteHandler,
  putHandler,
} = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/cmn/admin/users', getAdminUsers],
  ['/cmn/tenants', getAllTenants],
  ['/cmn/roles', getAllRoles],
  ['/cmn/allpeople', getAllPeople],
  ['/cmn/users/record/:searchId', getLookupPerson],
  ['/cmn/role-permissions', getAllRolePermissions],
  ['/cmn/limited-roles', getAllLimitedRoles],
  ['/cmn/users/audit/:username', getAuditPerson],
];

const postApiArr = [['/cmn/allpeople', createPerson]];

const deleteApiArr = [['/cmn/admin/users', deleteUser]];

const putApiArr = [['/cmn/admin/users/:username', updateUser]];

export default function(app) {
  /////////////////////GET routes///////////////////////
  getHandler(app, getApiArr);

  //////////////////////POST routes////////////////////////
  postHandler(app, postApiArr);

  //////////////////////DELETE routes/////////////////////
  deleteHandler(app, deleteApiArr);

  ///////////////////////PUT routes//////////////////////
  putHandler(app, putApiArr);
}
