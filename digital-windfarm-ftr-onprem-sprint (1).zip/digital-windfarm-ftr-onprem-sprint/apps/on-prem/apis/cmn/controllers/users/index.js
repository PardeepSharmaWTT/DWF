const usersHandler = require('@ge/sam-cmn-api/src/users/handler');

const {
  getHandlerWithCallback,
  postHandlerWithCallback,
} = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/cmn/users/prefs', usersHandler.getUsersPrefs],
  ['/cmn/users/view-prefs', usersHandler.getUsersViewPrefs],
];

const postApiArr = [
  ['/cmn/users/prefs', usersHandler.saveUsersPrefs],
  ['/cmn/users/view-prefs', usersHandler.saveUsersViewPrefs],
];

export default function (app) {
  ///////////////////GET routes///////////////////////
  getHandlerWithCallback(app, getApiArr);

  ///////////////////////////////POST routes/////////////////
  postHandlerWithCallback(app, postApiArr);
}
