const { getSiteContact, putSiteContact, postSiteContact } = require('@ge/sam-cmn-api/src/site-contact/handler');

const {
  getHandler,
  postHandler,
  putHandler,
} = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/cmn/site-contact', getSiteContact],
];

const postApiArr = [
  ['/cmn/site-contact', postSiteContact]
]

const putApiArr = [
  ['/cmn/site-contact/:siteId', putSiteContact]
]

export default function (app) {
  ///////////////////GET routes///////////////////////
  getHandler(app, getApiArr);

  /////////////////POST routes///////////////////////
  postHandler(app,postApiArr);

  /////////////////PUT routes///////////////////////
  putHandler(app, putApiArr);
}
