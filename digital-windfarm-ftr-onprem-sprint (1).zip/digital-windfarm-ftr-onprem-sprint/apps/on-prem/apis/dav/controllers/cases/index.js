import { getCases } from '@ge/sam-dav-api/src/cases/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/dav/cases', getCases]];

export default function (app) {
  // /dav/cases GET route getCases
  getHandler(app, getApiArr);
}
