import {
  getRealTimeValuesForWindTurbine,
  getRealTimeEventsForWindTurbine,
  getRealTimeDataForWindTurbine,
  getRealTimeValuesForSite,
  getRealTimeDataForSites,
  getRealTimeDataForSubstation,
  getRealTimeDataForSiteController,
} from '@ge/sam-rtmc-api/src/real-time/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const apiArr = [
  ['/dav/asset/rt-values', getRealTimeValuesForWindTurbine],
  ['/dav/asset/rt-events', getRealTimeEventsForWindTurbine],
  ['/dav/asset/:id/rt-data', getRealTimeDataForWindTurbine],
  ['/dav/site-controller/:id/rt-data', getRealTimeDataForSiteController],
  ['/dav/substation/:id/rt-data', getRealTimeDataForSubstation],
  ['/dav/sites/:id/rt-values', getRealTimeValuesForSite],
  ['/dav/sites/rt-data', getRealTimeDataForSites],
];

export default function (app) {
  ///////////////////////////////////////////////////////
  getHandler(app, apiArr);
}
