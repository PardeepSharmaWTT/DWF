// import {
//   getRegionIecCategory,
//   getRegionKpiData,
//   getLowestPerformingRegions,
//   getRegionOverview,
//   getRegionSystemLoss,
// } from '@ge/sam-dav-api/src/regions/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  // ['/dav/regions/:id/iec', getRegionIecCategory],
  // ['/dav/regions/:id/region-kpi-data', getRegionKpiData],
  // ['/dav/regions/lowest-performing', getLowestPerformingRegions],
  // ['/dav/regions/:id/overview', getRegionOverview],
  // ['/dav/regions/:id/system-loss', getRegionSystemLoss],
];
export default function (app) {
  /////////////////////////////////////////////////////////
  getHandler(app, getApiArr);
}
