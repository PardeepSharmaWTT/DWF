import {
  getAssetCards,
  getAssetKpiDataBySite,
  getAssetPowerCurve,
  getAssetDataExplorer,
  getAssetMetricChart,
  getAssetSignalData,
  getAssetsSignalData,
} from '@ge/sam-dav-api/src/assets/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  ['/dav/assets/asset-cards', getAssetCards],
  ['/dav/sites/:id/assets/site-kpi-data', getAssetKpiDataBySite],
  ['/dav/assets/:id/power-curve', getAssetPowerCurve],
  ['/dav/data-explorer/assets/overview', getAssetDataExplorer],
  ['/dav/assets/:id/metrics/:metric/chart', getAssetMetricChart],
  ['/dav/assets/:id/signal-data', getAssetSignalData],
  ['/dav/assets/signal-data', getAssetsSignalData],
];

export default function (app) {
  /////////////////GET routes/////////////////////
  getHandler(app, getApiArr);
}
