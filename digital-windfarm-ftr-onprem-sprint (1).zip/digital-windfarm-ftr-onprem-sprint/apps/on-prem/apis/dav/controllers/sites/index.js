// import {
//   getSiteById,
//   getSiteIecCategory,
//   getSiteCards,
//   getSiteKpiData,
//   getSiteKpiDataByRegion,
//   getSitePowerCurveByAsset,
//   getConditionAggregates,
//   getSiteSystemLoss,
//   getSiteOverview,
//   getSiteMetricChart,
// } from '@ge/sam-dav-api/src/sites/handler';

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [
  // ['/dav/sites/:id/search', getSiteById],
  // ['/dav/sites/:id/iec', getSiteIecCategory],
  // ['/dav/sites/site-cards', getSiteCards],
  // ['/dav/sites/:id/site-kpi-data', getSiteKpiData],
  // ['/dav/regions/:id/sites/region-kpi-data', getSiteKpiDataByRegion],
  // ['/dav/sites/:id/asset-power-curve', getSitePowerCurveByAsset],
  // ['/dav/sites/:id/condition-aggregates', getConditionAggregates],
  // ['/dav/sites/:id/system-loss', getSiteSystemLoss],
  // ['/dav/sites/:id/overview', getSiteOverview],
  // ['/dav/sites/:id/metrics/:metric/chart', getSiteMetricChart],
];

export default function (app) {
  /////////////////////////////////////
  getHandler(app, getApiArr);
}
