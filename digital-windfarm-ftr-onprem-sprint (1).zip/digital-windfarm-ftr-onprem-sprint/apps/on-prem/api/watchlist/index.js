const { getWatchlist } = require('@ge/sam-api/src/watchlist/handler');

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/watchlist', getWatchlist]];
export default function (app) {
  getHandler(app, getApiArr);
}
