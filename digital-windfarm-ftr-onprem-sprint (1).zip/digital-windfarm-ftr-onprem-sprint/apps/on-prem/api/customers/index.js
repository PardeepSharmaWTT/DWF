const { getCustomers } = require('@ge/sam-api/src/customers/handler');

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/customers', getCustomers]];

export default function (app) {
  getHandler(app, getApiArr);
}
