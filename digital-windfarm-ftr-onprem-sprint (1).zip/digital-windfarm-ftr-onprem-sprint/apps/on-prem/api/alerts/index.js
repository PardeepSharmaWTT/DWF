const { getAlerts } = require('@ge/sam-api/src/alerts/handler');

const { getHandler } = require('@ge/on-prem/util/rest-handlers');

const getApiArr = [['/alerts', getAlerts]];

export default function (app) {
  getHandler(app, getApiArr);
}
