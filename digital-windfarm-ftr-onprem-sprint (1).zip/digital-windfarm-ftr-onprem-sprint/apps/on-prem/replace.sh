cp ./util/mongo-utils.js ../serverless/utils/src/
sed -i "s/.\/dynamo-utils/.\/mongo-utils/g" ../serverless/utils/src/index.js
sed -i "s/.\/dynamo-utils/.\/mongo-utils/g" ../serverless/utils/src/user-db-utils.js