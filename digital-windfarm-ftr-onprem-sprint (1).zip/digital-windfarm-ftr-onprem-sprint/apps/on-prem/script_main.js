import {} from 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jsonBodyParser from 'body-parser';
import compression from 'compression';

//sam-api controllers
import alertsController from '@ge/on-prem/api/alerts';
import customersController from '@ge/on-prem/api/customers';
import watchListController from '@ge/on-prem/api/watchlist';

// cmn api controllers
import entitiesController from '@ge/on-prem/apis/cmn/controllers/entitites';
import usersController from '@ge/on-prem/apis/cmn/controllers/users';
import viewSelectorController from '@ge/on-prem/apis/cmn/controllers/view-selector';
import monitorAlersController from '@ge/on-prem/apis/cmn/controllers/alerts';
import monitorNotesController from '@ge/on-prem/apis/cmn/controllers/notes-specialinstructions';
import siteContactController from '@ge/on-prem/apis/cmn/controllers/site-contact';
import distributionListController from '@ge/on-prem/apis/cmn/controllers/distribution-list';
// const cmnCognitoController = require("@ge/on-prem/apis/cmn/controllers/auth/cognito");
// const cmnIacController = require("@ge/on-prem/apis/cmn/controllers/auth/iac");
import cmnIacController from '@ge/on-prem/apis/cmn/controllers/auth/iac';
import cmnAdminController from '@ge/on-prem/apis/cmn/controllers/admin';
// dav api controllers
import assetsController from '@ge/on-prem/apis/dav/controllers/assets';
import davCasesController from '@ge/on-prem/apis/dav/controllers/cases';
import regionsController from '@ge/on-prem/apis/dav/controllers/regions';
import sitesController from '@ge/on-prem/apis/dav/controllers/sites';
// const davIacController = require("@ge/on-prem/apis/dav/controllers/auth/iac");
// rtmc api controllers
import rtmcCasesController from '@ge/on-prem/apis/rtmc/controllers/cases';
import rtmcCommandsController from '@ge/on-prem/apis/rtmc/controllers/commands';
import realTimeDataController from '@ge/on-prem/apis/rtmc/controllers/real-time';
import rtmcRocActionLogController from '@ge/on-prem/apis/rtmc/controllers/roc-action-log';
import rtmcEventNotesController from '@ge/on-prem/apis/rtmc/controllers/event-notes';
import caseProceduresController from '@ge/on-prem/apis/rtmc/controllers/case-procedures';
// const rtmcIacController = require("@ge/on-prem/apis/rtmc/controllers/auth/iac");
import rtmcAllEvents from '@ge/on-prem/apis/rtmc/controllers/all-events';
import rtmcTurbineStatus from '@ge/on-prem/apis/rtmc/controllers/turbineStatus';

const app = express();
const PORT = process.env.PORT || 9000;
//Enabling cors
app.use(cors());
app.use(compression());
// parse application/json
app.use(jsonBodyParser.json());

//Attach controllers on the server
alertsController(app);
customersController(app);
watchListController(app);
// Attaching controllers for sam-cmn-api
cmnIacController(app);
entitiesController(app);
usersController(app);
viewSelectorController(app);
monitorAlersController(app);
monitorNotesController(app);
cmnAdminController(app);
siteContactController(app);
distributionListController(app);
// cmnCognitoController(app);
// cmnIacController(app);
// Attaching controllers for sam-dav-api
assetsController(app);
davCasesController(app);
regionsController(app);
sitesController(app);
// davIacController(app);
// Attaching controllers for sam-rtmc-api
rtmcCasesController(app);
rtmcCommandsController(app);
realTimeDataController(app);
rtmcRocActionLogController(app);
rtmcEventNotesController(app);
caseProceduresController(app);
// rtmcIacController(app);
rtmcAllEvents(app);
rtmcTurbineStatus(app);

//console.log("All the routes here!!!");
const routesArray = [];
app._router.stack.forEach(function(r) {
  if (r.route && r.route.path) {
    //   console.log(r.route.path);
    routesArray.push(r.route.path);
  }
});

//console.log(routesArray);

import YAML from 'yaml';
import fs from 'fs';
var store_cmn_routes = [],
  store_dav_routes = [],
  store_rtmc_routes = [];
// var chars = {'!':' ','{':':','}':''};

try {
  var data, str;
  const file = fs.readFileSync('../serverless/apis/cmn/template.yaml', 'utf8'); // reading a yaml file
  str = file.replace(/!/g, ' '); // removing " ! " from file
  data = YAML.parse(str);

  function getPaths(data, store_cmn_routes) {
    // This entire function is used for getting "Path"
    if ('Path' in data) store_cmn_routes.push(data['Path']);
    for (const key in data) {
      if (typeof data[key] === 'object') getPaths(data[key], store_cmn_routes);
    }
  }

  getPaths(data, store_cmn_routes);
  //console.log("routes from cmn Yaml file");
  //console.log(store_cmn_routes);
} catch (e) {
  console.log(e);
}

try {
  const file = fs.readFileSync('../serverless/apis/dav/template.yaml', 'utf8');
  str = file.replace(/!/g, ' ');
  data = YAML.parse(str);

  function getPaths(data, store_dav_routes) {
    if ('Path' in data) store_dav_routes.push(data['Path']);
    for (const key in data) {
      if (typeof data[key] === 'object') getPaths(data[key], store_dav_routes);
    }
  }

  // var store_dav_routes=[];
  getPaths(data, store_dav_routes);
  //console.log("routes from dav Yaml file");
  //console.log(store_dav_routes);
} catch (e) {
  console.log(e);
}

try {
  var data, str;
  const file = fs.readFileSync('../serverless/apis/rtmc/template.yaml', 'utf8');
  str = file.replace(/!/g, ' ');
  data = YAML.parse(str);

  function getPaths(data, store_rtmc_routes) {
    if ('Path' in data) store_rtmc_routes.push(data['Path']);
    for (const key in data) {
      if (typeof data[key] === 'object') getPaths(data[key], store_rtmc_routes);
    }
  }

  // var store_rtmc_routes=[];
  getPaths(data, store_rtmc_routes);
  //console.log("routes from rtmc Yaml file");
  //console.log(store_rtmc_routes);
} catch (e) {
  console.log(e);
}

var newStuff1 = store_cmn_routes.map((item) => item.replace(/{/g, ':').replace(/}/g, ''));
var newStuff2 = store_dav_routes.map((item) => item.replace(/{/g, ':').replace(/}/g, ''));
var newStuff3 = store_rtmc_routes.map((item) => item.replace(/{/g, ':').replace(/}/g, ''));

// var difference = routesArray.filter(x => newStuff.indexOf(x) === -1);
// console.log(difference);

var diff_cmn_routes = [],
  duff_dav_routes = [],
  diff_rtmc_routes = [];
console.log('These routes are not yet implemented taken from cmn');
diff_cmn_routes = newStuff1.filter((x) => routesArray.indexOf(x) === -1);
console.log(diff_cmn_routes);

console.log('These routes are not yet implemented taken from dav');
duff_dav_routes = newStuff2.filter((x) => routesArray.indexOf(x) === -1);
console.log(duff_dav_routes);

console.log('These routes are not yet implemented taken from rtmc');
diff_rtmc_routes = newStuff3.filter((x) => routesArray.indexOf(x) === -1);
console.log(diff_rtmc_routes);

console.log('SUMMARY');
console.log('Number of routes in express  ' + routesArray.length);
console.log(
  'Number of routes in yaml  ' +
    (store_cmn_routes.length + store_dav_routes.length + store_rtmc_routes.length),
);
console.log('Number of routes which differ in cmn yaml  ' + diff_cmn_routes.length);
console.log('Number of routes which differ in dav yaml  ' + duff_dav_routes.length);
console.log('Number of routes which differ in rtmc yaml ' + diff_rtmc_routes.length);
