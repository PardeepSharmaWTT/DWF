require = require("esm")(module);
module.exports = require("./script_main.js");
