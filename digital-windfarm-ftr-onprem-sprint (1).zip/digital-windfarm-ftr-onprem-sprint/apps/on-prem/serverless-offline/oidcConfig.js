const oidcConfig = {
  baseUrl: 'http://3.72.208.192:8080/auth',
  clientId: 'ge-ren-foundation',
  idpName: 'ldap',
  clientChallenge: '399f1a08-574b-4500-9e9f-59b47e9f6339',
};

module.exports.getOidcConfig = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(oidcConfig),
  };
};
