const fs = require("fs");
const routes = require("./allRoutes.json");

let text;

function miniGrep(string, patternToSearch) {
  var regexPatternToSearch = new RegExp(
    "^.*(" + patternToSearch + ").*$",
    "mg"
  );
  match = string.match(regexPatternToSearch);
  return match;
}

const yamlFileArr = [
  "../../serverless/apis/cmn/template.yaml",
  "../../serverless/apis/dav/template.yaml",
  "../../serverless/apis/rtmc/template.yaml",
];

let allRoutes = [];

yamlFileArr.forEach((fileEl) => {
  fs.readFile(fileEl, (err, data) => {
    if (err) throw err;
    text = data.toString();
    const pathArr = miniGrep(text, " Path").map((el) => {
      return el.split(" ")[13];
    });
    allRoutes = [...allRoutes, ...pathArr];
    // console.log(pathArr.length);
  });
});

// const compArr = JSON.parse(routes);
routes.forEach((element) => {
  console.log(element);
});
// console.log(routes);
