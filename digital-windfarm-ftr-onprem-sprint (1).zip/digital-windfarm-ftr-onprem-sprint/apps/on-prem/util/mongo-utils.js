const MongoClient = require("mongodb").MongoClient;
const DB_NAME = "DWF-Web-Client";
let dbo;
const client = new MongoClient(process.env.MONGO_DB_URL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Establish connection with mongoDB
const connectDB = () => {
  client.connect(async function (err) {
    try {
      if (err) throw err;
      dbo = client.db(DB_NAME);
      const collections = await dbo.listCollections().toArray();
      const exist = collections.find(
        (elem) => elem.name === process.env.USERS_TABLE_NAME
      );
      if (exist) return;
      dbo.createCollection(process.env.USERS_TABLE_NAME, function (err, res) {
        if (err) throw err;
        console.log("DB Users collection created");
      });
    } catch (err) {
      console.log("Error Happend while connecting to DB! ", err.message);
    }
  });
};

connectDB();

//Helper function for making mongoDB compatible params
function getMongoParamsFromDynamoParams(params) {
  const mongoParams = {};
  mongoParams.collectionName = params.TableName;

  //Execute only if Item param is there
  if (params.Item) mongoParams.item = params.Item;

  //Execute only if key param is there
  if (params.Key) mongoParams.filter = params.Key;

  //Execute if block only if updateExpression is there
  if (params.UpdateExpression) {
    const updateExprArr = params.UpdateExpression.split(", ").map((elem) => {
      const subArr = [];
      const tokens = elem.split(" ");
      if (tokens.length === 4) {
        subArr.push(tokens[1]);
        subArr.push(tokens[3]);
      } else {
        subArr.push(tokens[0]);
        subArr.push(tokens[2]);
      }
      return subArr;
    });

    const attrNames = Object.keys(params.ExpressionAttributeNames);
    attrNames.forEach((elem) => {
      updateExprArr
        .find((e) => {
          return e[0] === elem;
        })
        .push(params.ExpressionAttributeNames[elem]);
    });

    const update = {};
    const updateKeys = Object.keys(params.ExpressionAttributeValues);
    updateKeys.forEach((elem) => {
      const val = updateExprArr.find((el) => {
        return el[1] === elem;
      })[2];

      update[val] = params.ExpressionAttributeValues[elem];
    });
    mongoParams.update = update;
  }

  //Execute this block obly if KeyConitionExpression param is there
  if (params.KeyConditionExpression) {
    const keyParam = {};
    const [key, _, keyAttr] = params.KeyConditionExpression.split(" ");
    keyParam[key] = params.ExpressionAttributeValues[keyAttr];
    mongoParams.filter = keyParam;
  }

  // execute only if projection param is there
  if (params.ProjectionExpression) {
    const projection = {};
    const projectionKeys = params.ProjectionExpression.split(", ");
    projectionKeys.forEach((elem) => {
      projection[elem] = 1;
    });

    mongoParams.projection = projection;
  }

  return mongoParams;
}

// query Method
module.exports.query = async (params) => {
  if (!dbo) connectDB();
  const { collectionName, filter } = getMongoParamsFromDynamoParams(params);
  return await dbo.collection(collectionName).find(filter);
};

// getItem method
module.exports.getItem = async (params) => {
  if (!dbo) connectDB();
  const { collectionName, filter } = getMongoParamsFromDynamoParams(params);
  return await dbo.collection(collectionName).findOne(filter);
};
// saveItem method
module.exports.saveItem = (params) => {
  if (!dbo) connectDB();
  const { collectionName, item } = getMongoParamsFromDynamoParams(params);
  return dbo.collection(collectionName).insertOne(item);
};

// updateItem method
module.exports.updateItem = (params) => {
  if (!dbo) connectDB();
  const { collectionName, filter, update } =
    getMongoParamsFromDynamoParams(params);
  console.log(typeof collectionName);
  return dbo
    .collection(collectionName)
    .updateOne(filter, { $set: update }, { upsert: true });
};

// batchWrite method
module.exports.batchWrite = (params) => {
  if (!dbo) connectDB();
  return dbo.collection(params.TableName).insertMany(params.Items);
};

// batchGet method
module.exports.batchGet = (params) => {
  if (!dbo) connectDB();
  dbo.collection(params.TableName).find(params.Keys).toArray();
};

// deleteItem method
module.exports.deleteItem = (params) => {
  if (!dbo) connectDB();
  const { collectionName, filter } = getMongoParamsFromDynamoParams(params);
  return dbo.collection(collectionName).deleteOne(filter);
};
