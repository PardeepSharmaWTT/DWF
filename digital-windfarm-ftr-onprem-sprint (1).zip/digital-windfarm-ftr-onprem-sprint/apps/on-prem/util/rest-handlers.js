const buildReponse = require('@ge/on-prem/util/buildResponse');
const eventObj = require('@ge/on-prem/util/eventFormat.json');
const multer = require('multer');
const upload = multer();

const expressReqToLambdaEvent = (req) => {
  const event = {
    ...eventObj,
    httpMethod: req.method,
    headers: { ...req.headers },
    pathParameters: { ...req.params },
    queryStringParameters: { ...req.query },
  };

  console.log('Method', req.method);

  if (req.method !== 'GET') {
    event.body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    if (req.files) {
      const body = JSON.parse(event.body);
      body.files = typeof req.files === 'string' ? JSON.parse(req.files) : req.files;
      event.body = JSON.stringify(body);
    }
  }

  return event;
};

const getHandler = async (app, getApiArr) => {
  /////////////////////GET routes///////////////////////
  getApiArr.forEach((apiElement) => {
    app.get(apiElement[0], async function(req, res) {
      const reqObj = expressReqToLambdaEvent(req);
      let response = {};
      try {
        response = await apiElement[1](reqObj);
        res = buildReponse(res, response);
      } catch (err) {
        console.log('Some Error Happened!', err.message);
        response = {};
        res = buildReponse(res, response);
      }
    });
  });
};

const getHandlerWithCallback = async (app, getApiArr) => {
  /////////////////////GET routes///////////////////////
  getApiArr.forEach((apiElement) => {
    app.get(apiElement[0], async function(req, res) {
      const reqObj = expressReqToLambdaEvent(req);
      let response = {};
      try {
        const callbackFn = (_, Obj) => {
          response = Obj;
          res = buildReponse(res, response);
        };
        response = await apiElement[1](reqObj, undefined, callbackFn);
      } catch (err) {
        console.log('Some Error Happened!', err.message);
        response = {};
        res = buildReponse(res, response);
      }
    });
  });
};

const postHandlerWithCallback = async (app, postApiArr) => {
  postApiArr.forEach((apiElement) => {
    app.post(apiElement[0], async function(req, res) {
      const reqObj = expressReqToLambdaEvent(req);
      let response = {};
      try {
        const callbackFn = (_, Obj) => {
          response = Obj;
          res = buildReponse(res, response);
        };
        await apiElement[1](reqObj, undefined, callbackFn);
      } catch (err) {
        console.log('Some Error Happened!', err.message);
        response = {};
        res = buildReponse(res, response);
      }
    });
  });
};

const postHandler = async (app, postApiArr) => {
  postApiArr.forEach((apiElement) => {
    app.post(
      apiElement[0],
      apiElement[2] ? upload.array(apiElement[2]) : upload.none(),
      async function(req, res) {
        const reqObj = expressReqToLambdaEvent(req);
        let response = {};
        try {
          response = await apiElement[1](reqObj);
          res = buildReponse(res, response);
        } catch (err) {
          console.log('Some Error Happened!', err.message);
          response = {};
          res = buildReponse(res, response);
        }
      },
    );
  });
};

const patchHandler = async (app, patchApiArr) => {
  //////////////////////PATCH routes////////////////////////
  patchApiArr.forEach((apiElement) => {
    app.patch(
      apiElement[0],
      apiElement[2] ? upload.array(apiElement[2]) : upload.none(),
      async function(req, res) {
        const reqObj = expressReqToLambdaEvent(req);
        let response = {};
        try {
          response = await apiElement[1](reqObj);
          res = buildReponse(res, response);
        } catch (err) {
          console.log('Some Error Happened!', err.message);
          response = {};
          res = buildReponse(res, response);
        }
      },
    );
  });
};

const putHandler = async (app, putApiArr) => {
  //////////////////////PUT routes////////////////////////
  putApiArr.forEach((apiElement) => {
    app.put(apiElement[0], async function(req, res) {
      const reqObj = expressReqToLambdaEvent(req);
      let response = {};
      try {
        response = await apiElement[1](reqObj);
        res = buildReponse(res, response);
      } catch (err) {
        console.log('Some Error Happened!', err.message);
        response = {};
        res = buildReponse(res, response);
      }
    });
  });
};

const deleteHandler = async (app, deleteApiArr) => {
  //////////////////////DELETE routes////////////////////////
  deleteApiArr.forEach((apiElement) => {
    app.delete(apiElement[0], async function(req, res) {
      const reqObj = expressReqToLambdaEvent(req);
      let response = {};
      try {
        response = await apiElement[1](reqObj);
        res = buildReponse(res, response);
      } catch (err) {
        console.log('Some Error Happened!', err.message);
        response = {};
        res = buildReponse(res, response);
      }
    });
  });
};

module.exports = {
  getHandler,
  getHandlerWithCallback,
  postHandler,
  postHandlerWithCallback,
  patchHandler,
  deleteHandler,
  putHandler,
};
