module.exports = function (expressRes, handlerRes) {
  if (typeof handlerRes === "function") {
    handlerRes = handlerRes();
    expressRes.status(handlerRes.statusCode);
    expressRes.json(handlerRes.body);
    return expressRes;
  }
  if (handlerRes === undefined || handlerRes.body === undefined) {
    expressRes.status(502);
    expressRes.json({ message: "Internal server error" });
    return expressRes;
  }

  expressRes.status(handlerRes.statusCode || 200);
  expressRes.type("application/json");
  expressRes.set(handlerRes.headers || "");
  expressRes.send(handlerRes.body);
  return expressRes;
};
