# Steps required to run BFF on-prem

1. run yarn install from root dir of project
2. run yarn generate:mocks from root dir of project
3. run yarn replacedb from apps/on-prem
4. run yarn install from apps/on-prem
5. run yarn start from apps/on-prem

# Steps to build the project

1. If the project has never been run just follow the above steps after than just run yarn build from apps/on-prem
2. your build code will be inside apps/on-prem/dist
