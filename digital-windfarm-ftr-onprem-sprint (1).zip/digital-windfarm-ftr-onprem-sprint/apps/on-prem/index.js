import {} from 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jsonBodyParser from 'body-parser';
import compression from 'compression';

//sam-api controllers
import alertsController from '@ge/on-prem/api/alerts';
import customersController from '@ge/on-prem/api/customers';
import watchListController from '@ge/on-prem/api/watchlist';

// cmn api controllers
import entitiesController from '@ge/on-prem/apis/cmn/controllers/entitites';
import usersController from '@ge/on-prem/apis/cmn/controllers/users';
import viewSelectorController from '@ge/on-prem/apis/cmn/controllers/view-selector';
import monitorAlersController from '@ge/on-prem/apis/cmn/controllers/alerts';
import monitorNotesController from '@ge/on-prem/apis/cmn/controllers/notes-specialinstructions';
import siteContactController from '@ge/on-prem/apis/cmn/controllers/site-contact';
import distributionListController from '@ge/on-prem/apis/cmn/controllers/distribution-list';
// const cmnCognitoController = require("@ge/on-prem/apis/cmn/controllers/auth/cognito");
// const cmnIacController = require("@ge/on-prem/apis/cmn/controllers/auth/iac");
import cmnIacController from '@ge/on-prem/apis/cmn/controllers/auth/iac';
import cmnAdminController from '@ge/on-prem/apis/cmn/controllers/admin';
// dav api controllers
import assetsController from '@ge/on-prem/apis/dav/controllers/assets';
import davCasesController from '@ge/on-prem/apis/dav/controllers/cases';
import regionsController from '@ge/on-prem/apis/dav/controllers/regions';
import sitesController from '@ge/on-prem/apis/dav/controllers/sites';
// const davIacController = require("@ge/on-prem/apis/dav/controllers/auth/iac");
// rtmc api controllers
import rtmcCasesController from '@ge/on-prem/apis/rtmc/controllers/cases';
import rtmcCommandsController from '@ge/on-prem/apis/rtmc/controllers/commands';
import realTimeDataController from '@ge/on-prem/apis/rtmc/controllers/real-time';
import rtmcRocActionLogController from '@ge/on-prem/apis/rtmc/controllers/roc-action-log';
import rtmcEventNotesController from '@ge/on-prem/apis/rtmc/controllers/event-notes';
import caseProceduresController from '@ge/on-prem/apis/rtmc/controllers/case-procedures';
// const rtmcIacController = require("@ge/on-prem/apis/rtmc/controllers/auth/iac");
import rtmcAllEvents from '@ge/on-prem/apis/rtmc/controllers/all-events';
import rtmcTurbineStatus from '@ge/on-prem/apis/rtmc/controllers/turbineStatus';

const app = express();
const PORT = process.env.PORT || 9000;
//Enabling cors
app.use(cors());
app.use(compression());
// parse application/json
app.use(jsonBodyParser.json());

//Attach controllers on the server
alertsController(app);
customersController(app);
watchListController(app);
// Attaching controllers for sam-cmn-api
cmnIacController(app);
entitiesController(app);
usersController(app);
viewSelectorController(app);
monitorAlersController(app);
monitorNotesController(app);
cmnAdminController(app);
siteContactController(app);
distributionListController(app);
// cmnCognitoController(app);
// cmnIacController(app);
// Attaching controllers for sam-dav-api
assetsController(app);
davCasesController(app);
regionsController(app);
sitesController(app);
// davIacController(app);
// Attaching controllers for sam-rtmc-api
rtmcCasesController(app);
rtmcCommandsController(app);
realTimeDataController(app);
rtmcRocActionLogController(app);
rtmcEventNotesController(app);
caseProceduresController(app);
// rtmcIacController(app);
rtmcAllEvents(app);
rtmcTurbineStatus(app);

app.get('/test', async function(req, res) {
  // console.log(res);
  res.send('Test..........');
});

//Start server on the port number from environment variable
app.listen(PORT, () => {
  console.log(`✔ Started Listening on Port: ${PORT} 🖥...`);
});
