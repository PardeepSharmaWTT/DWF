const path = require('path');
const npm_package = require('./package.json');
// const nodeExternals = require('webpack-node-externals');
// const Dotenv = require('dotenv-webpack');

console.log(__dirname);

module.exports = {
  entry: './index.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'onprembff.build.js',
  },
  node: {
    __dirname: false,
    __filename: false,
  },
  plugins: [
    // new Dotenv({
    //   allowEmptyValues: true, // allow empty variables (e.g. `FOO=`) (treat it as empty string, rather than missing)
    //   systemvars: true, // load all the predefined 'process.env' variables which will trump anything local per dotenv specs.
    // }),
  ],
  target: 'node',
  externalsPresets: { node: true },
  externals: [
    // nodeExternals(),
    // nodeExternals({
    //   modulesDir: path.resolve(__dirname, '../../node_modules'),
    // }),
  ],
  mode: 'development',
  resolve: {
    extensions: ['.js', '.json'],
    alias: npm_package._moduleAliasesBuild,
    modules: ['node_modules'],
  },
};
