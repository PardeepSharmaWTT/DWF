const { views } = require('@ge/mocks/dist/entities/views');
const { buildResponse, intercept, noMocksInterceptor } = require('@ge/serverless-utils');

exports.getViews = intercept([noMocksInterceptor], async () => {
  const viewsResponse = {
    views,
  };

  return buildResponse(200, viewsResponse);
});
