import { views } from '@ge/mocks/dist/entities/views';
import { buildResponse, EnvVar } from '@ge/serverless-utils';

import { getViews } from './handler';

const mockJwt =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJjb2duaXRvOmdyb3VwcyI6W119.PvuRLMwacbS7n3iCizBkavgyLV6KsKiMf6uqKZeaIkM';

const mockEvent = {
  headers: {
    Authorization: mockJwt,
  },
};

const mockResponse = buildResponse(200, { views });

describe('Views', () => {
  describe('handler', () => {
    it('should return mock views', async () => {
      jest.spyOn(EnvVar, 'noMockData', 'get').mockReturnValue(false);

      expect(await getViews(mockEvent));
    });
  });
});
