import { AuthApi } from '@ge/serverless-http';

export const authorize = AuthApi.authorize;