const { regions } = require('@ge/mocks/dist/entities/regions');
const { buildResponse, intercept, noMocksInterceptor } = require('@ge/serverless-utils');

export const getRegions = intercept([noMocksInterceptor], async (event) => {
  const regionsResponse = {
    regions,
  };

  return buildResponse(200, regionsResponse);
});
