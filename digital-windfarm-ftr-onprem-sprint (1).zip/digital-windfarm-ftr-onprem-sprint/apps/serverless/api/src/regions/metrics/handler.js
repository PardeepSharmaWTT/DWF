const { metrics, toDayjs, QueryParams } = require('@ge/metrics');
const { responses } = require('@ge/serverless-utils');

export const getRegionAssetMetrics = (event) => {
  const { id: regionId } = event.pathParameters;
  const { interval, measure, start, end } = event.queryStringParameters;

  if (!measure) {
    return responses.error('Measure param is required.');
  }
  if (end && !start) {
    return responses.error('Cannot specify end time without start time.');
  }

  const params = new QueryParams(measure)
    .withField(measure)
    .withStart(toDayjs(start))
    .withEnd(toDayjs(end))
    .withAggregation(interval);

  return metrics.region
    .getRegionAssetMeasurement(regionId, params)
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
};

export const getRegionSiteMetrics = (event) => {
  const { id: regionId } = event.pathParameters;
  const { interval, measure, start, end } = event.queryStringParameters;

  if (!measure) {
    return responses.error('Measure param is required.');
  }
  if (end && !start) {
    return responses.error('Cannot specify end time without start time.');
  }

  const params = new QueryParams(measure)
    .withField(measure)
    .withStart(toDayjs(start))
    .withEnd(toDayjs(end))
    .withAggregation(interval);

  return metrics.region
    .getRegionSiteMeasurement(regionId, params)
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
};

export const getRegionMetrics = (event) => {
  const { id: regionId } = event.pathParameters;
  const { interval, measure, start, end } = event.queryStringParameters;

  if (!measure) {
    return responses.error('Measure param is required.');
  }
  if (end && !start) {
    return responses.error('Cannot specify end time without start time.');
  }

  const params = new QueryParams(measure)
    .withField(measure)
    .withStart(toDayjs(start))
    .withEnd(toDayjs(end))
    .withAggregation(interval);

  return metrics.region
    .getRegionMeasurement(regionId, params)
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
};
