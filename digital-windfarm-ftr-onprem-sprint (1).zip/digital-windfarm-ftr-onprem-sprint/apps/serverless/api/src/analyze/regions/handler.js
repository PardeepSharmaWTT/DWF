const { analyze } = require('@ge/mocks-logic');
const { intercept, noMocksInterceptor, responses } = require('@ge/serverless-utils');

export const getRegionIecCategory = intercept([noMocksInterceptor], (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { category },
  } = event;
  console.debug(`Getting IEC category ${category} for Region ${id}`);

  return Promise.resolve(analyze.getRegionIecCategory(id, category))
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});

export const getRegionKpiData = intercept([noMocksInterceptor], (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { categories },
  } = event;
  const categoryArray = categories.split(',');
  console.debug(`Getting Region KPI data (${categoryArray.join(', ')}) for Region ${id}`);

  return Promise.resolve(analyze.getRegionKpiData(id, categoryArray))
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});
