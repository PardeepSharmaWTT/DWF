const { analyze } = require('@ge/mocks-logic');
const { intercept, noMocksInterceptor, responses } = require('@ge/serverless-utils');

export const getAssetCards = intercept([noMocksInterceptor], async () => {
  try {
    console.debug('Getting all asset KPI cards');

    const response = analyze.getAssetKpiCards();

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getAssetKpiDataBySite = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
      queryStringParameters: { categories = [] },
    } = event;
    const categoryArray = categories.split(',');

    console.debug(`Getting Asset KPI data ${categoryArray.join(', ')} for Site ${id}`);

    const response = analyze.getAssetKpiBySite(id, categoryArray);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getAssetPowerCurve = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
    } = event;

    console.debug(`Getting power curve for asset ${id}`);

    const response = analyze.getAssetPowerCurve(id);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
