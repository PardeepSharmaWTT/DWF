const {
  buildResponse,
  getSitesFilter,
  intercept,
  noMocksInterceptor,
} = require('@ge/serverless-utils');
const mockAssets = require('@ge/mocks/dist/entities/assets').assets;
const mockEvents = require('@ge/mocks/dist/entities/events').events;
const mockTickets = require('@ge/mocks/dist/entities/tickets').tickets;

exports.getAsset = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;

  const mockAsset = mockAssets.find((asset) => id === asset.id);

  return buildResponse(200, { asset: mockAsset });
});

exports.getAssetEvents = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;

  const assetEvents = mockEvents.filter((e) => e.asset.id === id);

  const eventsResponse = {
    events: assetEvents,
  };

  return buildResponse(200, eventsResponse);
});

exports.getAssets = intercept([noMocksInterceptor], async (event) => {
  const sitesToFilterOn = await getSitesFilter(event);
  let assets;

  if (sitesToFilterOn.length === 0) {
    assets = mockAssets.slice(0, 100);
  } else {
    assets = mockAssets.filter((asset) => sitesToFilterOn.includes(asset.site.id)).slice(0, 100);
  }

  // Build the response object from the mock array
  const assetsResponse = {
    assets,
  };

  return buildResponse(200, assetsResponse);
});

exports.getTicketsByAsset = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;

  const assetTickets = mockTickets.filter((ticket) => ticket.asset.id === id);

  const ticketsResponse = {
    tickets: assetTickets,
  };

  return buildResponse(200, ticketsResponse);
});
