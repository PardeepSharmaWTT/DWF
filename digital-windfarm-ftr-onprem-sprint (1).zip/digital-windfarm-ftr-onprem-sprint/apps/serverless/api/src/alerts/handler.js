const { alerts } = require('@ge/mocks/dist/entities/alerts');
const { intercept, noMocksInterceptor, responses } = require('@ge/serverless-utils');

exports.getAlerts = intercept([noMocksInterceptor], async () => {
  try {
    // Build the response object from the mock array
    const response = {
      alerts,
    };

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
