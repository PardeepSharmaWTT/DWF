const { watchlist } = require('@ge/mocks/dist/entities/watchlist');
const { buildResponse, intercept, noMocksInterceptor } = require('@ge/serverless-utils');

exports.getWatchlist = intercept([noMocksInterceptor], async () => {
  // Build the response object from the mock array
  const watchlistResponse = {
    watchlist,
  };

  return buildResponse(200, watchlistResponse);
});
