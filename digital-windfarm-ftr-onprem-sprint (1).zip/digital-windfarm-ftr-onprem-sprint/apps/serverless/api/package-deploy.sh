#!/usr/bin/env bash

USER_POOL_ID=$(grep REACT_APP_COGNITO_USER_POOL_ID ../../web-client/.env | cut -d '=' -f2)
if [ -z "$USER_POOL_ID" ]; then { echo "Unable to locate USER_POOL_ID" 1>&2 ; exit 1; }; fi

#SERVICESAPI_URL='TODO-backend_.env'
SERVICESAPI_URL='https://zm571rxas3.execute-api.us-east-1.amazonaws.com/prod'

BRANCH_NICE=$(git rev-parse --abbrev-ref HEAD | tr '\/' '-')
STACK_NAME=$BRANCH_NICE-api
DEPLOY_BUCKET='renewables-uai3031357-dwf-ui-dev'

sam package \
  --output-template-file packaged.yaml \
  --s3-bucket $DEPLOY_BUCKET

sam deploy \
  --template-file packaged.yaml \
  --capabilities CAPABILITY_IAM \
  --s3-bucket $DEPLOY_BUCKET \
  --stack-name "$STACK_NAME" \
  --no-fail-on-empty-changeset \
  --parameter-overrides ParameterKey=UserPoolId,ParameterValue=$USER_POOL_ID ParameterKey=ServicesApiUrl,ParameterValue=$SERVICESAPI_URL
