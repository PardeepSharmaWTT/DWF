export const MockFailTurbineStatusCollections = {
    "assetState": [
        {
            "tenantId": "geservdrZp",
            "assetId": "32150011",
            "siteId": "5000415",
            "refreshts": 1649730947,
            "currentState": {
                "ieccode": 1,
                "ts": 1649678150,
                "quality": 3,
                "loggedTs": 1649679769
            },
            "metaData": {}
        },
        {
            "tenantId": "geservdrZp",
            "assetId": "32150041",
            "siteId": "5000415",
            "refreshts": 1649730947,
            "currentState": {
                "ieccode": 9,
                "ts": 1649678150,
                "quality": 3,
                "loggedTs": 1649679769
            },
            "metaData": {
                "Algorithm": "Fault Code"
            }
        }
    ],
    "siteMappingNotFound": [],
    "assetMappingNotFound": []
}