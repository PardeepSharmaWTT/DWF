// got sample data as an array, is this how it really comes across for single crew?
export const MockCrew = {
	_id: '1234567890',
	active: true,
	apply_on: [
		'FRIDAY'
	],
	deleted: true,
	end: '2022-04-18T16:20:04.506Z',
	last_updated_by: {
		date: '2022-04-18T16:20:04.506Z',
		name: 'mock_user'
	},
	members: [{
		created_by: 'mock_user',
		last_updated_by: {
			date: '2022-04-18T16:20:04.506Z',
			name: 'mock_user'
		},
		lead: true,
		member_id: '201234567',
		time_periods: [{
			end: '2022-04-18T16:20:04.506Z',
			start: '2022-04-18T16:20:04.506Z'
		}]
	}],
	name: 'mock_crew',
	service_group: 'mocks',
	shift_duration: {
		end: '2022-04-18T16:20:04.506Z',
		start: '2022-04-18T16:20:04.506Z'
	},
	start: '2022-04-18T16:20:04.506Z',
	tenant_id: 'dfsa',
	turbines: [{
		planned_date: '2022-04-18T16:20:04.506Z',
		tasks: [
			'623fd89e27bdf62db9c0bb17'
		],
		turbine_id: 'MO41'
	}]
};
