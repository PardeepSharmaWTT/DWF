export const MockErpRequestInProgress = {
  siteGroupSourceKey: 'GE_ONW_Colorado_Highlands_8412',
  taskId: '1671678',
  erpCurrentStatus: 'IN_PROGRESS',                                     
  erpBodyStatus: 'RECEIVED',                                                   
  errorDetails: [],                                                
  erpMetadata: {
      owner: '503191835',                                          
      ownerName: 'Rupert the Owl',                                     
      assetSerialNumber: '17131196',                               
      tag: 'GE_ONW_Colorado_Highlands_8412 | WP2_1',               
      srType: 'FSA - Non PM',
      srProblemSummary: 'M3: Gearbox, Yaw, HPU',
      severity: 'Standard',
      scadaFaultCode: '1',
      srProblemCode: 'ANEMWIND',
      pacNumber: '',
      majorCompSupplier: 'ABB',
      majorCompSN: '123',
      description: 'test',
      quoteNumber: '',
      laborDetails: [
          {
              rowNumber: 1,
              labortype: 'Repair',
              quantity: 2,
              serviceActivity: 'Labor'                             
          },
          {
              rowNumber: 2,
              labortype: 'Troubleshoot',
              quantity: 11,
              serviceActivity: 'Labor'
          }
      ],
     techAssignments: ['503190670', '503190671' ],
     assignedTechEmailIds: [ 'sivnagkumar.dayal@ge.com', 'sankaranand.ms@ge.com'  ],
     scheduledDate: [                                              
          '2020',
          '10',
          '28',
          '00',
          '00',
          '00',
          '000'
      ],
      partDetails: [
          {
              rowNumber: 1,
              partNumber: '104W4388P001',
              partName: 'P1',
              partQuantity: 1,
              serviceActivity: 'COI',
              replenish: true,
              ecoTurbineType: 'N',                        
              priority: 'DOWN TURBINE',
              // Exists only if SR Parts Order Update is received from RACES
              orderNumber: '',
              orderStatus: '',
              soLineCreationStatus:'SUCCESS',                   // Can be SUCCESS / ERROR / FAILURE
              soLineErrorCode:'',
              needByDate: '13-Apr-2022',
              addressType: 'A',
              shippingAddress: 'Default',
              alternateAddress: 'Chicago',
              phoneNumber: '8939724270',
              instructions: 'Deliver to Jimmy'
          },
      ],
      // Exists only if SR Status Update is received from RACES
      statusId: '100',
      status: 'Approved Estimates',
      statusCode: 'SR_APPROVED_ESTIMATES',
      timeStamp: '',                                            // timestamp received in Sr Status inbound call from RACES
      statusUpdatedOn: '',                                      // timestamp when the Status is updated in ERP
      // Exists only if SR Body Update is received from RACES
      chargesCreation: 'YES',                                   // Can be YES / NO / PARTIAL
      laborHrsCreation: 'SUCCESS',                              // Can be SUCCESS / FAILURE
      laborHrsErrordetails: '',                                 // Error message in English       
      techAssignmentCreation: 'YES',                            // Can be YES / NO / PARTIAL
      techErrorDetails: '',                                     // Error message in English
      // Exists only if SR Parts Response is received from RACES  
        orderCreation: 'YES',                            // Can be SUCCESS / FAILURE
       orderCreationErrorDetails: '',                           // Error message in English
      scheduledDateCreation: 'SUCCESS',                         // Can be SUCCESS / FAILURE
      scheduledDateErrorDetails: ''                             // Error message in English
  }
};