const placeholderValues = [
  { LOREM_IPSUM: 'Lorem ipsum' },
  { DOLOR_SIT_AMET: 'dolor sit amet' },
  { CONSECTETUR_ADIPISCING_ELIT: 'consectetur adipiscing elit' },
];

export const MockErpCollections = [
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'ASSET_DESCRIPTION_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'DIAG_ALARM_CODE_LIST',
    parentName: 'TOOLBOX_HARDWARE_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'LEAD_LIST_API',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'LOCATION_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'MAJOR_COMPONENT_SUPPLIER_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'OEM_FAULT_CODE_LIST',
    parentName: 'OEM_PLATFORM_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'OEM_PLATFORM_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'PROBLEM_CODE_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'SCADA_FAULT_CODE_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'SERVICE_ACTIVITY_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'SEVERITY_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'SHIPPING_PRIORITY',
    parentName: 'SR_TYPE_LIST',
    dependOn: ['WARRANTY', 'TI_RETRO'],
    values: [
      { MAINTENANCE: 'MAINTENANCE_CODE' },
      { DOWN_TURBINE: 'DOWN_TURBINE_CODE' },
      { SERVICE_PROGRAM: 'SERVICE_PROGRAM_CODE' },
      { STD_PRIORITY: 'STD_PRIORITY_CODE' },
      { UPTOWER: 'UPTOWER_CODE' },
    ],
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'SR_TYPE_LIST',
    parentName: null,
    dependOn: [],
    values: [
      { FSA_MCE: 'FSA_MCE_CODE' },
      { OM_MCE: 'OM_MCE_CODE' },
      { WARRANTY_MCE: 'WARRANTY_MCE_CODE' },
      { DEPOT_REPAIR: 'DEPOT_REPAIR_CODE' },
      { ENG_SUPPORT: 'ENG_SUPPORT_CODE' },
      { FSA_NON_PM: 'FSA_NON_PM_CODE' },
      { INTERNAL_SA_COST: 'INTERNAL_SA_COST_CODE' },
      { OM_NON_PM: 'OM_NON_PM_CODE' },
      { PROJECT_NEW_UNITS: 'PROJECT_NEW_UNITS_CODE' },
      { RECLAIM: 'RECLAIM_CODE' },
      { FSA_PM: 'FSA_PM_CODE' },
      { OM_PM: 'OM_PM_CODE' },
      { WARRANTY: 'WARRANTY_CODE' },
      { CM_U: 'CM_U_CODE' },
      { CUSTOMER_REQUEST: 'CUSTOMER_REQUEST_CODE' },
      { TI_RETRO: 'TI_RETRO_CODE' },
    ],
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'SUB_TYPE_LIST',
    parentName: 'WORK_TYPE_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'TOOLBOX_HARDWARE_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'WORK_TYPE_LIST',
    values: placeholderValues,
  },
  {
    tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
    name: 'YES_NO_LIST',
    values: [
      { YES: 'YES' },
      { NO: 'NO' },
    ],
  },
];