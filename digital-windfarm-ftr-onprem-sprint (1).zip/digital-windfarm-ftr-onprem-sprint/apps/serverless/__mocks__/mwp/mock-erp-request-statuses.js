/*
known statuses from confluence doc and spreadsheet:

erpStatus: SR_CREATION_INP, WO_CREATION_INP, SR_OPEN, SR_CLAIM_SUBMITTED, SR_APPROVED_ESTIMATES, SR_REJECTED_ESTIMATES, SR_REQUEST_INFORMATION, SR_COMPLETED, WO_CREATED, SR_CREATION_FAILED, WO_CREATION_FAILED
chargesStatus: SR_CHARGES_INP, SR_CHARGES_FAILED
techAssignmentsStatus: SR_TECH_ASSIGNMENT_INP, SR_TECH_ASSIGNMENT_FAILED
partsOrderStatus: SR_ORDER_INP, SR_ORDER_FAILED, SR_PARTIAL_ORDER_FAILED
*/

export const MockErpRequestStatuses = [
  // service request statuses
  {
    "taskId": "1234567890",
    "erpNumber": "55600988",
    "erpStatus": "SR_CREATION_INP",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": "",
        "consolidatedSubStatus": ""
    }
  },
  {
    "taskId": "1234567891",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": "SR_ORDER_INP",
        "consolidatedSubStatus": "SR_ORDER_INP"
    }
  },
  {
      "taskId": "1234567892",
      "erpNumber": "55600988",
      "erpStatus": "SR_OPEN",
      "erpSubStatus": {
          "chargesStatus": "",
          "techAssignmentsStatus": "",
          "partsOrderStatus": "",
          "consolidatedSubStatus": ""
      }
  },
  {
    "taskId": "1234567893",
    "erpNumber": "55600988",
    "erpStatus": "SR_CREATION_FAILED",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": "",
        "consolidatedSubStatus": ""
    }
  },
  {
    "taskId": "1234567894",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_FAILED",
        "partsOrderStatus": "",
        "consolidatedSubStatus": "SR_TECH_ASSIGNMENT_FAILED"
    }
  },
  {
    "taskId": "1234567895",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "SR_CHARGES_FAILED",
        "techAssignmentsStatus": "",
        "partsOrderStatus": "",
        "consolidatedSubStatus": "SR_CHARGES_FAILED"
    }
  },
  {
    "taskId": "1234567896",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": "SR_ORDER_FAILED",
        "consolidatedSubStatus": "SR_ORDER_FAILED"
    }
  },
  {
    "taskId": "1234567897",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": "SR_PARTIAL_ORDER_FAILED",
        "consolidatedSubStatus": "SR_PARTIAL_ORDER_FAILED"
    }
  },
  {
    "taskId": "1234567898",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "SR_CHARGES_FAILED",
        "techAssignmentsStatus": "",
        "partsOrderStatus": "SR_ORDER_FAILED",
        "consolidatedSubStatus": "SR_CHARGES_ORDER_FAILED"
    }
  },
  {
    "taskId": "1234567899",
    "erpNumber": "55600988",
    "erpStatus": "SR_CLAIM_SUBMITTED",
    "erpSubStatus": {
      "chargesStatus": "",
      "techAssignmentsStatus": "",
      "partsOrderStatus": "",
      "consolidatedSubStatus": ""
    }
  },
  {
    "taskId": "1234567900",
    "erpNumber": "55600988",
    "erpStatus": "SR_APPROVED_ESTIMATES",
    "erpSubStatus": {
      "chargesStatus": "",
      "techAssignmentsStatus": "",
      "partsOrderStatus": "",
      "consolidatedSubStatus": ""
    }
  },
  {
    "taskId": "1234567901",
    "erpNumber": "55600988",
    "erpStatus": "SR_REJECTED_ESTIMATES",
    "erpSubStatus": {
      "chargesStatus": "",
      "techAssignmentsStatus": "",
      "partsOrderStatus": "",
      "consolidatedSubStatus": ""
    }
  },
  {
    "taskId": "1234567902",
    "erpNumber": "55600988",
    "erpStatus": "SR_REQUEST_INFORMATION",
    "erpSubStatus": {
      "chargesStatus": "",
      "techAssignmentsStatus": "",
      "partsOrderStatus": "",
      "consolidatedSubStatus": ""
    }
  },
  {
    "taskId": "1234567903",
    "erpNumber": "55600988",
    "erpStatus": "SR_COMPLETED",
    "erpSubStatus": {
      "chargesStatus": "",
      "techAssignmentsStatus": "",
      "partsOrderStatus": "",
      "consolidatedSubStatus": ""
    }
  },
  {
    "taskId": "1234567904",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "SR_CHARGES_INP",
        "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_INP",
        "partsOrderStatus": "",
        "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_INP"
    }
  },
  {
    "taskId": "1234567905",
    "erpNumber": "55600988",
    "erpStatus": "SR_CLAIM_SUBMITTED",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_INP",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_INP",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_INP"
    }
  },
  {
    "taskId": "1234567906",
    "erpNumber": "55600988",
    "erpStatus": "SR_APPROVED_ESTIMATES",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_INP",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_INP",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_INP"
    }
  },
  {
    "taskId": "1234567907",
    "erpNumber": "55600988",
    "erpStatus": "SR_REJECTED_ESTIMATES",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_INP",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_INP",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_INP"
    }
  },
  {
    "taskId": "1234567908",
    "erpNumber": "55600988",
    "erpStatus": "SR_REQUEST_INFORMATION",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_INP",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_INP",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_INP"
    }
  },
  {
    "taskId": "1234567909",
    "erpNumber": "55600988",
    "erpStatus": "SR_COMPLETED",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_INP",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_INP",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_INP"
    }
  },
  {
    "taskId": "1234567910",
    "erpNumber": "55600988",
    "erpStatus": "SR_OPEN",
    "erpSubStatus": {
        "chargesStatus": "SR_CHARGES_FAILED",
        "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_FAILED",
        "partsOrderStatus": "",
        "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_FAILED"
    }
  },
  {
    "taskId": "1234567911",
    "erpNumber": "55600988",
    "erpStatus": "SR_CLAIM_SUBMITTED",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_FAILED",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_FAILED",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_FAILED"
    }
  },
  {
    "taskId": "1234567912",
    "erpNumber": "55600988",
    "erpStatus": "SR_APPROVED_ESTIMATES",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_FAILED",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_FAILED",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_FAILED"
    }
  },
  {
    "taskId": "1234567913",
    "erpNumber": "55600988",
    "erpStatus": "SR_REJECTED_ESTIMATES",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_FAILED",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_FAILED",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_FAILED"
    }
  },
  {
    "taskId": "1234567914",
    "erpNumber": "55600988",
    "erpStatus": "SR_REQUEST_INFORMATION",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_FAILED",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_FAILED",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_FAILED"
    }
  },
  {
    "taskId": "1234567915",
    "erpNumber": "55600988",
    "erpStatus": "SR_COMPLETED",
    "erpSubStatus": {
      "chargesStatus": "SR_CHARGES_FAILED",
      "techAssignmentsStatus": "SR_TECH_ASSIGNMENT_FAILED",
      "partsOrderStatus": "",
      "consolidatedSubStatus": "SR_CHARGES_TECH_ASSIGNMENT_FAILED"
    }
  },
  // work order statuses
  {
    "taskId": "1234567916",
    "erpNumber": "1671689",
    "erpStatus": "WO_CREATION_INP",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": ""
    }
  },
  {
    "taskId": "1234567917",
    "erpNumber": "1671690",
    "erpStatus": "WO_CREATED",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": ""
    }
  },
  {
    "taskId": "1234567918",
    "erpNumber": "1671691",
    "erpStatus": "WO_CREATION_FAILED",
    "erpSubStatus": {
        "chargesStatus": "",
        "techAssignmentsStatus": "",
        "partsOrderStatus": ""
    }
  },
];
