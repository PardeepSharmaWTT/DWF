import getPresignedUrlInput from './GetPresignedUrl.json';
import sitesNamesInput from './GetSitesNames.json';
import patchMetadataInput from './PatchMetadata.json';
import postJobInput from './PostJob.json';
import postMetadataInput from './PostMetadata.json';
import updateManufacturerInput from './UpdateManufacturerByJobId.json';

export {
  sitesNamesInput,
  postJobInput,
  postMetadataInput,
  patchMetadataInput,
  getPresignedUrlInput,
  updateManufacturerInput,
};
