import getAllDamagesInput from './GetAllDamages.json';
import getDamageDetailsInput from './GetDamageDetails.json';

export { getAllDamagesInput, getDamageDetailsInput };
