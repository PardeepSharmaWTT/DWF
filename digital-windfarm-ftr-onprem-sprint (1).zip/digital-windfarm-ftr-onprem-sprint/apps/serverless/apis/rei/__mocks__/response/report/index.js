import completeReport from './completeReport.json';
import reportById from './reportByJobId.json';
import reportBySiteid from './reportBySiteId.json';
import reportStage from './reportStageInfo.json';
import updateReport from './updateReport.json';

export { reportStage, reportById, updateReport, completeReport, reportBySiteid };
