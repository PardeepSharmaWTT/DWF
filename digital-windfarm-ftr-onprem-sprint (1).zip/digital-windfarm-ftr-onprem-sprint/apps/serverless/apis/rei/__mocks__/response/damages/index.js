import allDamages from './getAllDamages.json';
import damageDetails from './getDamageDetails.json';

export { allDamages, damageDetails };
