import annotations from './getAnnotations.json';
import damageTreeDetails from './getDamageTreeDetails.json';
import image from './getImage.json';
import images from './getImages.json';
import videos from './getVideos.json';
import updatAnnotationRes from './updateAnnotation.json';
import updateImageRes from './updateImage.json';
import updateVideoRes from './updateVideo.json';

export {
  annotations,
  image,
  images,
  videos,
  damageTreeDetails,
  updatAnnotationRes,
  updateImageRes,
  updateVideoRes,
};
