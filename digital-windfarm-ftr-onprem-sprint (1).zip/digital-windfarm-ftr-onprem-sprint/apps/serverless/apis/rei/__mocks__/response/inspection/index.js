import allJobs from './allJobs.json';
import createJobExecution from './createJobExecution.json';
import deleteSucess from './deleteSucess.json';
import executionJsonSucess from './executionInfo.json';
import executionStageInfoError from './executionStageInfoError.json';
import getJobById from './jobById.json';
import getPostProcessStageInfo from './postProcessStageInfo.json';
import uploadJson from './uploadInfo.json';
import uploadJsonError from './uploadInfoError.json';

export {
  executionJsonSucess,
  executionStageInfoError,
  uploadJson,
  uploadJsonError,
  getPostProcessStageInfo,
  getJobById,
  allJobs,
  deleteSucess,
  createJobExecution,
};
