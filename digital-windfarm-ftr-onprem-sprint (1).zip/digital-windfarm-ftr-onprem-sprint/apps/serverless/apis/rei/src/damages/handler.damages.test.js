import * as damagesApi from '@ge/serverless-http/src/rendigital/rei/damages-api';
import { buildResponse } from '@ge/serverless-utils';

import * as mockRequest from '../../__mocks__/request/damages';
import * as mockResponse from '../../__mocks__/response/damages';

import * as damagesFn from './handler';

const mockFailureRes = {
  config: {},
  message: 'GE Service Error: Request failed with status code 500',
};

describe('Damages', () => {
  describe('handler', () => {
    it('getAllDamages Success', async () => {
      jest.spyOn(damagesApi, 'getDamages').mockImplementation(() => mockResponse.allDamages);
      expect(await damagesFn.getDamages(mockRequest.getAllDamagesInput)).toEqual(
        buildResponse(200, mockResponse.allDamages),
      );
    });

    it('getAllDamages Failure', async () => {
      jest.spyOn(damagesApi, 'getDamages').mockRejectedValue(mockFailureRes);
      expect(await damagesFn.getDamages(mockRequest.getAllDamagesInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('getDamageDetails Success', async () => {
      jest
        .spyOn(damagesApi, 'getDamageDetails')
        .mockImplementation(() => mockResponse.damageDetails);
      expect(await damagesFn.getDamageDetails(mockRequest.getDamageDetailsInput)).toEqual(
        buildResponse(200, mockResponse.damageDetails),
      );
    });

    it('getDamageDetails Failure', async () => {
      jest.spyOn(damagesApi, 'getDamageDetails').mockRejectedValue(mockFailureRes);
      expect(await damagesFn.getDamageDetails(mockRequest.getDamageDetailsInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });
});
