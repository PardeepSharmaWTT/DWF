import * as postProcessApi from '@ge/serverless-http/src/rendigital/rei/post-processing-api';
import { buildResponse } from '@ge/serverless-utils';

import * as mockRequest from '../../__mocks__/request/post-processing';
import * as mockResponse from '../../__mocks__/response/post-processing';

import * as postProcessfn from './handler';

const mockFailureRes = {
  config: {},
  message: 'GE Service Error: Request failed with status code 500',
};

describe('PostProcess', () => {
  describe('handler', () => {
    it('getAnnotations Success', async () => {
      jest
        .spyOn(postProcessApi, 'getAnnotations')
        .mockImplementation(() => mockResponse.annotations);
      expect(await postProcessfn.getAnnotations(mockRequest.getAnnotationsInput)).toEqual(
        buildResponse(200, mockResponse.annotations),
      );
    });

    it('getAnnotations Failure', async () => {
      jest.spyOn(postProcessApi, 'getAnnotations').mockRejectedValue(mockFailureRes);
      expect(await postProcessfn.getAnnotations(mockRequest.getAnnotationsInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('getImage Success', async () => {
      jest.spyOn(postProcessApi, 'getImage').mockImplementation(() => mockResponse.image);
      expect(await postProcessfn.getImage(mockRequest.getImageInput)).toEqual(
        buildResponse(200, mockResponse.image),
      );
    });

    it('getImage Failure', async () => {
      jest.spyOn(postProcessApi, 'getImage').mockRejectedValue(mockFailureRes);
      expect(await postProcessfn.getImage(mockRequest.getImageInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('getImages Success', async () => {
      jest.spyOn(postProcessApi, 'getImages').mockImplementation(() => mockResponse.images);
      expect(await postProcessfn.getImages(mockRequest.getImagesInput)).toEqual(
        buildResponse(200, mockResponse.images),
      );
    });

    it('getImages Failure', async () => {
      jest.spyOn(postProcessApi, 'getImages').mockRejectedValue(mockFailureRes);
      expect(await postProcessfn.getImages(mockRequest.getImagesInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('getVideos Success', async () => {
      jest.spyOn(postProcessApi, 'getVideos').mockImplementation(() => mockResponse.images);
      expect(await postProcessfn.getVideos(mockRequest.getVideosInput)).toEqual(
        buildResponse(200, mockResponse.images),
      );
    });

    it('getVideos Failure', async () => {
      jest.spyOn(postProcessApi, 'getVideos').mockRejectedValue(mockFailureRes);
      expect(await postProcessfn.getVideos(mockRequest.getVideosInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('getDamageTreeDetails Success', async () => {
      jest
        .spyOn(postProcessApi, 'getDamageTreeDetails')
        .mockImplementation(() => mockResponse.damageTreeDetails);
      expect(
        await postProcessfn.getDamageTreeDetails(mockRequest.getDamageTreeDetailsInput),
      ).toEqual(buildResponse(200, mockResponse.damageTreeDetails));
    });

    it('getDamageTreeDetails Failure', async () => {
      jest.spyOn(postProcessApi, 'getDamageTreeDetails').mockRejectedValue(mockFailureRes);
      expect(
        await postProcessfn.getDamageTreeDetails(mockRequest.getDamageTreeDetailsInput),
      ).toEqual(buildResponse(500, mockFailureRes));
    });

    it('updateAnnotation Success', async () => {
      jest
        .spyOn(postProcessApi, 'updateAnnotation')
        .mockImplementation(() => mockResponse.updatAnnotationRes);
      expect(await postProcessfn.updateAnnotation(mockRequest.updateAnnotationInput)).toEqual(
        buildResponse(200, mockResponse.updatAnnotationRes),
      );
    });

    it('updateAnnotation Failure', async () => {
      jest.spyOn(postProcessApi, 'updateAnnotation').mockRejectedValue(mockFailureRes);
      expect(await postProcessfn.updateAnnotation(mockRequest.updateAnnotationInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('updateImage Success', async () => {
      jest
        .spyOn(postProcessApi, 'updateImage')
        .mockImplementation(() => mockResponse.updateImageRes);
      expect(await postProcessfn.updateImage(mockRequest.updateImageInput)).toEqual(
        buildResponse(200, mockResponse.updateImageRes),
      );
    });

    it('updateImage Failure', async () => {
      jest.spyOn(postProcessApi, 'updateImage').mockRejectedValue(mockFailureRes);
      expect(await postProcessfn.updateImage(mockRequest.updateImageInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('updateVideo Success', async () => {
      jest
        .spyOn(postProcessApi, 'updateVideo')
        .mockImplementation(() => mockResponse.updateVideoRes);
      expect(await postProcessfn.updateVideo(mockRequest.updateVideoInput)).toEqual(
        buildResponse(200, mockResponse.updateVideoRes),
      );
    });

    it('updateVideo Failure', async () => {
      jest.spyOn(postProcessApi, 'updateVideo').mockRejectedValue(mockFailureRes);
      expect(await postProcessfn.updateVideo(mockRequest.updateVideoInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });
});
