import { InspectionsApi } from '@ge/serverless-http';
import { bodyParserInterceptor, buildAuthHeader, intercept, responses } from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';

export const getAnnotations = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { objId },
    } = event;
    requireNotEmpty({ objId });
    console.log(`Getting Annoations for the job ID ${objId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getAnnotations(objId, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getImage = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { imageId },
    } = event;
    requireNotEmpty({ imageId });
    console.log(`Getting Image for the image ID ${imageId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getImage(imageId, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getImages = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { jobId },
    } = event;
    requireNotEmpty({ jobId });
    console.log(`Getting Images with job ID ${jobId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getImages(jobId, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getVideos = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { jobId },
    } = event;
    requireNotEmpty({ jobId });
    console.log(`Getting videos with job ID ${jobId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getVideos(jobId, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getDamageTreeDetails = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { inspectionType },
    } = event;
    requireNotEmpty({ inspectionType });
    console.log(`Getting DamageTree detail based on inspection type ${inspectionType}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getDamageTreeDetails(inspectionType, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const updateAnnotation = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { flagNew },
      body: data,
    } = event;

    const body = data;
    requireNotEmpty({ flagNew, body });
    console.log(`Updating Annotation with the data ${body}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.updateAnnotation(flagNew, body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const updateImage = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { flagNew },
      body: data,
    } = event;

    const body = data;
    requireNotEmpty({ flagNew, body });
    console.log(`Updating image with the data ${body}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.updateImage(flagNew, body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const updateVideo = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { flagNew },
      body: data,
    } = event;

    const body = data;
    requireNotEmpty({ flagNew, body });
    console.log(`Updating video with the data ${body}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.updateVideo(flagNew, body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
