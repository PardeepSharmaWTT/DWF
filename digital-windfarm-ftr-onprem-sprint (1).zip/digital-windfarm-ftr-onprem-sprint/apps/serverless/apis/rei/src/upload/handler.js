import { InspectionsApi } from '@ge/serverless-http';
import { buildAuthHeader, responses, intercept, bodyParserInterceptor } from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';
export const getTurbineTypes = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getTurbineTypes(headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getTurbineDetails = async (event) => {
  const {
    pathParameters: { siteId },
  } = event;

  try {
    requireNotEmpty({ siteId });
    console.log(`Getting turbine as per site id', ${siteId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getTurbineDetails(siteId, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getComponentDetailList = async (event) => {
  const {
    pathParameters: { turbineAssetId },
  } = event;

  try {
    requireNotEmpty({ turbineAssetId });
    console.log(`Getting component', ${turbineAssetId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getComponentDetailList(turbineAssetId, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const postJob = intercept([bodyParserInterceptor], async (event) => {
  const {
    pathParameters: { jobId },
    queryStringParameters: { version },
    body: data,
  } = event;

  try {
    const body = data;
    requireNotEmpty({ jobId, version, body });
    console.log('Uploading images & videos');
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.postJob(jobId, version, body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const postMetadata = intercept([bodyParserInterceptor], async (event) => {
  const {
    pathParameters: { jobId },
    queryStringParameters: { version },
    body: data,
  } = event;

  try {
    const body = data;
    requireNotEmpty({ jobId, version, body });
    console.log(`updating metadata for job ID ${jobId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.postMetadata(jobId, version, body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const patchMetadata = intercept([bodyParserInterceptor], async (event) => {
  const {
    pathParameters: { jobId, parameter },
    body: data,
  } = event;

  try {
    const body = data;
    requireNotEmpty({ jobId, parameter, body });
    console.log(`updating metadata for job ID ${jobId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.patchMetadata(jobId, parameter, body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getPresignedUrl = intercept([bodyParserInterceptor], async (event) => {
  const { body: data } = event;

  try {
    const body = data;
    requireNotEmpty({ body });
    console.log(`Getting image pre-signed url ${body}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getPresignedUrl(body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const updateManufacturerByJobId = intercept([bodyParserInterceptor], async (event) => {
  const {
    pathParameters: { jobId },
    body: data,
  } = event;

  try {
    const body = data;
    requireNotEmpty({ jobId, body });
    console.log(`update Manufacturer by job ID ${jobId}`);
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.updateManufacturerByJobId(jobId, body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const uploadSpreadsheet = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: formData } = event;
    const body = formData;
    requireNotEmpty(body);
    const headers = buildAuthHeader(event);
    console.log(`inside handler.js event', ${JSON.stringify(event)}`);
    console.log(`inside handler.js params', ${JSON.stringify(body)}`);
    const response = await InspectionsApi.uploadSpreadsheetFile(body, headers);
    console.log(`inside handler.js response', ${JSON.stringify(response)}`);

    return responses.success(response);
  } catch (err) {
    console.log(`inside handler.js error', ${JSON.stringify(err)}`);
    return responses.error(err);
  }
});
