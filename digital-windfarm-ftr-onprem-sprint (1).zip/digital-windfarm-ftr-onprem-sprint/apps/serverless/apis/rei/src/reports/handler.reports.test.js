import * as ReportApi from '@ge/serverless-http/src/rendigital/rei/report-api';
import { buildResponse } from '@ge/serverless-utils';

import * as mockRequest from '../../__mocks__/request/report';
import * as mockResponse from '../../__mocks__/response/report';
import mockRequestHeader from '../../test-events/GetAllJobs.json';

import * as Reportfn from './handler';

const mockEvent = {
  headers: mockRequestHeader.headers,
  pathParameters: {
    jobId: 4108,
  },
};

const mockEventSiteId = {
  headers: mockRequestHeader.headers,
  body: {
    filters: {
      cod: null,
      coreFleet: 'all',
      sites: ['50006099'],
    },
  },
};

const postMockEvent = {
  headers: mockRequestHeader.headers,
  pathParameters: {
    jobId: 4108,
  },
  body: {
    data: {
      stage_status: 'ready',
      postprocessingcompletion_date: 1648557387,
      workflow_stage: 'upload',
    },
  },
};

const mockEventPostUpdateReport = mockRequest.updateReport;

const mockFailureRes = {
  config: {},
  message: 'GE Service Error: Request failed with status code 500',
};

describe('Report test cases', () => {
  describe('Success Report stage info function', () => {
    it('should return sucess upload stage info', async () => {
      jest
        .spyOn(ReportApi, 'getReportStageInfo')
        .mockImplementation(() => mockResponse.reportStage);
      expect(await Reportfn.getReportStageInfo(mockEvent)).toEqual(
        buildResponse(200, mockResponse.reportStage),
      );
    });

    it('report by job id failure', async () => {
      jest.spyOn(ReportApi, 'getReportStageInfo').mockRejectedValue(mockFailureRes);
      expect(await Reportfn.getReportStageInfo(mockEvent)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('report function', () => {
    it('should return success report by job id', async () => {
      jest
        .spyOn(ReportApi, 'getDataForReportGeneration')
        .mockImplementation(() => mockResponse.reportById);
      expect(await Reportfn.getDataForReportGeneration(mockEvent)).toEqual(
        buildResponse(200, mockResponse.reportById),
      );
    });

    it('report by job id failure', async () => {
      jest.spyOn(ReportApi, 'getDataForReportGeneration').mockRejectedValue(mockFailureRes);
      expect(await Reportfn.getDataForReportGeneration(mockEvent)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('update report function', () => {
    it('should update report successfully', async () => {
      jest.spyOn(ReportApi, 'updateReport').mockImplementation(() => mockResponse.updateReport);
      expect(await Reportfn.updateReport(mockEventPostUpdateReport)).toEqual(
        buildResponse(200, mockResponse.updateReport),
      );
    });
    it('should update report failure', async () => {
      jest.spyOn(ReportApi, 'updateReport').mockRejectedValue(mockFailureRes);
      expect(await Reportfn.updateReport(mockEventPostUpdateReport)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('complete report', () => {
    it('report completed jobs by site id success', async () => {
      jest
        .spyOn(ReportApi, 'getAllJobsWithReportCompleted')
        .mockImplementation(() => mockResponse.reportBySiteid);
      expect(await Reportfn.getReportCompletedJobs(mockEventSiteId)).toEqual(
        buildResponse(200, mockResponse.reportBySiteid),
      );
    });

    it('report completed jobs by site id failure', async () => {
      jest.spyOn(ReportApi, 'getAllJobsWithReportCompleted').mockRejectedValue(mockFailureRes);
      expect(await Reportfn.getReportCompletedJobs(mockEventSiteId)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('changeJobWorkflow for report', () => {
    it('should change the job stage successfully', async () => {
      jest
        .spyOn(ReportApi, 'completeReport')
        .mockImplementation(() => ({ status: 'Success updating workflow for this job.' }));
      expect(await Reportfn.completeReport(postMockEvent)).toEqual(
        buildResponse(200, { status: 'Success updating workflow for this job.' }),
      );
    });

    it('should change the job stage failure', async () => {
      jest.spyOn(ReportApi, 'completeReport').mockRejectedValue(mockFailureRes);
      expect(await Reportfn.completeReport(postMockEvent)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });
});
