const { Common } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');

// Post API Handler
export const handlerDispatch = async ({ headers, body: dispatchDetails }) => {
  try {
    const parsedDispatchDetails = JSON.parse(dispatchDetails);
    console.log('Sending Dispatch Details', dispatchDetails);

    const _headers = buildAuthHeader({ headers });
    const response = await Common.dispatch.dispatchData({
      headers: _headers,
      dispatchDetails: parsedDispatchDetails,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

// Get API Handler
export const handlerGetDispatch = async ({ headers, queryStringParameters }) => {
  const { serviceGroup, dispatchDate, timeZone } = queryStringParameters;
  try {
    const _headers = buildAuthHeader({ headers });
    const _params = {
      serviceGroup: serviceGroup,
      dispatchDate: dispatchDate,
      timeZone: timeZone,
    };
    console.log('Getting dispatch data', _params);

    const response = await Common.dispatch.getDispatchedData({
      headers: _headers,
      params: _params,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

// Patch API Handler
export const handlerDispatchPatch = async ({ headers, pathParameters, planChange }) => {
  const { id } = pathParameters;
  try {
    const _headers = buildAuthHeader({ headers });
    const response = await Common.dispatch.patchDispatchData({
      headers: _headers,
      id,
      planChange,
    });
    console.log('Patch Id: ', id);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
