import dayjs from 'dayjs';

import { DateTimeFormats } from '@ge/models/constants';

const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  responses,
  intercept,
  bodyParserInterceptor,
} = require('@ge/serverless-utils');

export const getTasks = intercept([bodyParserInterceptor], async ({ headers, body }) => {
  // TODO this would speed up the call
  const _headers = buildAuthHeader({ headers });
  const { startDate, endDate, status, pageIdx, pageSize, siteIds } = body || {};
  try {
    if (status) {
      console.log(`Getting tasks with statuses ${status}`);

      const response = await Common.tasks.getByStatus({
        headers: _headers,
        status,
        pageSize,
        pageIdx,
        siteIds,
      });
      return responses.success(response);
    }
    if (startDate && endDate) {
      console.log(`Getting calendar tasks in range ${startDate} - ${endDate}`);

      const response = await Common.tasks.getCalendar({
        headers: _headers,
        startDate: dayjs(startDate).format(DateTimeFormats.ENDPOINT_PARAM),
        endDate: dayjs(endDate).format(DateTimeFormats.ENDPOINT_PARAM),
        pageSize,
        pageIdx,
        siteIds,
      });
      return responses.success(response);
    }
    console.log('Getting all tasks');
    let query = null;
    if (siteIds && siteIds.length > 0) query = 'siteKey=in=(' + siteIds + ')';
    const params = { pageIdx, pageSize, query };
    const response = await Common.tasks.getPage({ headers: _headers, params });
    return responses.success(response);
  } catch (err) {
    console.error(err);
    return responses.error(err);
  }
});

export const createTask = async ({ headers, body: task }) => {
  try {
    console.log('Creating task', task);
    const parsedTask = JSON.parse(task);
    const _headers = buildAuthHeader({ headers });
    const response = await Common.tasks.create({
      headers: _headers,
      task: parsedTask,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const bulkTask = async ({ headers, body: taskToUpdate }) => {
  try {
    console.log('bulk task data', taskToUpdate);
    const parsedTask = JSON.parse(taskToUpdate);
    const _headers = buildAuthHeader({ headers });
    const response = await Common.tasks.bulk({
      headers: _headers,
      bulkData: parsedTask,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getTask = async ({ headers, pathParameters }) => {
  const { taskId } = pathParameters;
  try {
    const _headers = buildAuthHeader({ headers });
    const response = await Common.tasks.get({
      headers: _headers,
      params: { taskId },
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const editTask = async ({ headers, pathParameters, body: task }) => {
  const { taskId } = pathParameters;
  try {
    const _headers = buildAuthHeader({ headers });
    const response = await Common.tasks.edit({
      headers: _headers,
      taskId,
      task,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const deleteTask = async ({ headers, pathParameters }) => {
  const { taskId } = pathParameters;
  console.log('Deleting task', taskId);
  try {
    const _headers = buildAuthHeader({ headers });
    const response = await Common.tasks.deleteTask({
      headers: _headers,
      taskId,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getTaskByIds = async (event) => {
  const { headers, pathParameters } = event;

  const { taskIds } = pathParameters || {};
  const taskIdsArray = taskIds.split(',');

  console.log('Getting tasks for taskIds', taskIdsArray);

  try {
    const authHeader = buildAuthHeader({ headers });
    const result = await Common.tasks.getByIds({
      headers: authHeader,
      taskIds: taskIdsArray,
    });
    console.log('Returning tasks responses');
    return responses.success(result);
  } catch (err) {
    console.error(err);
    return responses.error(err);
  }
};

export const getAssetByIds = async (event) => {
  const {
    headers,
    queryStringParameters: { assetIds },
  } = event;
  const _headers = buildAuthHeader({ headers });
  console.log('Getting tasks for assetIds', assetIds);
  try {
    const query = `assetKey==${assetIds};taskStatus==completed`;
    const params = { query };
    const response = await Common.tasks.getAll({ headers: _headers, params });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
