const { Common } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');

export const getTurbineFailedStatus = async ({ headers, queryStringParameters }) => {
  const { assetIds, includeFields } = queryStringParameters;
  try {
    console.log('Getting turbine failed Status data');
    const _headers = buildAuthHeader({ headers });
    const _params = {
      assetIds: assetIds,
      includeFields: includeFields,
    };
    const response = await Common.tasks.getTurbineFailedStatus({
      headers: _headers,
      params: _params,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
