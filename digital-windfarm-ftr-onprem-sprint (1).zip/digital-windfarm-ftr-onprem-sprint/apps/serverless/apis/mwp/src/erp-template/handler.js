/* test locally
sam local invoke CreateErpRequest -e test-events/CreateErpRequest.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
sam local invoke GetErpRequest -e test-events/GetErpRequest.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
sam local invoke GetErpRequestStatus -e test-events/GetErpRequestStatus.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
sam local invoke GetErpTemplate -e test-events/GetErpTemplate.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
sam local invoke GetErpTranslations -e test-events/GetErpTranslations.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
*/

// TODO: pass back 204s where applicable (can bubble up from backend)

import { Manage } from '@ge/serverless-orchestration';
import { bodyParserInterceptor, buildAuthHeader, intercept, responses } from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';

export const createErpRequest = intercept([bodyParserInterceptor], async (event) => {
  try {
    console.debug('Creating ERP request');

    const { body: params = {}, pathParameters } = event;
    const { taskId } = pathParameters || {};
    const { metadata } = params;

    // TODO: expand on what params we expect to be defined here
    requireNotEmpty({ metadata, taskId });

    console.debug(`Creating ERP request for task '${taskId}'`);

    const headers = buildAuthHeader(event);

    const response = await Manage.erpTemplate.createErpRequest({ ...params, taskId }, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getErpRequest = async (event) => {
  try {
    console.debug('Getting ERP request');

    const { pathParameters } = event;
    const { taskId } = pathParameters || {};

    requireNotEmpty({ taskId });

    console.debug(`Getting ERP request with task Id '${taskId}'`);

    const headers = buildAuthHeader(event);

    const response = await Manage.erpTemplate.getErpRequest({ taskId }, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getErpRequestStatus = intercept([bodyParserInterceptor], async (event) => {
  try {
    console.debug('Getting ERP request status');

    const { body: params = {} } = event;
    const { taskIds } = params;

    requireNotEmpty({ taskIds });

    const headers = buildAuthHeader(event);

    const response = await Manage.erpTemplate.getErpRequestStatus({ taskIds }, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getErpTemplate = async (event) => {
  try {
    console.debug('Getting ERP template');

    const headers = buildAuthHeader(event);

    const response = await Manage.erpTemplate.getErpTemplate(headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getErpTranslations = async (event) => {
  try {
    console.debug('Getting ERP translations');

    const { pathParameters } = event;
    // can allow default language here if needed
    const { language } = pathParameters || {};

    requireNotEmpty({ language });

    const headers = buildAuthHeader(event);

    const response = await Manage.erpTemplate.getErpTranslations({ language }, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
