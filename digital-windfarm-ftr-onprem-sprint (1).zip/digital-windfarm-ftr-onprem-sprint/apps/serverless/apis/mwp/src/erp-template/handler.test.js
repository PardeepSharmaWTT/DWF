import { ManageApi } from '@ge/serverless-http/src/rendigital';
import { ManageTransformer } from '@ge/serverless-models/src/rendigital/transformers';
import { Manage } from '@ge/serverless-orchestration/src/rendigital';

import {
  MockErpDfsaTemplate,
  MockErpCollections,
  MockErpInternationalization,
} from '../../../../__mocks__/mwp';
import * as MockErpTemplateRequest from '../../test-events/GetErpTemplate.json';
import * as MockErpTranslationsRequest from '../../test-events/GetErpTranslations.json';

import * as handler from './handler';

describe('ERP Template', () => {
  describe('handler', () => {
    it('Gets ERP template', async () => {
      // stub out http layer
      jest
        .spyOn(ManageApi.erpTemplate, 'getErpTemplate')
        .mockImplementation(() => ManageTransformer.erpTemplateTransformer(MockErpDfsaTemplate));
      jest
        .spyOn(ManageApi.erpTemplate, 'getErpTemplateFieldValues')
        .mockImplementation(() =>
          ManageTransformer.erpTemplateFieldValuesTransformer(MockErpCollections),
        );

      const { body } = await handler.getErpTemplate(MockErpTemplateRequest);
      const { operations, sections } = JSON.parse(body);

      expect(operations).toEqual(expect.arrayContaining(['create', 'edit']));
      expect(sections.length).toBe(MockErpDfsaTemplate.sections.length);

      sections.forEach(({ metadata }, i) => {
        const fieldKeys = Object.keys(metadata);
        const sourceSection = MockErpDfsaTemplate.sections[i];
        const { fields: sourceFields } = sourceSection;

        // can make this more granular as needed
        expect(fieldKeys.length).toBe(sourceFields.length);
      });
    });

    it('Gets ERP translations', async () => {
      // stub out orchestration layer
      jest
        .spyOn(Manage.erpTemplate, 'getErpTranslations')
        .mockImplementation(() =>
          ManageTransformer.erpTranslationsTransformer(MockErpInternationalization),
        );

      const { body } = await handler.getErpTranslations(MockErpTranslationsRequest);
      const translations = JSON.parse(body);

      expect(Object.keys(translations).length).toBeTruthy();
    });
  });
});
