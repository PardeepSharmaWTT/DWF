// #175 removing forced mocks for anomalies and adding handler
// this should be temporary though as we use cases going forward
// and remove anomalies from the codebase

const monitor = require('@ge/mocks-logic/monitor');
const { intercept, noMocksInterceptor, responses } = require('@ge/serverless-utils');

export const getAnomalies = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
      queryStringParameters: { caseId },
    } = event;

    let response;

    // TODO: add real data implementation here with option to fall back to mock

    if (id) {
      console.debug(`Getting anomaly for Id '${id}'`);

      response = { anomalies: monitor.getAnomalies(id) };
    } else if (caseId) {
      console.debug(`Getting anomalies for case '${caseId}'`);

      response = { anomalies: monitor.getAnamoliesByCaseId(caseId) };
    } else {
      console.debug('Getting anomalies');

      response = { anomalies: monitor.getAnomalies() };
    }

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

// putting this in anomalies handler for now since it's temporary and pulls the same mock data
export const getIssues = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      queryStringParameters: { assetId, caseId },
    } = event;

    let response;

    // TODO: add real data implementation here with option to fall back to mock

    if (assetId) {
      console.debug(`Getting event history for asset '${assetId}'`);

      response = { history: monitor.getEventHistory(assetId) };
    } else if (caseId) {
      console.debug(`Getting issues for case '${caseId}'`);

      response = { issues: monitor.getIssuesByCaseId(caseId) };
    }

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
