const eventCountInverter4 = {
  events_summary: [
    {
      severity_id: 1,
      count: 15,
      id: 3502,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 1,
      count: 10,
      id: 8713,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 1,
      count: 21,
      id: 8030,
      desc: 'SUPPLY VOLTAGE FOR THE ASSEMBLIES HAS FAILED',
    },
    {
      severity_id: 1,
      count: 4,
      id: 9031,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 1,
      count: 6,
      id: 9024,
      desc: 'FAST STOP TRIPPED BY REMOTE GFDI',
    },
    {
      severity_id: 1,
      count: 2,
      id: 9030,
      desc: 'FAST STOP TRIPPED BY EXTERNAL WATCHDOG',
    },
    {
      severity_id: 1,
      count: 3,
      id: 3501,
      desc: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
    },
    {
      severity_id: 1,
      count: 9,
      id: 7708,
      desc: 'FAULTY SWITCHING STATUS OF REMOTE GFDI',
    },
    {
      severity_id: 1,
      count: 1,
      id: 2040,
      desc: 'GRID VOLTAGE IS TOO LOW - UNDERVOLTAGE DETECTED',
    },
    {
      severity_id: 1,
      count: 7,
      id: 9009,
      desc: 'FAST STOP TRIPPED BY PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 1,
      count: 3,
      id: 9025,
      desc: 'FAST STOP TRIPPED BY PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 2,
      count: 15,
      id: 3517,
      desc: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
    },
    {
      severity_id: 2,
      count: 10,
      id: 3601,
      desc: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
    },
    {
      severity_id: 3,
      count: 15,
      id: 3112,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 3,
      count: 10,
      id: 1223,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 3,
      count: 21,
      id: 9987,
      desc: 'SUPPLY VOLTAGE FOR THE ASSEMBLIES HAS FAILED',
    },
    {
      severity_id: 3,
      count: 4,
      id: 9965,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 3,
      count: 6,
      id: 5432,
      desc: 'FAST STOP TRIPPED BY REMOTE GFDI',
    },
    {
      severity_id: 3,
      count: 2,
      id: 6543,
      desc: 'FAST STOP TRIPPED BY EXTERNAL WATCHDOG',
    },
    {
      severity_id: 3,
      count: 3,
      id: 7896,
      desc: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
    },
  ],
};

module.exports = { eventCountInverter4 };
