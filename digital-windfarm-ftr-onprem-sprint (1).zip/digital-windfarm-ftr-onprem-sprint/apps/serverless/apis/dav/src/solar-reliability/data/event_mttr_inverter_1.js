const eventMttrInverter1 = {
  events_summary: [
    {
      severity_id: 1,
      mttr: 73.6,
      id: 3501,
      desc: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
    },
    {
      severity_id: 1,
      mttr: 0.1,
      id: 8713,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 1,
      mttr: 0.0,
      id: 9025,
      desc: 'FAST STOP MANUALLY TRIPPED AT KEY SWITCH -S2',
    },
    {
      severity_id: 1,
      mttr: 0.1,
      id: 3502,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 1,
      mttr: 46.0,
      id: 9031,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 1,
      mttr: 138.9,
      id: 9009,
      desc: 'FAST STOP TRIPPED BY PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 1,
      mttr: 0.1,
      id: 9030,
      desc: 'FAST STOP TRIPPED BY EXTERNAL WATCHDOG',
    },
  ],
  units: {
    mttr: 'hour',
  },
};

module.exports = { eventMttrInverter1 };
