const { intercept, noMocksInterceptor } = require('@ge/serverless-utils/src/interceptor-utils');
const { responses } = require('@ge/serverless-utils/src/serverless-utils');

const { assetCountInverter1 } = require('./data/asset_count_inverter_1');
const { assetCountInverter4 } = require('./data/asset_count_inverter_123');
const { assetCountInverter2 } = require('./data/asset_count_inverter_2');
const { assetCountInverter3 } = require('./data/asset_count_inverter_3');
const { assetDurationInverter1 } = require('./data/asset_duration_inverter_1');
const { assetDurationInverter4 } = require('./data/asset_duration_inverter_123');
const { assetDurationInverter2 } = require('./data/asset_duration_inverter_2');
const { assetDurationInverter3 } = require('./data/asset_duration_inverter_3');
const { assetMtbfInverter1 } = require('./data/asset_mtbf_inverter_1');
const { assetMtbfInverter4 } = require('./data/asset_mtbf_inverter_123');
const { assetMtbfInverter2 } = require('./data/asset_mtbf_inverter_2');
const { assetMtbfInverter3 } = require('./data/asset_mtbf_inverter_3');
const { assetMttrInverter1 } = require('./data/asset_mttr_inverter_1');
const { assetMttrInverter4 } = require('./data/asset_mttr_inverter_123');
const { assetMttrInverter2 } = require('./data/asset_mttr_inverter_2');
const { assetMttrInverter3 } = require('./data/asset_mttr_inverter_3');
const { eventCountInverter1 } = require('./data/event_count_inverter_1');
const { eventCountInverter4 } = require('./data/event_count_inverter_123');
const { eventCountInverter2 } = require('./data/event_count_inverter_2');
const { eventCountInverter3 } = require('./data/event_count_inverter_3');
const { eventDurationInverter1 } = require('./data/event_duration_inverter_1');
const { eventDurationInverter4 } = require('./data/event_duration_inverter_123');
const { eventDurationInverter2 } = require('./data/event_duration_inverter_2');
const { eventDurationInverter3 } = require('./data/event_duration_inverter_3');
const { eventMtbfInverter1 } = require('./data/event_mtbf_inverter_1');
const { eventMtbfInverter4 } = require('./data/event_mtbf_inverter_123');
const { eventMtbfInverter2 } = require('./data/event_mtbf_inverter_2');
const { eventMtbfInverter3 } = require('./data/event_mtbf_inverter_3');
const { eventMttrInverter1 } = require('./data/event_mttr_inverter_1');
const { eventMttrInverter4 } = require('./data/event_mttr_inverter_123');
const { eventMttrInverter2 } = require('./data/event_mttr_inverter_2');
const { eventMttrInverter3 } = require('./data/event_mttr_inverter_3');

export const getReliability = intercept([noMocksInterceptor], async (event) => {
  try {
    const { groupBy, reportBy, severity } = JSON.parse(event.body);

    const reliabilityData = {
      assets: {
        count: {
          1: assetCountInverter1,
          2: assetCountInverter2,
          3: assetCountInverter3,
          4: assetCountInverter4,
        },
        duration: {
          1: assetDurationInverter1,
          2: assetDurationInverter2,
          3: assetDurationInverter3,
          4: assetDurationInverter4,
        },
        mttr: {
          1: assetMttrInverter1,
          2: assetMttrInverter2,
          3: assetMttrInverter3,
          4: assetMttrInverter4,
        },
        mtbf: {
          1: assetMtbfInverter1,
          2: assetMtbfInverter2,
          3: assetMtbfInverter3,
          4: assetMtbfInverter4,
        },
      },
      events: {
        count: {
          1: eventCountInverter1,
          2: eventCountInverter2,
          3: eventCountInverter3,
          4: eventCountInverter4,
        },
        duration: {
          1: eventDurationInverter1,
          2: eventDurationInverter2,
          3: eventDurationInverter3,
          4: eventDurationInverter4,
        },
        mttr: {
          1: eventMttrInverter1,
          2: eventMttrInverter2,
          3: eventMttrInverter3,
          4: eventMttrInverter4,
        },
        mtbf: {
          1: eventMtbfInverter1,
          2: eventMtbfInverter2,
          3: eventMtbfInverter3,
          4: eventMtbfInverter4,
        },
      },
    };
    if (
      typeof reliabilityData[groupBy] !== 'undefined' &&
      typeof reliabilityData[groupBy][reportBy] !== 'undefined' &&
      typeof reliabilityData[groupBy][reportBy][severity] !== 'undefined'
    ) {
      let responseData = reliabilityData[groupBy][reportBy][severity] || 'Invalid Data';
      return responses.success(JSON.stringify(responseData));
    }
    return responses.success(JSON.stringify('Invalid Data'));
  } catch (err) {
    return responses.error(err);
  }
});
