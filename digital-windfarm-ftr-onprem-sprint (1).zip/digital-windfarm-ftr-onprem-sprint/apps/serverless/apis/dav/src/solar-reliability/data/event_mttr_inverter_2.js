const eventMttrInverter2 = {
  events_summary: [
    {
      severity_id: 2,
      mttr: 73.6,
      id: 3517,
      desc: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
    },
    {
      severity_id: 2,
      mttr: 0.1,
      id: 3601,
      desc: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
    },
  ],
  units: {
    mttr: 'hour',
  },
};

module.exports = { eventMttrInverter2 };
