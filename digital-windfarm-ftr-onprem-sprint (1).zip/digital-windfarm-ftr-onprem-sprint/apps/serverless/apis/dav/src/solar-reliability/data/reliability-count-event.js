const reliabilityCountEvent = {
  data: {
    events_summary: [
      {
        severity_id: 1,
        count: 11,
        id: 5150,
        desc: 'Estop Panel - Estop Bldg Mushroom Switch',
      },
      {
        severity_id: 2,
        count: 1,
        id: 6001,
        desc: 'Grid meter communication error',
      },
      {
        severity_id: 2,
        count: 1,
        id: 6004,
        desc: 'Loss of grid voltage ',
      },
      {
        severity_id: 2,
        count: 1,
        id: 6005,
        desc: 'Loss of BESS communication ',
      },
      {
        severity_id: 2,
        count: 1,
        id: 6006,
        desc: 'BESS power control error',
      },
      {
        severity_id: 2,
        count: 1,
        id: 6009,
        desc: 'U/Phi/Q control error',
      },
      {
        severity_id: 3,
        count: 6,
        id: 6104,
        desc: 'Plant power capability is lower than rating',
      },
      {
        severity_id: 2,
        count: 4,
        id: 9040,
        desc: 'Incomer Protection Faulty (Watchdog) ',
      },
      {
        severity_id: 3,
        count: 1,
        id: 9069,
        desc: 'Bay14 BB VT - Aux Supply Abnormal',
      },
      {
        severity_id: 3,
        count: 1,
        id: 9071,
        desc: 'Bay14 BB VT - Supply Abnormal',
      },
      {
        severity_id: 3,
        count: 3,
        id: 9078,
        desc: 'Bay16 BB Earthing - Bus Earthed',
      },
    ],
  },
};
module.exports = { reliabilityCountEvent };
