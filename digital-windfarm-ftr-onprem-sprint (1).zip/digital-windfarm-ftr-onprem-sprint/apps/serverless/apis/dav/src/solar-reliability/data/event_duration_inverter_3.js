const eventDurationInverter3 = {
  events_summary: [
    {
      severity_id: 3,
      count: 10,
      id: 2211,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 3,
      count: 11,
      id: 3245,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 3,
      count: 12,
      id: 7632,
      desc: 'SUPPLY VOLTAGE FOR THE ASSEMBLIES HAS FAILED',
    },
    {
      severity_id: 3,
      count: 13,
      id: 6589,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 3,
      count: 14,
      id: 1115,
      desc: 'FAST STOP TRIPPED BY REMOTE GFDI',
    },
    {
      severity_id: 3,
      count: 15,
      id: 7654,
      desc: 'FAST STOP TRIPPED BY EXTERNAL WATCHDOG',
    },
    {
      severity_id: 3,
      count: 16,
      id: 7755,
      desc: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
    },
  ],
};

module.exports = { eventDurationInverter3 };
