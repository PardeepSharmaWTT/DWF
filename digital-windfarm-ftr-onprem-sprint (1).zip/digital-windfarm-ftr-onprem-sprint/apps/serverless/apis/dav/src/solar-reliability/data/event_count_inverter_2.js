const eventCountInverter2 = {
  events_summary: [
    {
      severity_id: 2,
      count: 15,
      id: 3517,
      desc: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
    },
    {
      severity_id: 2,
      count: 10,
      id: 3601,
      desc: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
    },
  ],
};

module.exports = { eventCountInverter2 };
