const assetMtbfInverter3 = {
  assets_summary: [
    {
      id: 'TECO_BMS_B01_INV01',
      name: '01-PCS-01',
      events_summary: [
        {
          severity_id: 3,
          mtbf: 2,
        },
      ],
    },
  ],
};

module.exports = { assetMtbfInverter3 };
