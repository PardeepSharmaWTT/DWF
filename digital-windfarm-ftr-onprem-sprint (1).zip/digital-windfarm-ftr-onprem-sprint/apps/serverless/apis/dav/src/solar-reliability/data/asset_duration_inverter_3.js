const assetDurationInverter3 = {
  assets_summary: [
    {
      id: 'TECO_BMS_B01_INV01',
      name: '01-PCS-01',
      events_summary: [
        {
          severity_id: 3,
          duration: 2,
        },
      ],
    },
    {
      id: 'TECO_BMS_B01_INV02',
      name: '01-PCS-02',
      events_summary: [
        {
          severity_id: 3,
          duration: 2,
        },
      ],
    },
    {
      id: 'TECO_BMS_B01_INV03',
      name: '01-PCS-03',
      events_summary: [
        {
          severity_id: 3,
          duration: 5,
        },
      ],
    },
  ],
};

module.exports = { assetDurationInverter3 };
