const eventDurationInverter1 = {
  events_summary: [
    {
      severity_id: 1,
      duration: 1104.3,
      id: 8713,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 1,
      duration: 1.0,
      id: 3502,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 1,
      duration: 0.1,
      id: 3501,
      desc: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
    },
    {
      severity_id: 1,
      duration: 0.4,
      id: 9031,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 1,
      duration: 276.2,
      id: 8030,
      desc: 'SUPPLY VOLTAGE FOR THE ASSEMBLIES HAS FAILED',
    },
    {
      severity_id: 1,
      duration: 277.8,
      id: 9025,
      desc: 'FAST STOP MANUALLY TRIPPED AT KEY SWITCH -S2',
    },
  ],
  units: {
    duration: 'hour',
  },
};

module.exports = { eventDurationInverter1 };
