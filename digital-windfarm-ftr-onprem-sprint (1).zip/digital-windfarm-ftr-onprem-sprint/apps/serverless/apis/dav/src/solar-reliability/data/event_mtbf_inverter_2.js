const eventMtbfInverter2 = {
  events_summary: [
    {
      severity_id: 2,
      mtbf: 73.6,
      id: 3517,
      desc: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
    },
    {
      severity_id: 2,
      mtbf: 0.1,
      id: 3601,
      desc: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
    },
  ],
  units: {
    mtbf: 'hour',
  },
};

module.exports = { eventMtbfInverter2 };
