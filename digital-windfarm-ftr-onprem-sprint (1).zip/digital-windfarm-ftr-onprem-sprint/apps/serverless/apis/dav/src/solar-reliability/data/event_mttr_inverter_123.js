const eventMttrInverter4 = {
  events_summary: [
    {
      severity_id: 1,
      mttr: 73.6,
      id: 3501,
      desc: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
    },
    {
      severity_id: 1,
      mttr: 0.1,
      id: 8713,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 1,
      mttr: 0.0,
      id: 9025,
      desc: 'FAST STOP MANUALLY TRIPPED AT KEY SWITCH -S2',
    },
    {
      severity_id: 1,
      mttr: 0.1,
      id: 3502,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 1,
      mttr: 46.0,
      id: 9031,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 1,
      mttr: 138.9,
      id: 9009,
      desc: 'FAST STOP TRIPPED BY PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 1,
      mttr: 0.1,
      id: 9030,
      desc: 'FAST STOP TRIPPED BY EXTERNAL WATCHDOG',
    },
    {
      severity_id: 2,
      mttr: 73.6,
      id: 3517,
      desc: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
    },
    {
      severity_id: 2,
      mttr: 0.1,
      id: 3601,
      desc: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
    },
    {
      severity_id: 3,
      count: 10,
      id: 8765,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 3,
      count: 11,
      id: 8854,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 3,
      count: 12,
      id: 2223,
      desc: 'SUPPLY VOLTAGE FOR THE ASSEMBLIES HAS FAILED',
    },
    {
      severity_id: 3,
      count: 13,
      id: 5567,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 3,
      count: 14,
      id: 6512,
      desc: 'FAST STOP TRIPPED BY REMOTE GFDI',
    },
  ],
  units: {
    mttr: 'hour',
  },
};

module.exports = { eventMttrInverter4 };
