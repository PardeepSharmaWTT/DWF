const assetMtbfInverter4 = {
  assets_summary: [
    {
      id: 'TECO_BB1_B01_INV05',
      name: 'MV CIRCUIT 1 - INV-05',
      events_summary: [
        {
          severity_id: 1,
          mtbf: 2,
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV01',
      name: 'MV CIRCUIT 2 - INV-06',
      events_summary: [
        {
          severity_id: 1,
          mtbf: 2,
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV02',
      name: 'MV CIRCUIT 2 - INV-07',
      events_summary: [
        {
          severity_id: 1,
          mtbf: 5,
        },
      ],
    },
    {
      id: 'TECO_BB1_B01_INV03',
      name: 'MV CIRCUIT 1 - INV-03',
      events_summary: [
        {
          severity_id: 1,
          mtbf: 3,
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV03',
      name: 'MV CIRCUIT 2 - INV-08',
      events_summary: [
        {
          severity_id: 1,
          mtbf: 1,
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV04',
      name: 'MV CIRCUIT 2 - INV-09',
      events_summary: [
        {
          severity_id: 1,
          mtbf: 3,
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV03',
      name: 'MV CIRCUIT 2 - INV-08',
      events_summary: [
        {
          severity_id: 2,
          mtbf: 2,
        },
      ],
    },
    {
      id: 'TECO_BMS_B01_INV01',
      name: '01-PCS-01',
      events_summary: [
        {
          severity_id: 3,
          mtbf: 2,
        },
      ],
    },
  ],
};

module.exports = { assetMtbfInverter4 };
