const eventCountInverter3 = {
  events_summary: [
    {
      severity_id: 3,
      count: 15,
      id: 3112,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 3,
      count: 10,
      id: 1223,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 3,
      count: 21,
      id: 9987,
      desc: 'SUPPLY VOLTAGE FOR THE ASSEMBLIES HAS FAILED',
    },
    {
      severity_id: 3,
      count: 4,
      id: 9965,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 3,
      count: 6,
      id: 5432,
      desc: 'FAST STOP TRIPPED BY REMOTE GFDI',
    },
    {
      severity_id: 3,
      count: 2,
      id: 6543,
      desc: 'FAST STOP TRIPPED BY EXTERNAL WATCHDOG',
    },
    {
      severity_id: 3,
      count: 3,
      id: 7896,
      desc: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
    },
  ],
};

module.exports = { eventCountInverter3 };
