const eventMttrInverter3 = {
  events_summary: [
    {
      severity_id: 3,
      count: 10,
      id: 8765,
      desc: 'GFDI HAS TRIPPED',
    },
    {
      severity_id: 3,
      count: 11,
      id: 8854,
      desc: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
    },
    {
      severity_id: 3,
      count: 12,
      id: 2223,
      desc: 'SUPPLY VOLTAGE FOR THE ASSEMBLIES HAS FAILED',
    },
    {
      severity_id: 3,
      count: 13,
      id: 5567,
      desc: 'FAST STOP TRIPPED BY REDUNDANT MONITORING OF THE PROCESSOR ASSEMBLY',
    },
    {
      severity_id: 3,
      count: 14,
      id: 6512,
      desc: 'FAST STOP TRIPPED BY REMOTE GFDI',
    },
  ],
};

module.exports = { eventMttrInverter3 };
