const reliabilityCountAsset = {
  data: {
    assets_summary: [
      {
        id: 'GESTO_BLXW_MVSG01_XFR01_INV01',
        name: 'INV 01',
        events_summary: [
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG01_XFR01_INV02',
        name: 'INV 02',
        events_summary: [
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG01_XFR01_INV03',
        name: 'INV 03',
        events_summary: [
          {
            severity_id: 1,
            count: 5,
          },
          {
            severity_id: 2,
            count: 30,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG01_XFR01_INV04',
        name: 'INV 04',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG02_XFR01_INV01',
        name: 'INV 05',
        events_summary: [
          {
            severity_id: 1,
            count: 1,
          },
          {
            severity_id: 2,
            count: 4,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG02_XFR01_INV02',
        name: 'INV 06',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG02_XFR01_INV03',
        name: 'INV 07',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG02_XFR01_INV04',
        name: 'INV 08',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG03_XFR01_INV01',
        name: 'INV 09',
        events_summary: [
          {
            severity_id: 1,
            count: 1,
          },
          {
            severity_id: 2,
            count: 3,
          },
          {
            severity_id: 3,
            count: 4,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG03_XFR01_INV02',
        name: 'INV 10',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG03_XFR01_INV03',
        name: 'INV 11',
        events_summary: [
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG04_XFR01_INV01',
        name: 'INV 12',
        events_summary: [
          {
            severity_id: 1,
            count: 1,
          },
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG04_XFR01_INV02',
        name: 'INV 13',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG04_XFR01_INV03',
        name: 'INV 14',
        events_summary: [
          {
            severity_id: 1,
            count: 1,
          },
          {
            severity_id: 2,
            count: 16,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG05_XFR01_INV01',
        name: 'INV 15',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG05_XFR01_INV02',
        name: 'INV 16',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG05_XFR01_INV03',
        name: 'INV 17',
        events_summary: [
          {
            severity_id: 1,
            count: 1,
          },
          {
            severity_id: 2,
            count: 1,
          },
          {
            severity_id: 3,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG06_XFR01_INV01',
        name: 'INV 18',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG06_XFR01_INV03',
        name: 'INV 20',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG07_XFR01_INV02',
        name: 'INV 22',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG07_XFR01_INV03',
        name: 'INV 23',
        events_summary: [
          {
            severity_id: 2,
            count: 4,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG08_XFR01_INV01',
        name: 'INV 24',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG08_XFR01_INV02',
        name: 'INV 25',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG08_XFR01_INV03',
        name: 'INV 26',
        events_summary: [
          {
            severity_id: 1,
            count: 2,
          },
          {
            severity_id: 2,
            count: 10,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG09_XFR01_INV01',
        name: 'INV 27',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG09_XFR01_INV02',
        name: 'INV 28',
        events_summary: [
          {
            severity_id: 2,
            count: 3,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG09_XFR01_INV03',
        name: 'INV 29',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG10_XFR01_INV01',
        name: 'INV 30',
        events_summary: [
          {
            severity_id: 2,
            count: 1,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG10_XFR01_INV02',
        name: 'INV 31',
        events_summary: [
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG10_XFR01_INV03',
        name: 'INV 32',
        events_summary: [
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG11_XFR01_INV01',
        name: 'INV 33',
        events_summary: [
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG11_XFR01_INV02',
        name: 'INV 34',
        events_summary: [
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
      {
        id: 'GESTO_BLXW_MVSG11_XFR01_INV03',
        name: 'INV 35',
        events_summary: [
          {
            severity_id: 1,
            count: 1,
          },
          {
            severity_id: 2,
            count: 2,
          },
        ],
      },
    ],
  },
};
module.exports = { reliabilityCountAsset };
