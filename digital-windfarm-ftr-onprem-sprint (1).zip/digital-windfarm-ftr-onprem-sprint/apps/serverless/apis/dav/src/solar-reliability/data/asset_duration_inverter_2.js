const assetDurationInverter2 = {
  assets_summary: [
    {
      id: 'TECO_BB1_B02_INV03',
      name: 'MV CIRCUIT 2 - INV-08',
      events_summary: [
        {
          severity_id: 2,
          duration: 2,
        },
      ],
    },
  ],
};

module.exports = { assetDurationInverter2 };
