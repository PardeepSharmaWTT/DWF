const { intercept, noMocksInterceptor } = require('@ge/serverless-utils/src/interceptor-utils');
const { responses } = require('@ge/serverless-utils/src/serverless-utils');

const { inverterData } = require('./data/inverter-list');
const { siteAggregatedKpis } = require('./data/site-agrregated-kpis');

export const getInverterList = intercept([noMocksInterceptor], async () => {
  try {
    let responseData;
    responseData = JSON.stringify(inverterData);
    return responses.success(responseData);
  } catch (err) {
    return responses.error(err);
  }
});

export const getsiteAggregatedKpis = intercept([noMocksInterceptor], async () => {
  try {
    let responseData;
    responseData = JSON.stringify(siteAggregatedKpis);
    return responses.success(responseData);
  } catch (err) {
    return responses.error(err);
  }
});
