import { SortDirection, TimeAggr } from '@ge/models/constants';
import { InputEntityType } from '@ge/serverless-models/src/rendigital/enums';
import Analyze from '@ge/serverless-orchestration/src/rendigital/dav';
import AvailabilityKpi from '@ge/serverless-orchestration/src/rendigital/dav/availability-kpi';

const {
  bodyParserInterceptor,
  buildAuthHeader,
  intercept,
  responses,
} = require('@ge/serverless-utils');

export const getFleetKpiData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;

    console.debug(`Getting fleet KPI data with params '${JSON.stringify(body)}'`);

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      // do we need to map incoming type to internal type?
      entityAggr = InputEntityType.REGION,
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;
    // TODO: remove this, it's just a placeholder for now because still required by backend
    // but that is supposed to change since not all calls expect entity ids
    // was told to just pass tenant id along for now
    const entityIds = ['geservdrZp'];
    const entityType = InputEntityType.FLEET;

    const response = await Analyze.kpi.getKpiData(
      {
        ...params,
        entityAggr,
        entityIds,
        entityType,
        timeAggr,
      },
      headers,
    );

    console.debug('Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSitePerformance = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;

    console.debug(`Getting fleet site performance data with params '${JSON.stringify(body)}'`);

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      pageIndex = 0,
      pageSize = 10,
      // do we need to map incoming type to internal type?
      sortDirection = SortDirection.ASC,
      // is this the right default for this endpoint?
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;

    const data = await AvailabilityKpi.getSitePerformance(
      {
        ...params,
        entityAggr: InputEntityType.SITE,
        entityType: InputEntityType.FLEET,
        pageIndex,
        pageSize,
        sortDirection,
        timeAggr,
      },
      headers,
    );

    const response = { data };

    console.debug('Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
