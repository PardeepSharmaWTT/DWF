import { TimeAggr } from '@ge/models/constants';
import { InputEntityType } from '@ge/serverless-models/src/rendigital/enums';
import Analyze from '@ge/serverless-orchestration/src/rendigital/dav';
import { buildAuthHeader } from '@ge/serverless-utils/src/external-api';

const analyze = require('@ge/mocks-logic/analyze');

import { executionTimer } from '@ge/serverless-utils';

const {
  bodyParserInterceptor,
  intercept,
  noMocksInterceptor,
  responses,
} = require('@ge/serverless-utils');

export const getRegionKpiData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      body,
      pathParameters: { id },
    } = event;

    console.debug(`Getting KPI data for Region '${id}' with params '${JSON.stringify(body)}'`);

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      entityType = InputEntityType.REGION,
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;
    const entityIds = [id];
    const stopTimer = executionTimer(
      `Api Call Time for Region ${id} with categories ${params && params.categories} is`,
    );
    const { data } = await Analyze.kpi.getKpiData(
      {
        ...params,
        entityIds,
        entityType,
        timeAggr,
      },
      headers,
    );

    const response = {
      data,
    };
    stopTimer();
    console.debug('Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getLowestPerformingRegions = intercept([noMocksInterceptor], async () => {
  try {
    console.debug('Getting lowest performing regions');

    const response = analyze.getLowestPerformingRegions();

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getRegionOverview = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
    } = event;

    console.debug(`Getting overview for Region ${id}`);

    const response = analyze.getRegionOverview(id);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getRegionSystemLoss = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
    } = event;

    console.debug(`Getting system loss data for region ${id}`);

    const response = analyze.getRegionSystemLoss(id);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
