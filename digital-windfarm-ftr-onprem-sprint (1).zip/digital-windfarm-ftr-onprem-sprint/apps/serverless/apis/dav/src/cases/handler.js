import { bodyParserInterceptor, intercept } from '@ge/serverless-utils/src/interceptor-utils';
import { requireNonNull } from '@ge/util/object-utils';

const { Enums } = require('@ge/serverless-models');
const { Analyze } = require('@ge/serverless-orchestration');
const { buildAuthHeader, getSiteIdsFilter, responses } = require('@ge/serverless-utils');

const { CaseEntityParams } = Enums;

export const getCases = (event) => {
  const {
    queryStringParameters: { siteIds },
  } = event;

  if (!siteIds) {
    return Promise.resolve(() => responses.error('Must specify site ids param'));
  }
  const siteIdArray = siteIds.split(',');
  const authHeader = buildAuthHeader(event);

  return Analyze.casesForSites(siteIdArray, authHeader)
    .then((result) => responses.success(result))
    .catch((e) => responses.error(e));
};

export const updateCase = intercept([bodyParserInterceptor], async (event) => {
  const {
    body,
    pathParameters: { id },
  } = event;
  const authHeader = buildAuthHeader(event);
  try {
    const { asset, ...rest } = body;
    requireNonNull({ id, asset });
    requireNonNull({ assetId: asset.id });
    const result = await Analyze.updateCase({ id, asset: { id: asset.id }, ...rest }, authHeader);
    return responses.success(result);
  } catch (e) {
    return responses.error(e);
  }
});

// createCase() is deprecated. please use createCases instead
export const createCase = intercept([bodyParserInterceptor], async (event) => {
  const { body } = event;
  const authHeader = buildAuthHeader(event);
  try {
    const { assetId, siteId, title, componentIds } = body;
    requireNonNull({ assetId });
    requireNonNull({ siteId });
    requireNonNull({ title });
    requireNonNull({ componentIds });
    const result = await Analyze.createCase(body, authHeader);
    return responses.success(result);
  } catch (e) {
    return responses.error(e);
  }
});

export const createCases = intercept([bodyParserInterceptor], async (event) => {
  const { body } = event;
  const authHeader = buildAuthHeader(event);
  try {
    const { casesToBeLoaded } = body;

    requireNonNull({ casesToBeLoaded });

    const result = await Analyze.createCases(body, authHeader);
    return responses.success(result);
  } catch (e) {
    return responses.error(e);
  }
});

export const updateCases = intercept([bodyParserInterceptor], async (event) => {
  const { body } = event;
  const authHeader = buildAuthHeader(event);
  try {
    const { caseIds, status, ...rest } = body;

    requireNonNull({ caseIds, status });

    const result = await Analyze.updateCases(caseIds, { status, ...rest }, authHeader);
    return responses.success(result);
  } catch (e) {
    return responses.error(e);
  }
});

export const linkCases = intercept([bodyParserInterceptor], async (event) => {
  const { body } = event;
  const authHeader = buildAuthHeader(event);
  try {
    const { title, parentCaseId, caseToBeLinked } = body;
    console.log(
      `🦄 ~ Linking cases with title ${title}, parentCaseId ${parentCaseId} and childCaseIds ${caseToBeLinked}`,
    );
    requireNonNull({ parentCaseId, caseToBeLinked });

    const result = await Analyze.linkCases(body, authHeader);
    return responses.success(result);
  } catch (e) {
    if (e.response) {
      return responses.error(e.response.data, e.response.status);
    }
    return responses.error(e);
  }
});

export const unlinkCases = intercept([bodyParserInterceptor], async (event) => {
  const { body } = event;
  const authHeader = buildAuthHeader(event);
  try {
    const { siteId, assetId, parentId, casesToBeDelinked } = body;

    console.log(
      `🦄 ~ Unlinking cases with siteId ${siteId}, assetId ${assetId}, parentCaseId ${parentId} and childCaseIds ${casesToBeDelinked}`,
    );

    requireNonNull({ siteId, assetId, parentId, casesToBeDelinked });

    const result = await Analyze.unlinkCases(body, authHeader);

    return responses.success(result);
  } catch (e) {
    if (e.response) {
      return responses.error(e.response.data, e.response.status);
    }
    return responses.error(e);
  }
});

export const getCaseTable = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;
    let { pageIndex, pageSize, siteIds, status, lastUpdatedStart } = body;

    pageIndex = Number(pageIndex) || 0;
    pageSize = Number(pageSize) || 50000;

    const params = {
      [CaseEntityParams.STATUS]: status,
      [CaseEntityParams.PAGE_INDEX]: pageIndex,
      [CaseEntityParams.PAGE_SIZE]: pageSize,
      [CaseEntityParams.LAST_UPDATED_START]: lastUpdatedStart,
    };

    siteIds = siteIds && siteIds.length > 0 ? siteIds : await getSiteIdsFilter(event);

    const authHeader = buildAuthHeader(event);

    const { data, ...rest } = await Analyze.caseTable(siteIds, authHeader, params);

    const nextPage = data && data.length < pageSize ? null : pageIndex + 1;

    return responses.success({ data, nextPage, pageIndex, pageSize, ...rest });
  } catch (e) {
    return responses.error(e);
  }
});

export const getCaseTablePageParams = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;
    let { siteIds, status } = body;

    console.log(`fetching page params for site ids ${siteIds} and status ${status}`);

    const params = {
      [CaseEntityParams.STATUS]: status,
    };

    requireNonNull({ siteIds, status });

    const authHeader = buildAuthHeader(event);

    const result = await Analyze.caseTablePageParams(siteIds, authHeader, params);

    return responses.success(result);
  } catch (e) {
    return responses.error(e);
  }
});

export const getCaseDetails = (event) => {
  const {
    pathParameters: { id },
  } = event;

  console.log(`Getting case details for case ${id}`);

  const authHeader = buildAuthHeader(event);
  return Analyze.caseDetails(id, authHeader)
    .then((result) => responses.success(result))
    .catch((e) => responses.error(e));
};

export const getAssetsCases = async (event) => {
  try {
    const {
      queryStringParameters: { assets: assetsParam, status, includeChildCases },
    } = event;
    console.log(`getAssetsCases query params: assets - ${assetsParam}, status - ${status}`);

    const authHeader = buildAuthHeader(event);

    const assets = assetsParam.split(',');
    const result = await Analyze.assetsCases(assets, status, authHeader, includeChildCases);

    return responses.success(result);
  } catch (e) {
    return responses.error(e);
  }
};

export const getCaseAnalysisTemplate = async (event) => {
  const {
    queryStringParameters: { templateIds: templateIdsParam, assetId },
  } = event;
  const authHeader = buildAuthHeader(event);

  try {
    requireNonNull({ templateIds: templateIdsParam, assetId });
    const templateIds = templateIdsParam.split(',');
    const template = await Analyze.analysisTemplates(templateIds, assetId, authHeader);
    return responses.success(template);
  } catch (e) {
    return responses.error(e);
  }
};

export const getCaseTemplate = async (event) => {
  const {
    queryStringParameters: { id },
  } = event;
  console.log(`getCaseTemplate path params: id - ${id}`);

  const authHeader = buildAuthHeader(event);

  try {
    requireNonNull({ id });
    const template = await Analyze.caseTemplate(id, authHeader);
    return responses.success(template);
  } catch (e) {
    return responses.error(e);
  }
};

export const getCaseTemplateRootCause = async (event) => {
  try {
    const {
      queryStringParameters: { ids },
    } = event;

    console.log(`getCaseTemplateRootCause path params: ids - ${ids}`);

    requireNonNull({ ids });

    const caseTemplateIds = String(ids).split(',');

    const authHeader = buildAuthHeader(event);

    const res = await Analyze.caseTemplateRootCause(caseTemplateIds, authHeader);
    return responses.success(res);
  } catch (e) {
    return responses.error(e);
  }
};

export const getAssetCaseMetrics = async (event) => {
  try {
    const {
      queryStringParameters: { assets: assetsParam },
    } = event;

    requireNonNull(assetsParam);

    console.log(`getAssetCaseMetrics query params: assets - ${assetsParam}`);

    const authHeader = buildAuthHeader(event);

    const assets = assetsParam.split(',');
    const result = await Analyze.assetsCaseMetrics(assets, authHeader);

    return responses.success(result);
  } catch (e) {
    return responses.error(e);
  }
};
