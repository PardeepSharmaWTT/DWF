import { TimeAggr } from '@ge/models/constants';
import { InputEntityType } from '@ge/serverless-models/src/rendigital/enums';

const analyze = require('@ge/mocks-logic/analyze');
const { kpiSiteTableTransformer } = require('@ge/serverless-models/src/rendigital/transformers');
const { Analyze } = require('@ge/serverless-orchestration');
const {
  bodyParserInterceptor,
  buildAuthHeader,
  intercept,
  noMocksInterceptor,
  responses,
  getTenantId,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getSiteById = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
    } = event;

    console.debug(`Getting Site ${id}`);

    const response = analyze.getSiteById(id);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSiteCards = intercept([noMocksInterceptor], async () => {
  try {
    console.debug('Getting site cards');

    const response = analyze.getSiteKpiCards();

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

// TODO: refactor this to move orchestration logic out of serverless so it can
// be consumed across platforms
export const getSitesKpiData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;

    const {
      // assign default params
      entityType = InputEntityType.SITE,
      timeAggr = TimeAggr.DAILY,
      filters,
      filters: { siteIds },
      ...params
    } = body;

    console.debug(
      `Getting KPI data for Sites '${siteIds.join()}' with params '${JSON.stringify(body)}'`,
    );

    const headers = buildAuthHeader(event);
    const tenantId = getTenantId(event);

    const entityIds = entityType === InputEntityType.FLEET ? [tenantId] : siteIds;

    const res = await Analyze.kpi.getKpiData(
      {
        ...params,
        filters,
        entityIds,
        entityType,
        timeAggr,
      },
      headers,
    );

    console.debug('Returning data in response');

    return responses.success(res);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSiteKpiDataByRegion = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
      queryStringParameters: { categories = [] },
    } = event;
    const categoryArray = categories.split(',');

    console.debug(`Getting Site KPI data ${categoryArray.join(', ')} for Region ${id}`);

    const response = analyze.getSiteKpiByRegion(id, categoryArray);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
// TODO No longer being used. Should we delete this?
export const getSiteKpiDataByRegionId = intercept([bodyParserInterceptor], async (event) => {
  try {
    // Region ID
    const {
      body,
      pathParameters: { id },
    } = event;

    if (!id) return responses.error('Missing Site ID');

    console.debug(
      `Getting All Sites data for Region '${id}' with params '${JSON.stringify(body)}'`,
    );

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      entityType = InputEntityType.REGION,
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;
    const entityIds = [id];

    const { data: regionSitesData, errors } = await Analyze.kpi.getKpiData(
      {
        ...params,
        entityIds,
        entityType,
        timeAggr,
      },
      headers,
    );

    // Process Data
    console.debug(`Data processing all Sites in Region: ${id}`);

    const sitesDataProcessed = kpiSiteTableTransformer(regionSitesData);

    // Create Body response of all Region's Sites with data
    console.debug('Returning data in response');

    const response = {
      data: {
        regionId: id,
        sites: Object.values(sitesDataProcessed),
      },
      errors,
    };

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSitesTableKpiData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;

    console.debug(`Getting sites table KPI data with params '${JSON.stringify(body)}'`);

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      // do we need to map incoming type to internal type?
      entityAggr = InputEntityType.SITE,
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;
    // TODO: remove this, it's just a placeholder for now because still required by backend
    // but that is supposed to change since not all calls expect entity ids
    // was told to just pass tenant id along for now
    const entityIds = ['geservdrZp'];
    const entityType = InputEntityType.FLEET;

    const { data: allSitesData, errors } = await Analyze.kpi.getKpiData(
      {
        ...params,
        entityAggr,
        entityIds,
        entityType,
        timeAggr,
      },
      headers,
    );

    console.debug('Returning data in response all sites', JSON.stringify(allSitesData));

    const sitesDataProcessed = kpiSiteTableTransformer(allSitesData);

    // Create Body response of all Region's Sites with data
    console.debug('Returning data in response');

    const response = {
      data: {
        sites: Object.values(sitesDataProcessed),
      },
      errors,
    };

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSitePowerCurveByAsset = (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { start, end },
  } = event;

  requireNonNull({ start, end });

  const { regression } = event.queryStringParameters || {};
  const regressionBool = regression === 'true';
  console.debug(`Getting asset${regressionBool ? ' regression ' : ' '}power curves for site ${id}`);

  const headers = buildAuthHeader(event);

  return Analyze.machineData
    .powerCurveForSite({ headers, siteId: id, startTime: start, endTime: end })
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
};

export const getConditionAggregates = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      body,
      pathParameters: { id },
    } = event;

    console.debug(`Getting condition data for Site '${id}' with params '${JSON.stringify(body)}'`);

    const headers = buildAuthHeader(event);

    const { startDate, endDate, ...params } = body;

    requireNonNull({ startDate, endDate });

    const response = await Analyze.conditionsForEntity({
      ...params,
      endDate,
      entityType: InputEntityType.SITE,
      headers,
      id,
      startDate,
    });

    console.debug('Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSiteSystemLoss = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
    } = event;
    console.debug(`Getting system loss data for Site ${id}`);

    const response = analyze.getSiteSystemLoss(id);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSiteOverview = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
    } = event;
    console.debug(`Getting overview for Site ${id}`);

    const response = analyze.getSiteOverview(id);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSiteMetricChart = intercept([noMocksInterceptor], async () => {
  try {
    console.debug('Getting metric chart for Site');

    const response = analyze.getSiteMetricChart();

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
