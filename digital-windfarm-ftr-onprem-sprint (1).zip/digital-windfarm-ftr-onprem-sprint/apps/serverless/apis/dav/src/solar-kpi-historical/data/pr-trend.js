const prTrend = {
  data: {
    yield: {
      timeSeriesData: [
        {
          date: '2022-05-01',
          value: 100,
        },
        {
          date: '2022-05-01',
          value: 300,
        },
        {
          date: '2022-05-01',
          value: 400,
        },
        {
          date: '2022-05-01',
          value: 600,
        },
        {
          date: '2022-05-01',
          value: 800,
        },
        {
          date: '2022-05-01',
          value: 1000,
        },
        {
          date: '2022-05-01',
          value: 1200,
        },
      ],
      units: 'MWh',
    },
  },
};
module.exports = { prTrend };
