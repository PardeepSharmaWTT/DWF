const availabilityTrend = {
  data: {
    yield: {
      entityData: [
        {
          entity: {
            id: '50004859',
            name: 'INV 001',
          },
          value: 37,
        },
        {
          entity: {
            id: '50002642',
            name: 'INV 002',
          },
          value: 31,
        },
        {
          entity: {
            id: '500111',
            name: 'INV 003',
          },
          value: 30,
        },
        {
          entity: {
            id: '5000404',
            name: 'INV 004',
          },
          value: 38,
        },
        {
          entity: {
            id: '50004823',
            name: 'INV 005',
          },
          value: 60,
        },
        {
          entity: {
            id: '50004400',
            name: 'INV 006',
          },
          value: 51,
        },
        {
          entity: {
            id: '5000387',
            name: 'INV 007',
          },
          value: 46,
        },
        {
          entity: {
            id: '50005119',
            name: 'INV 008',
          },
          value: 57,
        },
        {
          entity: {
            id: '5000326',
            name: 'INV 009',
          },
          value: 39,
        },
        {
          entity: {
            id: '50005183',
            name: 'INV 010',
          },
          value: 43,
        },
        {
          entity: {
            id: '50003842',
            name: 'INV 011',
          },
          value: 55,
        },
        {
          entity: {
            id: '5000567',
            name: 'INV 012',
          },
          value: 57,
        },
        {
          entity: {
            id: '5000277',
            name: 'INV 013',
          },
          value: 35,
        },
        {
          entity: {
            id: '50002979',
            name: 'INV 014',
          },
          value: 41,
        },
        {
          entity: {
            id: '50005240',
            name: 'INV 015',
          },
          value: 48,
        },
        {
          entity: {
            id: '5000314',
            name: 'INV 016',
          },
          value: 49,
        },
        {
          entity: {
            id: '5001085',
            name: 'INV 017',
          },
          value: 46,
        },
        {
          entity: {
            id: '5000303',
            name: 'INV 018',
          },
          value: 43,
        },
        {
          entity: {
            id: '50003238',
            name: 'INV 019',
          },
          value: 37,
        },
        {
          entity: {
            id: '5000852',
            name: 'INV 020',
          },
          value: 33,
        },
        {
          entity: {
            id: '50003405',
            name: 'INV 021',
          },
          value: 39,
        },
        {
          entity: {
            id: '5000513',
            name: 'INV 022',
          },
          value: 44,
        },
        {
          entity: {
            id: '5000542',
            name: 'INV 023',
          },
          value: 59,
        },
        {
          entity: {
            id: '50002703',
            name: 'INV 024',
          },
          value: 60,
        },
        {
          entity: {
            id: '50002205',
            name: 'INV 025',
          },
          value: 38,
        },
        {
          entity: {
            id: '50005140',
            name: 'INV 026',
          },
          value: 36,
        },
        {
          entity: {
            id: '50003307',
            name: 'INV 027',
          },
          value: 39,
        },
        {
          entity: {
            id: '5000832',
            name: 'INV 028',
          },
          value: 49,
        },
        {
          entity: {
            id: '50006159',
            name: 'INV 029',
          },
          value: 54,
        },
        {
          entity: {
            id: '5000863',
            name: 'INV 030',
          },
          value: 59,
        },
      ],
      timeSeriesData: [
        {
          date: '2022-05-01',
          value: 0,
        },
        {
          date: '2022-05-01',
          value: 0,
        },
        {
          date: '2022-05-01',
          value: 0,
        },
        {
          date: '2022-05-01',
          value: 0,
        },
        {
          date: '2022-05-01',
          value: 0,
        },
        {
          date: '2022-05-01',
          value: 0,
        },
        {
          date: '2022-05-01',
          value: 10,
        },
      ],
      units: '%',
    },
  },
};

module.exports = { availabilityTrend };
