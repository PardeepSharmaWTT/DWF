const { intercept, noMocksInterceptor } = require('@ge/serverless-utils/src/interceptor-utils');
const { responses } = require('@ge/serverless-utils/src/serverless-utils');

const { availabilityTrend } = require('./data/availability-trend');
const { capacityFactorTrend } = require('./data/capacity-factor-trend');
const { energyTrend } = require('./data/energy-trend');
const { powerTrend } = require('./data/power-trend');
const { prTrend } = require('./data/pr-trend');
const { weatherTrendChart } = require('./data/weather-trend-chart');
const { yieldData } = require('./data/yield');

export const getkpiSiteHistorical = intercept([noMocksInterceptor], async (event) => {
  try {
    const { kpilist } = JSON.parse(event.body);
    let responseData;
    if (kpilist[0] === 'actualPower' && kpilist[1] === 'irradiance') {
      responseData = JSON.stringify(powerTrend);
      return responses.success(responseData);
    } else if (kpilist[0] === 'energy') {
      responseData = JSON.stringify(energyTrend);
      return responses.success(responseData);
    } else if (kpilist[0] === 'capacityFactor') {
      responseData = JSON.stringify(capacityFactorTrend);
      return responses.success(responseData);
    } else if (kpilist[0] === 'yield') {
      responseData = JSON.stringify(yieldData);
      return responses.success(responseData);
    } else if (kpilist[0] === 'pr') {
      responseData = JSON.stringify(prTrend);
      return responses.success(responseData);
    } else if (kpilist[0] === 'availability') {
      responseData = JSON.stringify(availabilityTrend);
      return responses.success(responseData);
    } else if (
      kpilist[0] === 'POAIrradiance' &&
      kpilist[1] === 'GHI' &&
      kpilist[2] === 'ambTemp' &&
      kpilist[3] === 'moduleTemp' &&
      kpilist[4] === 'windspeed'
    ) {
      responseData = JSON.stringify(weatherTrendChart);
      return responses.success(responseData);
    }
    return responses.success('Invalid Data');
  } catch (err) {
    return responses.error(err);
  }
});
