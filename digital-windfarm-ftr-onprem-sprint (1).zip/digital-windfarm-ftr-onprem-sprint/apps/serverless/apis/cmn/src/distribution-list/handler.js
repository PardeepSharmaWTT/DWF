const { Common } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getDistributionList = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { entityType, entityId, emailType, assetType },
    } = event;
    requireNonNull({ entityType, entityId, emailType });
    const distributionList = await Common.distributionList.getDistributionList({
      headers,
      params: { entityType, entityId, emailType, assetType },
    });

    return responses.success(distributionList);
  } catch (err) {
    return responses.error(err);
  }
};
