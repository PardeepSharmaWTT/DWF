const { Common } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getSiteContact = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { siteId },
    } = event;
    requireNonNull({ siteId });
    const siteContact = await Common.siteContact.getSiteContact({
      headers,
      params: { siteId },
    });
    return responses.success(siteContact);
  } catch (err) {
    return responses.error(err);
  }
};

export const putSiteContact = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      body: data,
      pathParameters: { siteId },
    } = event;
    requireNonNull({ siteId });
    const parsedData = await JSON.parse(data);
    const updatedSiteContact = await Common.siteContact.putSiteContact(headers, siteId, parsedData);
    return responses.success(updatedSiteContact);
  } catch (err) {
    return responses.error(err);
  }
};

export const postSiteContact = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      body: data,
      queryStringParameters: { override },
    } = event;
    const parsedData = await JSON.parse(data);
    const updatedSiteContact = await Common.siteContact.postSiteContact(
      headers,
      override,
      parsedData,
    );
    return responses.success(updatedSiteContact);
  } catch (err) {
    return responses.error(err);
  }
};
