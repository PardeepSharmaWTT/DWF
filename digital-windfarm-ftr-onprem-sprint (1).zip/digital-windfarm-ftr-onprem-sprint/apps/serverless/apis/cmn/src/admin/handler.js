const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  bodyParserInterceptor,
  intercept,
  responses,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getAdminUsers = async (event) => {
  try {
    console.log('getting admin users');
    const headers = buildAuthHeader(event);

    const { pathParameters } = event;

    const { username, firstName, lastName } = pathParameters || {};

    const params = Object.assign(
      {},
      username && { username },
      firstName && { firstName },
      lastName && { lastName },
    );

    const _usersResp = await Common.adminUsers.getUsers({ headers, params });
    return responses.success(_usersResp);
  } catch (err) {
    return responses.error(err);
  }
};

export const updateUser = intercept([bodyParserInterceptor], async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;

    const { username } = data;
    requireNonNull({ username });
    console.log('updating user ' + username);
    const response = await Common.adminUsers.updateUser({ headers, username, data });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const deleteUser = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { username },
    } = event;
    requireNonNull({ username });
    console.log(`deleting user: ${username}`);
    const response = await Common.adminUsers.deleteUser({ headers, params: { username } });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAllTenants = async (event) => {
  try {
    console.log('getting all tenants');
    const headers = buildAuthHeader(event);
    const _tenantResp = await Common.adminUsers.getTenants({ headers });
    return responses.success(_tenantResp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAllRoles = async (event) => {
  try {
    console.log('getting all roles');
    const headers = buildAuthHeader(event);
    const _rolesResp = await Common.adminUsers.getRoles({ headers });
    return responses.success(_rolesResp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAllRolePermissions = async (event) => {
  try {
    console.log('getting all roles and permissions');
    const headers = buildAuthHeader(event);
    const _rolesPermResp = await Common.adminUsers.getRolePermissions({ headers });
    return responses.success(_rolesPermResp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAllLimitedRoles = async (event) => {
  try {
    console.log('getting limited roles');
    const headers = buildAuthHeader(event);
    const _limitedRolesResp = await Common.adminUsers.getLimitedRoles({ headers });
    return responses.success(_limitedRolesResp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAllPeople = async (event) => {
  try {
    console.log('getting all people for infinite scroll');
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { pageIdx, pageSize },
    } = event;

    requireNonNull({ pageIdx, pageSize });
    const response = await Common.adminUsers.getPeople({
      headers,
      pageIdx,
      pageSize,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const createPerson = intercept([bodyParserInterceptor], async (event) => {
  try {
    const headers = buildAuthHeader(event);
    console.log('building event:' + headers);
    const { body: data } = event;
    console.log('data for person:' + JSON.stringify(data));

    requireNonNull({ data });
    const response = await Common.adminUsers.create({
      headers,
      person: data,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getLookupPerson = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { searchId },
    } = event;
    requireNonNull({ searchId });
    console.log(`Look up: ${searchId}`);
    const response = await Common.adminUsers.composePerson({ headers, searchId });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getFetchedPerson = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { username },
    } = event;
    requireNonNull({ username });
    console.log(`Fetch: ${username}`);
    const response = await Common.adminUsers.getPerson({ headers, username });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const patchEditPerson = intercept([bodyParserInterceptor], async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      body,
      pathParameters: { username },
    } = event;
    console.log(`${JSON.stringify(event)}`);
    console.log(`Patched person: ${username}`);
    const response = await Common.adminUsers.editPerson({
      headers,
      username,
      body,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getAuditPerson = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { username },
    } = event;
    requireNonNull({ username });
    console.log(`Fetch audit username: ${username}`);
    const response = await Common.adminUsers.getAuditPerson({ headers, username });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
