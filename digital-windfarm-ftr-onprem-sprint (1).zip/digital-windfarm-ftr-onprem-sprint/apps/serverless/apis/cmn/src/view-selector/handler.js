import { regions } from '@ge/mocks/dist/entities/regions';

const { common } = require('@ge/mocks-logic');
const { EntityApi } = require('@ge/serverless-http');
const { EntityParams, Transformers } = require('@ge/serverless-models');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');
const { byId } = require('@ge/util/array-utils');

// Temporary mock region until the asset service returns region information.
const region0 = regions[0];
const region1 = regions[1];

export const getViewSelectorContents = (event) => {
  console.debug('Getting all sites');

  const headers = buildAuthHeader(event);

  return Promise.all([EntityApi.Sites.getAll(headers)])
    .then(([_sites]) => {
      console.log(`Fetched sites: ${_sites.length}`);

      // Get the mocks for the view selector to mix real data into.
      let viewSelectorMockMix = common.getViewSelector();
      const mockSiteIds = Object.keys(viewSelectorMockMix.entities.sites);

      const mappedSites = Transformers.Site.ofSites(_sites, [
        EntityParams.Site.ID,
        EntityParams.Site.NAME,
        EntityParams.Site.CUSTOMER_ID,
        EntityParams.Site.CUSTOMER_NAME,
      ]).map((site) => {
        // Add real sites to a region that we can disable in the view selector.
        const region = mockSiteIds.includes(site.id) ? region0 : region1;

        return {
          ...site,
          region, // Temporarily assign all sites to a region
        };
      });

      // Mix the real site data in with the existing mocks so that custom views exist.
      viewSelectorMockMix.entities.sites = byId(mappedSites);

      return responses.success(viewSelectorMockMix);
    })
    .catch((e) => responses.error(e));
};
