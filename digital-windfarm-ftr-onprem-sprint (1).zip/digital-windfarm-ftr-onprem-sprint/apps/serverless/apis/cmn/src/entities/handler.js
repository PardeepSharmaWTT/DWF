const { Enums } = require('@ge/serverless-models');
const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  intercept,
  responses,
  segmentTokensInterceptor,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

const { EntityApiType, InputEntityType } = Enums;

export const getWindTurbines = intercept(
  [segmentTokensInterceptor],
  async ({ body, headers, pathParameters, queryStringParameters }) => {
    try {
      console.log('Getting wind turbines');

      const { pageIndex, pageSize, sortDirection, sortMetric } = queryStringParameters || {};
      const { siteId } = pathParameters || {};
      const { segmentTokens } = body;

      let entityType = InputEntityType.TURBINE;
      let params = {};

      if (siteId) {
        console.log(`Getting wind turbines for site ${siteId}`);

        entityType = EntityApiType.TURBINE_BY_SITE;
        params = { siteId };
      }

      const response = await Common.entity.getEntities({
        entityType,
        headers,
        pageIndex,
        pageSize,
        params,
        segmentTokens,
        sortDirection,
        sortMetric,
      });

      console.debug(`Retrieved ${response.length} wind turbines`);

      return responses.success(response);
    } catch (err) {
      return responses.error(err);
    }
  },
);

export const getRegions = async (event) => {
  try {
    console.log('Getting regions');

    const headers = buildAuthHeader(event);
    const response = await Common.entity.getRegions({ headers });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getRocStations = async (event) => {
  try {
    console.log('Getting RocStations in handler');

    const headers = buildAuthHeader(event);
    const response = await Common.entity.getRocStations({ headers });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getSites = intercept([segmentTokensInterceptor], async ({ body, headers }) => {
  try {
    console.log('Getting sites');

    const { segmentTokens } = body;

    const response = await Common.entity.getEntities({
      entityType: InputEntityType.SITE,
      headers,
      segmentTokens,
    });

    console.debug(`Retrieved ${response.length} sites`);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSiteById = intercept(
  [segmentTokensInterceptor],
  async ({ body, headers, pathParameters }) => {
    try {
      const { id } = pathParameters || {};
      const { segmentTokens } = body;

      console.log(`Getting site ${id}`);

      const response = await Common.entity.getEntities({
        entityType: EntityApiType.SITE,
        headers,
        params: { id },
        segmentTokens,
      });

      // might want to look at orchestration supporting returning single entity
      // rather than having to wrap in an array to process
      const site = response[0];

      console.debug('Retrieved site');

      return responses.success(site);
    } catch (err) {
      return responses.error(err);
    }
  },
);

export const getSiteControllers = intercept(
  [segmentTokensInterceptor],
  async ({ body, headers }) => {
    try {
      console.log('Getting site controllers');

      const { segmentTokens } = body;

      const response = await Common.entity.getEntities({
        entityType: InputEntityType.SITE_CONTROLLER,
        headers,
        segmentTokens,
      });

      console.debug(`Retrieved ${response.length} site controllers`);

      return responses.success(response);
    } catch (err) {
      return responses.error(err);
    }
  },
);

export const getSubstations = intercept([segmentTokensInterceptor], async ({ body, headers }) => {
  try {
    console.log('Getting substations');

    const { segmentTokens } = body;

    const response = await Common.entity.getEntities({
      entityType: InputEntityType.SUBSTATION,
      headers,
      segmentTokens,
    });

    console.debug(`Retrieved ${response.length} substations`);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getServiceGroups = async (event) => {
  try {
    console.log('Getting service groups');

    const headers = buildAuthHeader(event);
    const response = await Common.entity.getServiceGroups({ headers });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAssetComponentHierarchy = async (event) => {
  const {
    pathParameters: { assetId },
  } = event;
  try {
    requireNonNull({ assetId });
    console.log('Getting component hierarchy');

    const headers = buildAuthHeader(event);
    const response = await Common.components.getHierarchy({ assetId, headers });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAssetsDataAssignments = async (event) => {
  const headers = buildAuthHeader(event);
  try {
    const {
      // TODO:- In future we will pass only site id to receive assetDataAssignment for all the assets of a site
      queryStringParameters: { assetIds },
    } = event;
    const resp = await Common.machineData.RealtimeValues.getAssetsDataAssignments(
      assetIds.split(','),
      headers,
    );
    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
};
