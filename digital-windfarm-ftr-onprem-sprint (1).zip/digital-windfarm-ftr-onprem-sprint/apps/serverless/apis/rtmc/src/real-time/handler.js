const { mergeDeepWith, concat } = require('ramda');

const { AlertsEntityType, AssetStateHistory } = require('@ge/models/constants');
const { Transformers } = require('@ge/serverless-models');
const { SignalIds, SiteAggregatedSignals } = require('@ge/serverless-models/src/rendigital/enums');
const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  responses,
  getSiteIdsFilter,
  isFulfilled,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getRealTimeValuesForWindTurbine = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { id, make, controllerType, platform },
    } = event;
    requireNonNull({ id });
    const response = await Common.machineData.RealtimeValues.getRealTimeValuesForWindTurbine(
      id,
      make,
      controllerType,
      platform,
      headers,
    );
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getRealTimeEventsForWindTurbine = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { id },
    } = event;

    requireNonNull({ id });
    const response = await Common.machineData.RealtimeValues.getRealTimeEventsForWindTurbine(
      id,
      headers,
    );
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getRealTimeDataForWindTurbine = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
      queryStringParameters: { make, controllerType, platform },
    } = event;

    requireNonNull({ id });
    const response = await Common.machineData.RealtimeValues.getRealTimeDataForAsset(
      id,
      make,
      controllerType,
      platform,
      headers,
    );
    // console.log(response);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getRealTimeDataForSiteController = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
      queryStringParameters: { make, controllerType, platform },
    } = event;

    requireNonNull({ id });
    const response = await Common.machineData.RealtimeValues.getRealTimeDataForSiteController(
      id,
      make,
      controllerType,
      platform,
      headers,
    );
    // console.log(response);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getRealTimeDataForSubstation = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
    } = event;
    requireNonNull({ id });
    const response = await Common.machineData.RealtimeValues.getRealTimeDataForSubstation(
      id,
      headers,
    );
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

// TODO: look into taking site id here instead of list of asset ids
// i believe ge said they might support getting real time data by site id
export const getRealTimeValuesForSite = async (event) => {
  try {
    console.debug('Getting real time values for site');

    const {
      body: data,
      pathParameters: { id: siteId },
    } = event;

    const { assetIds } = JSON.parse(data);

    console.debug(`Getting values for assets :: '${assetIds}'`);

    const headers = buildAuthHeader(event);

    // MACHINEDATA API NO LONGER SENDS THE TURBINE STATUS.
    // HAVE TO USE STATETRASLATIONSERVICE TO FETCH THE CURRENT STATUS AND THE LAST STATE

    // 1. Call aggregatedApi to fetch the site temp + site windspeed
    // 2. Call machinedataApi to fetch the speed and power for all assets
    // 3. Call alertsApi to fetch alerts for all assets
    // 4. Call aggregatedApi to fetch the connection status for all Assets
    // 5. Call stateTranslationServiceApi to fetch the Assets status along with the last state.

    // #TODO: Merge 1 and 4 into a single call in next release

    const [
      aggregatedResp,
      assetsResp,
      alertsResp,
      conncStatusResp,
      turbStatusResp,
    ] = await Promise.allSettled([
      Common.machineData.RealtimeValues.getRealTimeDataForAggregatedSignals(
        [siteId],
        headers,
        [SiteAggregatedSignals.TEMP, SiteAggregatedSignals.WIND_SPEED],
        {
          POWER: { to: ['temp'], from: [SiteAggregatedSignals.TEMP, 'value'] },
          WIND_SPEED: { to: ['wind'], from: [SiteAggregatedSignals.WIND_SPEED, 'value'] },
        },
      ),
      Common.machineData.RealtimeValues.getRealTimeValuesForSignals(
        // hard-coding signals expected at site level for now, can make this more dynamic
        {
          assetIds,
          signals: [SignalIds.Speed, SignalIds.Power],
        },
        headers,
      ),
      Common.monitorAlerts.getAlerts(headers, { siteId, assetType: AlertsEntityType.WIND_TURBINE }),
      Common.machineData.RealtimeValues.getConnectionStatusForAssets([siteId], headers),
      Common.machineData.RealtimeValues.getTurbineStatusFromSiteIds(
        [siteId],
        headers,
        AssetStateHistory.PREVIOUS_STATE,
      ),
    ]);

    const response = { site: {}, assets: {} };
    if (isFulfilled(aggregatedResp)) {
      response.site = aggregatedResp.value.length ? aggregatedResp.value[0] : {};
    }
    // Creating default empty asset object for all assetIds
    let defaultAssetsResp = {};
    if (assetIds.length) {
      assetIds.forEach((assetId) => {
        defaultAssetsResp = { ...defaultAssetsResp, [assetId]: {} };
      });
    }
    response.assets =
      isFulfilled(assetsResp) && Object.keys(assetsResp.value).length
        ? assetsResp.value
        : defaultAssetsResp;
    if (isFulfilled(alertsResp) && Array.isArray(alertsResp.value)) {
      const assetAlerts = alertsResp.value.filter(
        (itr) => itr.siteId === siteId && itr.assetType === AlertsEntityType.WIND_TURBINE,
      );
      response.assets = Transformers.RealTime.Sites.fuseAlertsResponseForRealTimeValuesOfSite(
        assetAlerts,
        response,
      );
    }

    // console.debug(conncStatusResp);
    if (isFulfilled(conncStatusResp)) {
      const merged = mergeDeepWith(concat, response.assets, conncStatusResp.value || {});
      response.assets = merged;
    }

    // console.debug(turbStatusResp);
    if (isFulfilled(turbStatusResp)) {
      const merged = mergeDeepWith(concat, response.assets, turbStatusResp.value || {});
      response.assets = merged;
    }

    Object.keys(response.assets).map(
      (as) =>
        (response.assets[as] = Transformers.RealTime.Signals.checkTurbineStatusTSForNoComm(
          response.assets[as],
        )),
    );

    // console.log(response);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getRealTimeDataForSites = async (event) => {
  const headers = buildAuthHeader(event);
  const siteIds = await getSiteIdsFilter(event);
  console.log(' selected siteIds are ', siteIds.join(','));
  try {
    const resp = await Common.machineData.RealtimeValues.getRealTimeDataForMonitorSites(
      siteIds,
      headers,
    );
    // console.debug(resp);
    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
};
