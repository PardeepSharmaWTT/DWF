const { Monitor } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

const defaultControllerType = 'Mark VI';

export const getROCActionTakenOptions = async (event) => {
  try {
    const {
      queryStringParameters: { controllerType, assetType },
    } = event;

    console.log('Trying to fetch ROC Action Taken Options');
    const response = await Monitor.ROCActionLog.getROCActionTakenOptions({
      controllerType: controllerType || defaultControllerType,
      assetType,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const createROCActionLog = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const parsedData = JSON.parse(data);
    const { caseId, assetType, siteId, type, eventCode } = parsedData;

    requireNonNull({ caseId, assetType, siteId, type, eventCode });
    console.log('Trying to create ROC Action Log');
    const response = await Monitor.ROCActionLog.createROCActionLog({
      headers,
      data: parsedData,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
