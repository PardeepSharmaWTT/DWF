const { Common } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');

export const getTurbineFailedStatus = async ({ headers, queryStringParameters }) => {
  const { assetIds, includeFields, idType } = queryStringParameters;
  try {
    const _headers = buildAuthHeader({ headers });
    if (idType) {
      console.log('Getting turbine Causal Response data');
      const _params = {
        assetIds: assetIds,
        includeFields: includeFields,
        idType: idType,
      };
      const response = await Common.tasks.getTurbineActiveStatus({
        headers: _headers,
        params: _params,
      });
      return responses.success(response);
    }
    console.log('Getting turbine failed Status data');
    const _params = {
      assetIds: assetIds,
      includeFields: includeFields,
    };
    const response = await Common.tasks.getTurbineFailedStatus({
      headers: _headers,
      params: _params,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
