const { Monitor } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  getSitesFilter,
  responses,
  intercept,
  noMocksInterceptor,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getCaseQueue = intercept([noMocksInterceptor], async (event) => {
  const sitesToFilterOn = await getSitesFilter(event);
  const siteIds = sitesToFilterOn.map((site) => site.id);
  const headers = buildAuthHeader(event);
  let casesQueue;
  try {
    const {
      queryStringParameters: { pageSize, pageNumber, status, filterType },
    } = event;
    requireNonNull({ pageSize, pageNumber, status });
    console.log('Trying to fetch Monitor Case Queue');
    casesQueue = await Monitor.cases.casesQueue({
      pageSize,
      pageNumber,
      status,
      filterType,
      siteIds,
      headers,
    });
    return responses.success(casesQueue);
  } catch (err) {
    return responses.error(err.message);
  }
});

export const changeMonitorCasesStatus = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const parsedData = JSON.parse(data);

    requireNonNull({ parsedData });
    console.log('Trying to change Monitor Case Status');
    const response = await Monitor.cases.changeMonitorCasesStatus({
      headers,
      data: parsedData,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const editMonitorCasesQueue = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const parsedData = JSON.parse(data);

    requireNonNull({ parsedData });
    console.log('Trying to edit Monitor Case Queue');
    const response = await Monitor.cases.editMonitorCasesQueue({
      headers,
      data: parsedData,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAssetCases = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id: assetId },
      queryStringParameters: { page, pageSize, status, days },
    } = event;
    requireNonNull({ status, assetId });
    console.log('Trying to fetch asset cases');
    const assetCases = await Monitor.cases.getAssetCases({
      headers,
      params: {
        page,
        pageSize,
        status,
        assetId,
        days,
      },
    });
    return responses.success(assetCases);
  } catch (err) {
    return responses.error(err);
  }
};

export const getActiveCaseCount = async (event) => {
  try {
    const sitesToFilterOn = await getSitesFilter(event);
    const siteIds = sitesToFilterOn.map((site) => site.id);
    const headers = buildAuthHeader(event);

    console.log('Trying to fetch cases count based on filterType');
    const caseCountResp = await Monitor.cases.getActiveCaseCount({
      headers,
      params: {
        siteIds,
      },
    });
    return responses.success(caseCountResp);
  } catch (err) {
    return responses.error(err);
  }
};
