const { graphQl } = require('@ge/models/constants');
const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  intercept,
  bodyParserInterceptor,
  responses,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getAssetAllEvents = intercept([bodyParserInterceptor], async ({ headers, body }) => {
  requireNonNull(headers);
  requireNonNull(body);
  try {
    const _headers = buildAuthHeader({ headers });
    console.debug('Getting Asset All Events');
    const assetId = body;
    let response = [];
    try {
      console.debug('with assetId- >', assetId.body);
      if (assetId.body !== false) {
        const _params = {
          query: graphQl.GET_ALL_EVENTS.replace('___', assetId.body),
        };
        console.debug('body->', _params);
        response = await Common.tasks.getAllAplicableEvents({
          headers: _headers,
          params: _params,
        });
      }
    } catch (e) {
      console.log(e);
    }
    return responses.success(response);
  } catch (err) {
    console.log(err.messege);
    return responses.error(err);
  }
});
