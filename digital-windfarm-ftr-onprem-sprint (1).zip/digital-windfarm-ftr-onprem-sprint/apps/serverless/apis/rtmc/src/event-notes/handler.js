const { is } = require('ramda');

const { Monitor } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getEventNotes = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { pageSize, pageIndex, id },
    } = event;

    requireNonNull({ pageIndex, pageSize, id });
    const response = await Monitor.eventNotes.getEventNotes({
      headers,
      pageIndex,
      pageSize,
      id,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const addEventNote = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const parsedData = JSON.parse(data);
    const { domainId, note } = parsedData;

    requireNonNull({ domainId, note });
    const response = await Monitor.eventNotes.addEventNote({
      headers,
      data: parsedData,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const editEventNote = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
      body: data,
    } = event;
    const parsedData = JSON.parse(data);

    requireNonNull({ id, parsedData });
    const response = await Monitor.eventNotes.editEventNote({
      headers,
      id,
      data: parsedData,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const deleteEventNote = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
    } = event;
    requireNonNull({ id });
    const response = await Monitor.eventNotes.deleteEventNote({
      headers,
      id,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const escalateCase = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const { files, payload } = is(String, data) ? JSON.parse(data) : {};
    const parsedData = payload ? JSON.parse(payload) : {};
    const { caseId } = parsedData;
    requireNonNull({ caseId });
    const response = await Monitor.eventNotes.escalateCase({
      headers,
      data: parsedData,
      files,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const bulkEscalateCase = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const { files, payload } = is(String, data) ? JSON.parse(data) : {};
    const parsedData = payload ? JSON.parse(payload) : {};
    const { caseDetails } = parsedData;
    requireNonNull({ caseDetails });
    const response = await Monitor.eventNotes.bulkEscalateCase({
      headers,
      data: parsedData,
      files,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
