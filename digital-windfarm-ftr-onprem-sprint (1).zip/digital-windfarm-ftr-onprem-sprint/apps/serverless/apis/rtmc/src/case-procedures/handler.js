const { Monitor } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  responses,
  isFulfilled,
  createErrorObject,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');
// FHP: @request: {assetId: assetId, eventCodeId: eventCodeId}
export const getCaseProcForEventByAsset = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { assetId },
      queryStringParameters: { eventCodeId },
    } = event;
    requireNonNull({ assetId, eventCodeId });
    const eventConfigMap = await Monitor.CaseProcedure.getEventMapByAssetId(headers, assetId);
    if (!eventConfigMap) {
      console.log('No Event config data on the provided assetId');
      return responses.success({}, 204);
    }
    const eventMapId = eventConfigMap.eventMapId;
    const procId = await Monitor.CaseProcedure.getProcByEventIdMap(
      headers,
      eventMapId,
      eventCodeId,
    );
    if (!procId) {
      console.log('No case procedure id attached to provided eventCodeId');
      return responses.success({}, 204);
    }
    const [caseProcedures, linkedEvents] = await Promise.allSettled([
      Monitor.CaseProcedure.getCaseProcedureByProcId(headers, procId),
      Monitor.CaseProcedure.getEventsByprocId(headers, procId),
    ]);
    const resObj = {};
    if (isFulfilled(caseProcedures)) {
      resObj.procId = caseProcedures.value.procId;
      resObj.title = caseProcedures.value.title;
      resObj.desc = caseProcedures.value.desc;
    }
    if (!resObj.title) {
      console.log('No case procedure data on the provided procId');
      return responses.success(resObj, 204);
    }
    if (isFulfilled(linkedEvents)) {
      resObj.associatedEvents = linkedEvents.value;
    }
    return responses.success(resObj);
  } catch (err) {
    return responses.error(createErrorObject(err));
  }
};
