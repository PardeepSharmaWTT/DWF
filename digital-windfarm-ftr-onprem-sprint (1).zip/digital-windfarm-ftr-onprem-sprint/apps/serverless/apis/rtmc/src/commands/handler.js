// TODO: commenting mock logic imports for now
// import Chance from 'chance';
// import dayjs from 'dayjs';

// import { AssetCommandStatus, AssetCommand } from '@ge/models/constants';
// import { DateTimeFormats } from '@ge/models/constants';
import { requireNonNull } from '@ge/util/object-utils';

const { Monitor } = require('@ge/serverless-orchestration');
const {
  intercept,
  noMocksInterceptor,
  bodyParserInterceptor,
  responses,
  buildAuthHeader,
} = require('@ge/serverless-utils');

// eslint-disable-next-line new-cap
// const chance = Chance();

export const getCommandsList = intercept([noMocksInterceptor], async (event) => {
  try {
    const { body: data } = event;
    const parsedData = JSON.parse(data);
    const { assets } = parsedData;
    requireNonNull(assets);
    const response = await Monitor.commands.getCommandsList({ assets });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getCommandsStatus = async ({ headers, pathParameters, queryStringParameters }) => {
  try {
    console.log('Trying to get command execution status');
    const finalHeader = buildAuthHeader({ headers });
    const { id: commandId } = pathParameters || {};
    const { isGroup = 'false' } = queryStringParameters || {};
    requireNonNull(commandId);
    const response =
      isGroup === 'true'
        ? await Monitor.commands.getGroupCommandsStatus({ headers: finalHeader, commandId })
        : await Monitor.commands.getCommandsStatus({ headers: finalHeader, commandId });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const postCommands = intercept([bodyParserInterceptor], async ({ body, headers }) => {
  try {
    const finalHeader = buildAuthHeader({ headers });
    const { assets, command } = body;
    const response = await Monitor.commands.sendCommands({ headers: finalHeader, assets, command });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const commandSafetyCheck = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { assetIds },
      pathParameters: { siteId: siteId },
    } = event;
    requireNonNull({ siteId, assetIds });
    const response = await Monitor.commands.commandSafetyCheck({ headers, siteId, assetIds });
    console.log(response);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const abortCommands = async ({ headers, pathParameters }) => {
  try {
    console.log('Trying to abort group command execution');
    const finalHeader = buildAuthHeader({ headers });
    const { id: commandId } = pathParameters || {};
    requireNonNull(commandId);
    const response = await Monitor.commands.abortCommands({ headers: finalHeader, commandId });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAssetHistory = intercept(
  [noMocksInterceptor],
  async ({ headers, pathParameters, queryStringParameters }) => {
    const authHeaders = buildAuthHeader({ headers });
    try {
      console.log('Trying to get command execution history');
      const { siteId } = pathParameters || {};
      const { assetId, make, controllerType, platform } = queryStringParameters || {};
      requireNonNull(siteId, assetId);
      const response = await Monitor.commands.getCommandHistory({
        headers: authHeaders,
        siteId,
        assetId,
        make,
        controllerType,
        platform,
      });
      return responses.success(response);
    } catch (err) {
      return responses.error(err);
    }
  },
);
