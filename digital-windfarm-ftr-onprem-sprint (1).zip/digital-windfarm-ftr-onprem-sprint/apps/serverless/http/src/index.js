const Rendigital = require('./rendigital');

module.exports = Rendigital;
