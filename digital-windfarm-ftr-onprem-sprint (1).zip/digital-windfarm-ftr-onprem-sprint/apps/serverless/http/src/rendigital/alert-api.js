const { splitEvery } = require('ramda');

const { Enums } = require('@ge/serverless-models');
const { svcGetWithBaseURL } = require('@ge/serverless-utils');

const ALERTS_BY_ID = '/diagnostics/v1/alerts/id';
const BASE_URL = process.env.FS_DEV_BASE_URL;

const { CaseEntityParams } = Enums;

const PARAMS = {
  forAlertIds: (ids) => ({ [CaseEntityParams.ALERT_IDS]: ids.join(',') }),
};

const _getAlertById = (headers) => (alertId) =>
  svcGetWithBaseURL(`${ALERTS_BY_ID}/${alertId}`, BASE_URL, { headers });

const getAlertById = (alertId, headers) => _getAlertById(headers)(alertId);

// Alert api accepts multiple alert ids. Max of 100 alert ids can be sent at a time
const getAlertsByIds = (alertIds, headers) => {
  if (!alertIds.length) return Promise.resolve([]);
  const chunked = splitEvery(100, alertIds);
  const promises = chunked.map((ids) =>
    svcGetWithBaseURL(ALERTS_BY_ID, BASE_URL, {
      headers,
      params: PARAMS.forAlertIds(ids),
    }),
  );
  return Promise.all(promises).then((arr) =>
    arr.reduce((acc, resp) => acc.concat(resp.alerts), []),
  );
};

module.exports = {
  getById: getAlertById,
  getByIds: getAlertsByIds,
};
