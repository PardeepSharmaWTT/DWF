const dayjs = require('dayjs');

const {
  commands: CommandProps,
  AssetCommandStatus,
  CaseType,
  AssetCommandDetails,
  CustomEventRefreshCommand,
} = require('@ge/models/constants');
const { svcGet, svcPost } = require('@ge/serverless-utils');

const BASE = '/assetmgmt/v1';
const COMMANDS = '/monitor/v1/command';
const GROUP_COMMANDS = '/monitor/v1/command/group';
const GET_COMMANDS = '/monitor/v1/command-details';
const GROUP_GET_COMMANDS = '/monitor/v1/command-details/group';
const COMMAND_SAFETY_CHECK = '/monitor/v1/command-safety-check';
const ABORT_COMMANDS = '/monitor/v1/command/group/cancel';
const COMMAND_MAPS = `${BASE}/command-maps`;
const ADAPTER_CONFIG = `${BASE}/adapter-config`;
const COMMAND_HISTORY = '/monitor/v1/command-logs';
const COMMAND_HISTORY_COUNT = `${COMMAND_HISTORY}/count`;
const CASE_HISTORY_COUNT = '/monitor/v1/cases/count-details';

const CaseTypeMap = [
  CaseType.UNKNOWN,
  CaseType.FLAGGED,
  CaseType.FAULTED,
  CaseType.SITE_NO_COMM,
  CaseType.FLEET_NO_COMM,
  CaseType.STOPPED,
  CaseType.EXTERNAL_API,
  CaseType.ASSET_NO_COMM,
  CaseType.BOP_BREAKER,
];

const requiredHeaders = {
  ['Content-Type']: 'application/json',
};

const signalMapByMapIdAndSourceId = (signalMapId, sourceId) =>
  `${BASE}/signal-maps/${signalMapId}/signals/${sourceId}`;

const commandSignalsByMapId = (signalMapId) => `${COMMAND_MAPS}/${signalMapId}/signals/`;

const adapterConfigByName = (name) => `${ADAPTER_CONFIG}/${name}`;

const adapterConnDetailsByName = (name) => `${ADAPTER_CONFIG}/${name}/adapterConnectionDetails`;

const getCmdCategory = (cmdName) => {
  if (cmdName === CustomEventRefreshCommand.canId) {
    return AssetCommandDetails.Category.ONDEMANDDATA;
  }
  return AssetCommandDetails.Category.CONTROLCOMMAND;
};

const getCmdSubCategory = (cmdName) => {
  if (cmdName === CustomEventRefreshCommand.canId) {
    return AssetCommandDetails.SubCategory.EVENTDATA;
  }
  return '';
};

const getRequestBody = ({ assets, cmdName, isGroup = false }) => {
  if (!isGroup) {
    // Return the below payload incase of single command
    return {
      timestamp: dayjs().valueOf(),
      cmd: [
        {
          siteId: assets[0].siteId,
          turbineId: assets[0].turbineId,
          cmdName: cmdName,
          value: CommandProps.VALUE,
          cmdType: CommandProps.MANUAL,
          Category: getCmdCategory(cmdName),
          SubCategory: getCmdSubCategory(cmdName),
        },
      ],
    };
  }

  // Return the below request payload for Group Commands i.e isGroup === false
  return {
    timestamp: dayjs().valueOf(),
    cmdType: CommandProps.MANUAL,
    delayInSec: CommandProps.GROUP_DELAY_SEC,
    cmdList: assets.map((element) => {
      return {
        cmdNo: element.cmdNo,
        siteId: element.siteId,
        turbineId: element.turbineId,
        cmdName: cmdName,
        value: CommandProps.VALUE,
      };
    }),
  };
};

const formCommandHistoryParams = (siteId, assetId, days = 7) => {
  const startTime = dayjs()
    .subtract(days, 'd')
    .valueOf();
  const endTime = dayjs().valueOf();
  return {
    fields: 'cmdName,cmdStatus,timestamp,cmdSendTime',
    // Need only recent 10 records
    pageSize: 10,
    sortBy: 'cmdSendTime',
    query: `startTime=${startTime}&endTime=${endTime}&siteId=${siteId}&turbineId=${assetId}`,
  };
};

const formCommandHistoryCountParams = (siteId, assetId, days, cmdStatus) => {
  const startTime = dayjs()
    .subtract(days, 'd')
    .valueOf();
  const endTime = dayjs().valueOf();
  return {
    // Need only success commands for now
    query: `startTime=${startTime}&endTime=${endTime}&siteId=${siteId}&turbineId=${assetId}&cmdStatus=${cmdStatus}`,
  };
};

const formCaseHistoryCountParams = (siteId, assetId, days, type) => {
  const startTime = dayjs()
    .subtract(days, 'd')
    .valueOf();
  const endTime = dayjs().valueOf();
  return {
    groupBy: 'state,assetId',
    query: `startTime=${startTime}&endTime=${endTime}&siteId=${siteId}&assetId=${assetId}&type=${type}`,
  };
};

const getSendCommandURL = ({ isGroup = false }) => (isGroup ? GROUP_COMMANDS : COMMANDS);

const getAllCommandMaps = (headers) =>
  svcGet(COMMAND_MAPS, {
    headers: { ...headers, ...requiredHeaders },
  });

const _getCommandSignalsByMapId = (headers) => (mapId) =>
  svcGet(commandSignalsByMapId(mapId), {
    headers: { ...headers, ...requiredHeaders },
  });

const getCommandSignalsByMapId = (headers, mapId) => _getCommandSignalsByMapId(headers)(mapId);

const getSignalMapByMapIdAndSignalId = (headers, mapId, signalId) =>
  svcGet(signalMapByMapIdAndSourceId(mapId, signalId), {
    headers: { ...headers, ...requiredHeaders },
  });

const getAdapterConfig = (headers) =>
  svcGet(ADAPTER_CONFIG, {
    headers: { ...headers, ...requiredHeaders },
  });

const getAdapterConfigByAdapterName = (headers, adapterName) =>
  svcGet(adapterConfigByName(adapterName), {
    headers: { ...headers, ...requiredHeaders },
  });

const getAdapterConnDetailsByAdpterName = (headers, adapterName) =>
  svcGet(adapterConnDetailsByName(adapterName), {
    headers: { ...headers, ...requiredHeaders },
  });

const postCommand = (headers, config) => {
  return svcPost(getSendCommandURL(config), getRequestBody(config), {
    headers: { ...headers, ...requiredHeaders },
  });
};

const postCmnSafetyCheck = (headers, params) => {
  return svcPost(COMMAND_SAFETY_CHECK, params, {
    headers: { ...headers, ...requiredHeaders },
  });
};

const getCommandStatus = (headers, cmdUID, isGroup = false) => {
  return svcGet(isGroup ? GROUP_GET_COMMANDS : GET_COMMANDS, {
    headers: { ...headers, ...requiredHeaders },
    params: { commandId: cmdUID },
  });
};

const abortCommands = (headers, cmdUID) => {
  return svcGet(ABORT_COMMANDS, {
    headers: { ...headers, ...requiredHeaders },
    params: { commandId: cmdUID },
  });
};

const getCommandsHistory = (headers, siteId, assetId, days) => {
  return svcGet(COMMAND_HISTORY, {
    headers: { ...headers, ...requiredHeaders },
    params: formCommandHistoryParams(siteId, assetId, days),
  });
};

const getCommandsHitoryCount = (
  headers,
  siteId,
  assetId,
  days,
  cmdStatus = AssetCommandStatus.SUCCESS,
) => {
  return svcGet(COMMAND_HISTORY_COUNT, {
    headers: { ...headers, ...requiredHeaders },
    params: formCommandHistoryCountParams(siteId, assetId, days, cmdStatus),
  });
};

const getCaseHistoryCount = (
  headers,
  siteId,
  assetId,
  days,
  type = CaseTypeMap.indexOf(CaseType.FAULTED),
) => {
  return svcGet(CASE_HISTORY_COUNT, {
    headers: { ...headers, ...requiredHeaders },
    params: formCaseHistoryCountParams(siteId, assetId, days, type),
  });
};

const commands = {
  getAllCommandMaps,
  getCommandSignalsByMapId,
  getSignalMapByMapIdAndSignalId,
  getAdapterConfig,
  getAdapterConfigByAdapterName,
  getAdapterConnDetailsByAdpterName,
  postCommand,
  getCommandStatus,
  postCmnSafetyCheck,
  abortCommands,
  getCommandsHistory,
  getCommandsHitoryCount,
  getCaseHistoryCount,
};

module.exports = {
  commands,
};
