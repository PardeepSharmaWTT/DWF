const { svcGet } = require('@ge/serverless-utils');

const SERVICE_URL = '/diagnostics/v1/analysis/fusion';

const PARAMS = {
  forAnalysisTemplateIds: (templateIds, assetId) => ({
    analysisTemplateIds: templateIds.join(','),
    assetId,
  }),
};

const getAnalysisTemplates = (templateIds, assetId, headers) =>
  svcGet(SERVICE_URL, { headers, params: PARAMS.forAnalysisTemplateIds(templateIds, assetId) });

module.exports = {
  getByIds: getAnalysisTemplates,
};
