const { svcPost, svcGet, svcPatch } = require('@ge/serverless-utils');

const URLS = {
  dispatchEndPoint: '/manage/v1/mobile-assignment/dispatch',
};

const postMtmDispatchData = (dispatchDetails, headers) =>
  svcPost(URLS.dispatchEndPoint, dispatchDetails, { headers }, 'service');

const getDispatchedData = (headers, params) => svcGet(URLS.dispatchEndPoint, { headers, params });

const patchDispatchData = (headers, id, planChange) =>
  svcPatch(URLS.dispatchEndPoint + '/' + id, planChange, { headers }, 'service');

const Dispatch = {
  postMtmDispatchData: postMtmDispatchData,
  getDispatchedData: getDispatchedData,
  patchDispatchData: patchDispatchData,
};

module.exports = { Dispatch };
