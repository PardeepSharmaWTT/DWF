const { svcPost, svcGet } = require('@ge/serverless-utils');

// TODO : Move all Url's to common file after PR https://github.build.ge.com/REN-AWS/digital-windfarm/pull/1747 is merged to ftr-develop
const URLS = {
  notification: '/common/v1/email-notification',
  template: '/common/v1/email-template',
};

const sendNotification = (requestBody, headers) => {
  return svcPost(URLS.notification, requestBody, {
    headers,
  });
};

const getEmailTemplate = (namespace, sourceId, headers) => {
  return svcGet(URLS.template, {
    params: { namespace, sourceId },
    headers,
  });
};

const Email = {
  sendNotification,
};

const Template = {
  getEmailTemplate,
};

module.exports = {
  Email,
  Template,
};
