const asyncPool = require('tiny-async-pool');

const { svcGet } = require('@ge/serverless-utils');

const BASE = '/assetmgmt/v1';
const DATA_ASSIGNMENTS = `${BASE}/asset-data-assignments/`;
const COMPONENT_HIERARCHY = `${BASE}/component-hierarchies`;

const requiredHeaders = {
  ['Content-Type']: 'application/json',
};

const SignalIds = {
  CANONICAL: 'canonicalSignalId',
  NON_CANONICAL: 'sourceSignalId',
};

const signalMapById = (signalId) => `${BASE}/signal-maps/${signalId}/signals/`;
const eventByIds = `${BASE}/events/search`;

const PARAMS = {
  dataAssigmentForAsset: (assetId) => ({
    assetId: assetId,
  }),
};

const FHPARAMS = {
  dataAssigmentForAsset: (assetId) => ({
    assetId: assetId,
    dataMode: 'realtime',
  }),
};

const _getDataAssignmentForAsset = (headers) => (assetId) =>
  svcGet(DATA_ASSIGNMENTS, {
    headers: { ...headers, ...requiredHeaders },
    params: PARAMS.dataAssigmentForAsset(assetId),
  });

const getFHPDataForAsset = (headers, assetId) =>
  svcGet(DATA_ASSIGNMENTS, {
    headers: { ...headers, ...requiredHeaders },
    params: FHPARAMS.dataAssigmentForAsset(assetId),
  });

const getDataAssignmentForAsset = (headers, assetId) =>
  _getDataAssignmentForAsset(headers)(assetId);

const getDataAssignmentsForAssets = (assetIds, headers) =>
  asyncPool(20, assetIds, _getDataAssignmentForAsset(headers));

const _getSignalMappingById = (headers) => (signalId) =>
  svcGet(signalMapById(signalId), { headers: { ...headers, ...requiredHeaders } }).then((data) =>
    data
      .filter((d) => !!d.sourceSignalName)
      .map((d) => ({
        ...d,
        signalType: d[SignalIds.CANONICAL] ? SignalIds.CANONICAL : SignalIds.NON_CANONICAL,
      })),
  );

const getEventsInfo = (eventIds, headers) => {
  const ids = eventIds.join(',');
  return svcGet(eventByIds, {
    headers: { ...headers, ...requiredHeaders },
    params: {
      query: `eventId=in=(${ids})`,
    },
  });
};

const getSignalMappingsById = (signalIds = [], headers) =>
  asyncPool(20, signalIds, _getSignalMappingById(headers));

const getComponentHierarchy = (hierarchyId, headers) =>
  svcGet(`${COMPONENT_HIERARCHY}/${hierarchyId}`, { headers: { ...headers, ...requiredHeaders } });

const Asset = {
  getDataAssignment: getDataAssignmentForAsset,
};

const Assets = {
  getDataAssignments: getDataAssignmentsForAssets,
};

const Component = {
  getHierarchy: getComponentHierarchy,
};

const Events = {
  getEventsInfo,
};

const FHP = {
  getFHPDataForAsset,
};

module.exports = {
  Asset,
  Assets,
  Component,
  getSignalMappingsById,
  Events,
  FHP,
};
