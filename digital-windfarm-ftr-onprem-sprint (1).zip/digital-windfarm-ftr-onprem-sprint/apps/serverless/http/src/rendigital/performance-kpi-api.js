const { KpiCategoryDefs } = require('@ge/models/constants');
const { KpiSubType } = require('@ge/serverless-models/src/rendigital/enums');
const { kpiRequestTransformer } = require('@ge/serverless-models/src/rendigital/transformers');
const { svcPost } = require('@ge/serverless-utils');

const BASE_URL = process.env.FS_DEV_BASE_URL;
const SERVICE_URL = '/performance/production-metrics/v1';

const endpointDict = {
  [KpiCategoryDefs.ACTUAL_PRODUCTION]: `${SERVICE_URL}/actual-production`,
  [KpiCategoryDefs.CAPACITY_FACTOR]: `${SERVICE_URL}/capacity-factor`,
  [KpiCategoryDefs.PRODUCTION_ACTUAL]: `${SERVICE_URL}/actual-production`,
  [KpiCategoryDefs.PRODUCTION_EXPECTED_CONTRACT]: `${SERVICE_URL}/expected-production?kpiSubType=${KpiSubType.CONTRACT}`,
  [KpiCategoryDefs.PRODUCTION_EXPECTED_LEARNED]: `${SERVICE_URL}/expected-production?kpiSubType=${KpiSubType.LEARNED}`,
  [KpiCategoryDefs.PRODUCTION_LOST_CONTRACT]: `${SERVICE_URL}/lost-production?kpiSubType=${KpiSubType.CONTRACT}`,
  [KpiCategoryDefs.PRODUCTION_LOST_LEARNED]: `${SERVICE_URL}/lost-production?kpiSubType=${KpiSubType.LEARNED}`,
  // production ratio is currently not written on backend
  [KpiCategoryDefs.PRODUCTION_RATIO]: `${SERVICE_URL}/performance/production-ratio`,
  [KpiCategoryDefs.UNPRODUCED_ENERGY_CONTRACT]: `${SERVICE_URL}/unproduced-energy?kpiSubType=${KpiSubType.CONTRACT}`,
  [KpiCategoryDefs.UNPRODUCED_ENERGY_LEARNED]: `${SERVICE_URL}/unproduced-energy?kpiSubType=${KpiSubType.LEARNED}`,
};

// the params are agnostic of a specific endpoint/implementation so that we
// can swap out endpoints dynamically based on deployment, not sure how easy that will be in practice
const getKpiData = ({ category, ...params }, headers) => {
  const endpoint = endpointDict[category];

  console.debug(`Calling endpoint '${endpoint}'`);

  const body = kpiRequestTransformer(params);

  return svcPost(endpoint, body, {
    baseURL: BASE_URL,
    headers,
  });
};

module.exports = {
  getKpiData,
};
