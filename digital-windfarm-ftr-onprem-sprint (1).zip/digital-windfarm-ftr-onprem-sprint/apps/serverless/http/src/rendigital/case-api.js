const dayjs = require('dayjs');
const asyncPool = require('tiny-async-pool');

const {
  MonitorCaseStateMapping,
  CaseTypeMapping,
  AlertsEntityType,
} = require('@ge/models/constants');
const { EntityParams, Transformers, Enums } = require('@ge/serverless-models');
const { svcGetWithBaseURL, svcGet, svcPut, svcPatch, svcPost } = require('@ge/serverless-utils');

const CASES_INDEX = '/diagnostics/v1/cases';
const CASES_CREATE = '/diagnostics/v1/cases/load';
const CASES_UPDATE = '/diagnostics/v1/cases/bulk/caseupdate';
const CASES_BY_ID = '/diagnostics/v1/cases/id';
const CASES_BY_SITE = '/diagnostics/v1/cases/sites';
const CASES_BY_ASSET = '/diagnostics/v1/cases/assets';
const ANOMALIES_BY_SITE = '/diagnostics/v1/cases/sites/anomalies';
const ANOMALIES_PAGE_PARAMS = '/diagnostics/v1/cases/sites/anomalies/siteSplit';
const MONITOR_CASES = '/monitor/v1/cases';
const CASE_METRICS_BY_ASSET = '/diagnostics/v1/cases/assets/metrics';
const MONITOR_CASE_COUNT = '/monitor/v1/cases/count-details';
const LINK_CASES = '/diagnostics/v1/cases/link';
const UNLINK_CASES = '/diagnostics/v1/cases/delink';
const MONITOR_CASES_V2 = '/monitor/v2/cases';

const BASE_URL = process.env.FS_DEV_BASE_URL;

const { CaseEntityParams } = Enums;

const filterTypeQuery = {
  ACTIONS_OVERDUE: `&state=${MonitorCaseStateMapping.NEW},${MonitorCaseStateMapping.RETURNED}&type=${CaseTypeMapping.FAULTED}&metricIds=1`,
  NO_COMM_ASSETS: `&state=${MonitorCaseStateMapping.NEW},${MonitorCaseStateMapping.RETURNED}&type=${CaseTypeMapping.ASSET_NO_COMM}&metricIds=1`,
};

const PARAMS = {
  forCaseIds: (ids) => ({ caseIds: ids.join(',') }),
  forSiteIds: (ids, params) => ({ ...params, [CaseEntityParams.SITE_ID]: ids.join(',') }),
  forAssetIdsAndStatus: (ids, status) => ({ assetIds: ids.join(','), status }),
  forMonitorCases: (pageSize, pageNumber, status, filterType, siteIds) => {
    let query = `siteIds=${siteIds.join(',')}`;
    if (filterType) {
      query += filterTypeQuery[filterType];
    } else {
      query += `&excludeTypes=${CaseTypeMapping.ASSET_NO_COMM}&state=${status}`;
    }

    return {
      pageSize,
      page: pageNumber,
      query,
    };
  },
  forMetrics: (ids) => ({ assetIds: ids.join(',') }),
  forAssetCases: ({ assetId, status, page = 0, pageSize = 1000, days = 7 }) => {
    if (status === String(MonitorCaseStateMapping.CLOSED)) {
      return {
        page,
        pageSize,
        query: `assetId=${assetId}&state=${status}&createdTime>${dayjs()
          .subtract(days, 'd')
          .valueOf()}&createdTime<${dayjs().valueOf()}`,
      };
    }
    return {
      page,
      pageSize,
      query: `assetId=${assetId}&state=${status}&excludeTypes=${CaseTypeMapping.SITE_NO_COMM},${CaseTypeMapping.FLEET_NO_COMM}`,
    };
  },
  forActiveCaseCount: ({ siteIds, filterType }) => {
    let query = `siteIds=${siteIds.join(',')}`;
    query += filterTypeQuery[filterType] ? filterTypeQuery[filterType] : '';
    return {
      query,
    };
  },
  forCaseHistoryCount: ({ siteId, assetId, days = 7, responsibleAlarm }) => {
    let query = `state=${MonitorCaseStateMapping.CLOSED}`;
    if (siteId) {
      query += `&siteId=${siteId}&asset_type=${AlertsEntityType.SITE}`;
    } else {
      query += `&assetId=${assetId}`;
    }
    if (responsibleAlarm) {
      query += `&responsibleAlarm=${responsibleAlarm}`;
    }
    query += `&startTime=${dayjs()
      .subtract(days, 'd')
      .valueOf()}&endTime=${dayjs().valueOf()}`;
    return {
      query,
    };
  },
};

const getCasesByIds = (caseIds = [], headers) => {
  if (!caseIds.length) return Promise.resolve([]);
  return svcGetWithBaseURL(CASES_BY_ID, BASE_URL, { headers, params: PARAMS.forCaseIds(caseIds) });
};

const getCaseById = (caseId, headers) => getCasesByIds([caseId], headers).then(([r]) => r);

const _getCasesForAssetId = (headers) => (assetId) =>
  svcGetWithBaseURL(`${CASES_BY_ASSET}/${assetId}`, BASE_URL, { headers });

const getCasesForAssetIds = (assetIds, headers) =>
  asyncPool(20, assetIds, _getCasesForAssetId(headers)).then((caseArrays) => caseArrays.flat());

// Case api returns data for multiple site ids.
const getCasesForSiteIds = (siteIds, headers, params) => {
  if (!siteIds.length) return Promise.resolve([]);
  return svcGetWithBaseURL(CASES_BY_SITE, BASE_URL, {
    headers,
    params: PARAMS.forSiteIds(siteIds, params),
  });
};

// Case api returns data for multiple site ids for anomalies
const getAnomaliesForSiteIds = (siteIds, headers, params) => {
  return svcGetWithBaseURL(ANOMALIES_BY_SITE, BASE_URL, {
    headers,
    params: PARAMS.forSiteIds(siteIds, params),
  });
};

// Case api returns data for multiple site ids for anomalies
const getAnomaliesPageParams = (siteIds, headers, params) => {
  return svcGetWithBaseURL(ANOMALIES_PAGE_PARAMS, BASE_URL, {
    headers,
    params: PARAMS.forSiteIds(siteIds, params),
  });
};

const getCaseTreeRecursive = async (caseIds, headers) => {
  const cases = await getCasesByIds(caseIds, headers);
  const childIds = Transformers.Case.ofCases(cases, [EntityParams.Case.CHILD_CASE_IDS]).reduce(
    (acc, c) => [...acc, ...(c.childCaseIds || [])],
    [],
  );
  if (childIds.length) {
    return cases.concat(await getCaseTreeRecursive(childIds, headers));
  }
  return cases;
};

const getCasesForAssetsAndStatus = (assetIds, status, headers) => {
  if (!assetIds.length) return Promise.resolve([]);
  return svcGetWithBaseURL(CASES_BY_ASSET, BASE_URL, {
    headers,
    params: PARAMS.forAssetIdsAndStatus(assetIds, status),
  });
};

const getMonitorCases = (pageSize, pageNumber, status, filterType, siteIds, headers) => {
  return svcGet(MONITOR_CASES, {
    headers,
    params: PARAMS.forMonitorCases(pageSize, pageNumber, status, filterType, siteIds),
  });
};

const getCaseMetricsForAssets = (assetIds, headers) => {
  if (!assetIds.length) return Promise.resolve([]);
  return svcGetWithBaseURL(CASE_METRICS_BY_ASSET, BASE_URL, {
    headers,
    params: PARAMS.forMetrics(assetIds),
  });
};

// UPDATE WITH PUT to Close Case
const updateCaseById = (caseId, assetId, casePayload, headers) => {
  if (!caseId && !assetId && !casePayload) {
    throw new Error('Please include caseId, assetId, and an updated casePayload.');
  }
  const bodyObj = {
    id: caseId,
    assetId,
    ...casePayload,
  };
  return svcPut(`${BASE_URL}${CASES_INDEX}`, bodyObj, { headers });
};

const createCase = (data, headers) => {
  return svcPost(`${BASE_URL}${CASES_INDEX}`, data, {
    headers,
  });
};

const createCases = (data, headers) => {
  return svcPost(`${BASE_URL}${CASES_CREATE}`, data, {
    headers,
  });
};

const updateCases = (ids, body, headers) => {
  return svcPatch(`${BASE_URL}${CASES_UPDATE}`, body, {
    headers,
    params: PARAMS.forCaseIds(ids),
  });
};

const linkCases = (data, headers) => {
  return svcPost(`${BASE_URL}${LINK_CASES}`, data, {
    headers,
  });
};

const unlinkCases = (data, headers) => {
  return svcPost(`${BASE_URL}${UNLINK_CASES}`, data, {
    headers,
  });
};

const changeMonitorCasesStatus = (headers, data) => {
  return svcPatch(`${BASE_URL}${MONITOR_CASES_V2}`, data, {
    headers,
  });
};

const editMonitorCasesQueue = (headers, data) => {
  return svcPatch(`${BASE_URL}${MONITOR_CASES_V2}`, data, {
    headers,
  });
};

const getAssetCases = (headers, params) => {
  return svcGet(MONITOR_CASES, {
    headers,
    params: PARAMS.forAssetCases(params),
  });
};

const getActiveCaseCount = (headers, params) => {
  return svcGet(MONITOR_CASE_COUNT, {
    headers,
    params: PARAMS.forActiveCaseCount(params),
  });
};

const getCaseHistoryCount = (headers, params) => {
  return svcGet(MONITOR_CASE_COUNT, {
    headers,
    params: PARAMS.forCaseHistoryCount(params),
  });
};

module.exports = {
  getForAssetIds: getCasesForAssetIds,
  getForSiteIds: getCasesForSiteIds,
  getById: getCaseById,
  getByIds: getCasesByIds,
  getByIdsWithChildren: getCaseTreeRecursive,
  getForAssetIdsAndStatus: getCasesForAssetsAndStatus,
  getMonitorCases,
  getMetricsForAssets: getCaseMetricsForAssets,
  updateCase: updateCaseById,
  createCase,
  createCases,
  updateCases,
  linkCases,
  unlinkCases,
  changeMonitorCasesStatus,
  editMonitorCasesQueue,
  getAssetCases,
  getActiveCaseCount,
  getAnomaliesForSiteIds,
  getAnomaliesPageParams,
  getCaseHistoryCount,
};
