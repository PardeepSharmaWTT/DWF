const { NotesCategory, EntityType } = require('@ge/models/constants');
const { svcGet, svcPatch, svcPost, svcDelete } = require('@ge/serverless-utils');

const BASE = '/common/v1';
const SITE_NOTES = `${BASE}/site-notes`;
const ASSET_NOTES = `${BASE}/asset-notes`;
const CASE_NOTES = `${BASE}/case-notes`;
const EVENT_NOTES = `${BASE}/event-notes`;
const TASK_NOTES = `${BASE}/task-notes`;

const NotesUrl = {
  [EntityType.SITE]: SITE_NOTES,
  [EntityType.ASSET]: ASSET_NOTES,
  [EntityType.CASE]: CASE_NOTES,
  [EntityType.TASK]: TASK_NOTES,
};

const getSpecialInstructionsQueryParam = (category, domainId, isActive) => {
  if (isActive) {
    return `category==${category};domainId==${domainId};status==${
      isActive === 'true' ? 'active' : 'inactive'
    }`;
  }
  return `category==${category};domainId==${domainId}`;
};

const getNotesSpeicalInstructionsQueryParam = (
  category,
  domainId,
  creationDate,
  fetchBoth = false,
) => {
  if (!fetchBoth) {
    return `category==${category};domainId==${domainId};timestampc>='${creationDate}'`;
  }
  return `domainId==${domainId};timestampc>='${creationDate}'`;
};

const PARAMS = {
  forNotes: (creationDate, pageSize, pageIdx, domainId, fetchBoth) => ({
    query: getNotesSpeicalInstructionsQueryParam(
      NotesCategory.NOTE,
      domainId,
      creationDate,
      fetchBoth,
    ),
    pageIdx,
    pageSize,
  }),
  forEntitiesNotes: (ids) => ({
    query: `domainId=in=(${ids.join(',')})`,
  }),
  forSpecialInstructions: (pageSize, pageIdx, domainId, isActive) => ({
    query: getSpecialInstructionsQueryParam(NotesCategory.SPECIAL_INSTRUCTION, domainId, isActive),
    pageSize,
    pageIdx,
  }),
  forEventNotes: (pageSize, pageIdx, domainId) => ({
    query: `domainId==${domainId}`,
    pageIdx,
    pageSize,
  }),
  forEventNotesWithDomainIds: (eventIds) => ({
    domainId: `${eventIds.join(',')}`,
  }),
};

const _getNoteURL = (url, id) => `${url}/${id}`;

const getSiteNotes = async (headers, { creationDate, pageSize, pageIndex, id, fetchBoth }) => {
  const resp = await svcGet(SITE_NOTES, {
    headers,
    params: PARAMS.forNotes(creationDate, pageSize, pageIndex, id, fetchBoth),
  });
  return resp;
};

const getSiteSpecialInstructions = async (headers, { pageSize, pageIndex, id, isActive }) => {
  const resp = await svcGet(SITE_NOTES, {
    headers,
    params: PARAMS.forSpecialInstructions(pageSize, pageIndex, id, isActive),
  });
  return resp;
};

const getAssetNotes = async (headers, { creationDate, pageSize, pageIndex, id, fetchBoth }) => {
  const resp = await svcGet(ASSET_NOTES, {
    headers,
    params: PARAMS.forNotes(creationDate, pageSize, pageIndex, id, fetchBoth),
  });
  return resp;
};

const getAssetSpecialInstructions = async (headers, { pageSize, pageIndex, id, isActive }) => {
  const resp = await svcGet(ASSET_NOTES, {
    headers,
    params: PARAMS.forSpecialInstructions(pageSize, pageIndex, id, isActive),
  });
  return resp;
};

const getCaseNotes = async (headers, { creationDate, pageSize, pageIndex, id, fetchBoth }) => {
  const resp = await svcGet(CASE_NOTES, {
    headers,
    params: PARAMS.forNotes(creationDate, pageSize, pageIndex, id, fetchBoth),
  });
  return resp;
};

const getCaseHistoryNotes = async ({ headers, caseIds }) => {
  const resp = await svcGet(EVENT_NOTES, {
    headers,
    params: PARAMS.forEventNotesWithDomainIds(caseIds),
  });
  return resp;
};

const getEntitiesNotes = async (headers, { ids, entityType }) => {
  const resp = await svcGet(NotesUrl[entityType], {
    headers,
    params: PARAMS.forEntitiesNotes(ids),
  });
  return resp;
};

const getCaseSpecialInstructions = async (headers, { pageSize, pageIndex, id, isActive }) => {
  const resp = await svcGet(CASE_NOTES, {
    headers,
    params: PARAMS.forSpecialInstructions(pageSize, pageIndex, id, isActive),
  });
  return resp;
};

const getEventNotes = async (headers, { pageSize, pageIndex, id }) => {
  const resp = await svcGet(EVENT_NOTES, {
    headers,
    params: PARAMS.forEventNotes(pageSize, pageIndex, id),
  });
  return resp;
};

const editAddAssetNotes = async (headers, { id, data, newRecord }) => {
  let resp;

  if (newRecord) {
    resp = await svcPost(ASSET_NOTES, data, {
      headers,
    });
  } else {
    resp = await svcPatch(_getNoteURL(ASSET_NOTES, id), data, {
      headers,
    });
  }
  return resp;
};

const editAddSiteNotes = async (headers, { id, data, newRecord }) => {
  let resp;

  if (newRecord) {
    resp = await svcPost(SITE_NOTES, data, {
      headers,
    });
  } else {
    resp = await svcPatch(_getNoteURL(SITE_NOTES, id), data, {
      headers,
    });
  }
  return resp;
};

const editAddCaseNotes = async (headers, { id, data, newRecord }) => {
  let resp;

  if (newRecord) {
    resp = await svcPost(CASE_NOTES, data, {
      headers,
    });
  } else {
    resp = await svcPatch(_getNoteURL(CASE_NOTES, id), data, {
      headers,
    });
  }
  return resp;
};

const editAddTaskNotes = async (headers, { id, data, newRecord }) => {
  let resp;

  if (newRecord) {
    resp = await svcPost(TASK_NOTES, data, {
      headers,
    });
  } else {
    resp = await svcPatch(_getNoteURL(TASK_NOTES, id), data, {
      headers,
    });
  }
  return resp;
};

const addEventNote = async (headers, { data }) =>
  await svcPost(EVENT_NOTES, data, {
    headers,
  });

const editEventNote = async (headers, { id, data }) =>
  await svcPatch(_getNoteURL(EVENT_NOTES, id), data, {
    headers,
  });

const deleteSiteNoteOrSpecialInstruction = async (headers, id) => {
  return await svcDelete(_getNoteURL(SITE_NOTES, id), {
    headers,
  });
};

const deleteAssetNoteOrSpecialInstruction = async (headers, id) => {
  return await svcDelete(_getNoteURL(ASSET_NOTES, id), {
    headers,
  });
};

const deleteCaseNoteOrSpecialInstruction = async (headers, id) => {
  return await svcDelete(_getNoteURL(CASE_NOTES, id), {
    headers,
  });
};

const deleteTaskNoteOrSpecialInstruction = async (headers, id) => {
  return await svcDelete(_getNoteURL(TASK_NOTES, id), {
    headers,
  });
};

const deleteEventNote = async (headers, id) => {
  return await svcDelete(_getNoteURL(EVENT_NOTES, id), {
    headers,
  });
};

const Asset = {
  getAssetNotes,
  getAssetSpecialInstructions,
  editAddAssetNotes,
  deleteAssetNoteOrSpecialInstruction,
};

const Site = {
  getSiteNotes,
  getSiteSpecialInstructions,
  editAddSiteNotes,
  deleteSiteNoteOrSpecialInstruction,
};

const Case = {
  getCaseNotes,
  getCaseHistoryNotes,
  getEntitiesNotes,
  getCaseSpecialInstructions,
  editAddCaseNotes,
  deleteCaseNoteOrSpecialInstruction,
};

const Task = {
  editAddTaskNotes,
  deleteTaskNoteOrSpecialInstruction,
};

const Event = {
  getEventNotes,
  addEventNote,
  editEventNote,
  deleteEventNote,
};

module.exports = {
  Asset,
  Site,
  Case,
  Task,
  Event,
};
