// https://devcloud.swcoe.ge.com/devspace/pages/viewpage.action?pageId=1742717495

const dayjs = require('dayjs');
const utc = require('dayjs/plugin/utc');
const { splitEvery } = require('ramda');
const asyncPool = require('tiny-async-pool');

dayjs.extend(utc);

const { IdType, SiteAggregatedSignals } = require('@ge/serverless-models/src/rendigital/enums');
const { svcGet } = require('@ge/serverless-utils');

const BASE = '/machinedata/v1';
const SIGNAL_VALUES = `${BASE}/historical-signals/values/`;
const REALTIME_VALUES = `${BASE}/realtime-signals/values/`;
const REALTIME_EVENTS = `${BASE}/realtime-events/values/`;
const AGGREGATED_SITES_DATA = '/machinedata/v2/realtime-aggregate/values/';
const TURBINE_STATUS = 'machinedata/realtime/v1/assetstate';

const PARAMS = {
  forAssets: (
    assetIds,
    startTime,
    endTime,
    signalIds = [],
    assetIdType = IdType.canonical,
    signalIdType = IdType.canonical,
  ) => ({
    assetIds: assetIds.join(','),
    startTime,
    endTime,
    aggregation: 'AVG_10M',
    signalIds: signalIds.join(','),
    quality: 3,
    assetIdType,
    signalIdType,
  }),
  forAssetSignalsRealTime: (assetIds, signalIds = [], isCanonical) => ({
    assetIds: assetIds.join(','),
    // aggregation: 'SAM_30S', // #TODO: HAS TO BE REVISITED :  Commenting for now because of the SAGE issue ( SAGE is using AVG_30s)
    signalIds: signalIds.join(','),
    // quality: 3, // #TODO: Will uncheck once the sage streams proper data
    assetIdType: isCanonical ? IdType.canonical : IdType.source,
    signalIdType: isCanonical ? IdType.canonical : IdType.source,
  }),
  forAssetEventsRealTime: (assetId, isCanonical) => ({
    assetIdType: isCanonical ? IdType.canonical : IdType.source,
    assetIds: assetId,
    eventIdType: IdType.all,
  }),
  // TODO: This is based on the intermediate API def.. Will be changed when the actual api is implemented.
  forSitesAggregated: (siteIds, signalIds) => ({
    siteIds: siteIds.join(','),
    signalIds: signalIds.join(','),
    entityType: 'SITE',
  }),
  forTurbineStatus: (assetIds) => ({
    assetIds,
  }),
  forTurbineFailedStatus: (assetIds) => ({
    assetIds,
    includeFields: 'metaData,event',
  }),
  forTurbineStatusWithHistory: (assetIds, historyCount) => ({
    assetIds,
    includeFields: 'stateChangeHistory,metaData,event',
    stateChangeHistoryCount: historyCount,
  }),
  forTurbineStatusForSite: (siteIds) => ({
    siteIds,
  }),
  forTurbineStatusForSiteWithHistory: (siteIds, historyCount) => ({
    siteIds,
    includeFields: 'stateChangeHistory,metaData,event',
    stateChangeHistoryCount: historyCount,
  }),
  forAssetsConnectionStatus: (id) => ({
    siteIds: id.join(','),
    entityType: 'ASSET',
    signalIds: `${SiteAggregatedSignals.ASSET_CONNC_STATUS},${SiteAggregatedSignals.BOP_SC_CONNC_STATUS}`,
  }),
  forAssetConnectionStatus: (id) => ({
    assetIds: Array.isArray(id) ? id.join(',') : id,
    entityType: 'ASSET',
    signalIds: `${SiteAggregatedSignals.ASSET_CONNC_STATUS},${SiteAggregatedSignals.BOP_SC_CONNC_STATUS}`,
  }),
  forTurbineCausalStatus: (assetIds) => ({
    assetIds,
    includeFields: 'metaData,event',
    idType: 'canonical',
  }),
};

const getSignalsForAssets = (
  headers,
  assetIds = [],
  { startTime, endTime, assetIdType, signalIdType, signalIds = [] },
) => {
  const chunked = splitEvery(25, assetIds); // To see if the powercurve can load faster in analyze
  const startSec = dayjs.utc(startTime).unix();
  const endSec = dayjs.utc(endTime).unix();

  console.log(
    `Getting asset signals [${signalIds.join(', ')}] for ${assetIds.length} assets using ${
      chunked.length
    } requests`,
  );
  const promises = chunked.map((ids) =>
    svcGet(SIGNAL_VALUES, {
      headers,
      params: PARAMS.forAssets(ids, startSec, endSec, signalIds, assetIdType, signalIdType),
    }),
  );

  return Promise.all(promises).then((arr) =>
    arr.reduce((acc, resp) => acc.concat(resp.assetIds), []),
  );
};

const getRTValuesForSignals = async (headers, assetIds, signals, isCanonical = true) => {
  const resp = await svcGet(REALTIME_VALUES, {
    headers,
    params: PARAMS.forAssetSignalsRealTime(assetIds, signals, isCanonical),
  });
  return resp;
};

const getRTEvents = async (headers, assetId, isCanonical = true) => {
  const resp = await svcGet(REALTIME_EVENTS, {
    headers,
    params: PARAMS.forAssetEventsRealTime(assetId, isCanonical),
  });
  return resp;
};

const getAggregatedDataForMonitorSites = async (headers, siteIds, signalIds) => {
  const resp = await svcGet(AGGREGATED_SITES_DATA, {
    headers,
    params: PARAMS.forSitesAggregated(siteIds, signalIds),
  });
  return resp;
};

const getConnectionStatusForAssets = async (headers, siteId) => {
  const resp = await svcGet(AGGREGATED_SITES_DATA, {
    headers,
    params: PARAMS.forAssetsConnectionStatus(siteId),
  });
  return resp;
};

const _getConnectionStatusForAssetIds = (headers) => async (assetIds) =>
  await svcGet(AGGREGATED_SITES_DATA, {
    headers,
    params: PARAMS.forAssetConnectionStatus(assetIds),
  });

const getConnectionStatusForAsset = async (headers, assetId) => {
  const resp = await svcGet(AGGREGATED_SITES_DATA, {
    headers,
    params: PARAMS.forAssetConnectionStatus(assetId),
  });
  return resp;
};

const _getTurbineStatus = (headers, historyCount = 0) => async (assetIds) => {
  const assetIdsStr = assetIds.join(',');
  let params = PARAMS.forTurbineStatus(assetIdsStr);
  if (historyCount > 0) {
    params = PARAMS.forTurbineStatusWithHistory(assetIdsStr, historyCount);
  }
  return await svcGet(TURBINE_STATUS, {
    headers,
    params,
  });
};

const _getTurbineFailedStatus = (headers) => async (assetIds) => {
  const assetIdsStr = assetIds.join(',');
  let params = PARAMS.forTurbineFailedStatus(assetIdsStr);
  return await svcGet(TURBINE_STATUS, {
    headers,
    params,
  });
};

const getTurbineStatusForAllAssets = async (siteIds, headers, historyCount = 0) => {
  const siteIdsStr = siteIds.join(',');
  let params = PARAMS.forTurbineStatusForSite(siteIdsStr);
  if (historyCount > 0) {
    params = PARAMS.forTurbineStatusForSiteWithHistory(siteIdsStr, historyCount);
  }
  return await svcGet(TURBINE_STATUS, {
    headers,
    params,
  });
};

const getTurbineStatus = (assetIdsArr, headers, historyCount = 0) =>
  asyncPool(6, assetIdsArr, _getTurbineStatus(headers, historyCount));

const getTurbineFailedStatus = (assetIdsArr, headers) =>
  asyncPool(6, assetIdsArr, _getTurbineFailedStatus(headers));
// In CaseQueue table we have to display 1000 records, so using asyncPool with poolLimit as 6
// and we are processing the call for 200 assetIds in a pool
const getConnectionStatusForAssetIds = (headers, assetIdsArr) =>
  asyncPool(6, assetIdsArr, _getConnectionStatusForAssetIds(headers));

const getTurbineCausalEvent = (headers) => async (assetIds) => {
  let params = PARAMS.forTurbineCausalStatus(assetIds.join(','));
  return await svcGet(TURBINE_STATUS, {
    headers,
    params,
  });
};

const Assets = {
  getSignals: getSignalsForAssets,
  getRTValuesForSignals: getRTValuesForSignals,
  getRTEvents,
  getTurbineStatus,
  getConnectionStatusForAssets,
  getConnectionStatusForAsset,
  getConnectionStatusForAssetIds,
  getTurbineFailedStatus,
  getTurbineCausalEvent,
};

const Sites = {
  getAggregatedData: getAggregatedDataForMonitorSites,
  getTurbineStatusForAllAssets,
};

module.exports = {
  Assets,
  Sites,
};
