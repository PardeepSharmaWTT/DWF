const { svcGet } = require('@ge/serverless-utils');

const BASE = '/machinedata/v1/file';
const FILE_DETAILS = `${BASE}/getS3KeyDetails`;
const DOWNLOAD_FILE = `${BASE}/downloadS3Files`;
/* const getFilesDetails = (fileInputParameters, headers) =>
  svcPost(
    FILE_DETAILS,
    {
      siteId: fileInputParameters.siteId,
      assetId: fileInputParameters.assetId,
      categoryId: fileInputParameters.categoryId,
      subCategoryId: fileInputParameters.subCategoryId,
      startTime: fileInputParameters.startTime,
      endTime: fileInputParameters.endTime,
      fileType: fileInputParameters.fileType,
    },
    {
      headers,
    },
  );

const getFileDowloadData = (s3FileKey, headers) =>
  svcPost(
    DOWNLOAD_FILE,
    {
      s3FileKey,
    },
    {
      headers,
    },
  );
*/
const getFilesDetails = (
  siteId,
  assetId,
  categoryId,
  subCategoryId,
  startTime,
  endTime,
  fileType,
  headers,
) =>
  svcGet(FILE_DETAILS, {
    headers,
    params: {
      siteId,
      assetId,
      categoryId,
      subCategoryId,
      startTime,
      endTime,
      fileType,
    },
  });
const getFileDowloadData = (s3FileKey, headers) =>
  svcGet(DOWNLOAD_FILE, {
    headers,
    params: {
      s3FileKey,
    },
  });
module.exports = {
  getFilesDetails,
  getFileDowloadData,
};
