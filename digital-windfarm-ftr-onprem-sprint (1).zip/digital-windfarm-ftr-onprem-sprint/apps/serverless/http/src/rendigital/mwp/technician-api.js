import { ManageTransformer } from '@ge/serverless-models/src/rendigital/transformers';
import { svcGet } from '@ge/serverless-utils';

const Url = {
  CREWS: '/manage/crew-svc/v1/crews',
};

export const getCrew = async ({ crewId }, headers) => {
  console.debug(`Getting crew with Id '${crewId}'`);

  const response = await svcGet(`${Url.CREWS}/${crewId}`, { headers });

  const transformed = ManageTransformer.crewTransformer(response);

  return transformed;
};
