import { ManageTransformer } from '@ge/serverless-models/src/rendigital/transformers';
import { svcGet, svcPut } from '@ge/serverless-utils';

const ERP_COLLECTIONS_URL = 'manage/task-template/v1/erpCollections';
const ERP_REQUEST_STATUS_URL = '/manage/v2/work-orders';
const ERP_REQUEST_URL = '/manage/v2/work-orders/work-order';
const ERP_TEMPLATE_URL = 'manage/task-template/v1/erpTemplate';
const ERP_TRANSLATIONS_URL = '/manage/task-template/v1/internationalization';

export const getErpTemplate = async (headers) => {
  console.debug('Getting ERP template');

  const response = await svcGet(ERP_TEMPLATE_URL, { headers });

  const transformed = ManageTransformer.erpTemplateTransformer(response, headers);

  return transformed;
};

export const getErpTemplateFieldValues = async (headers) => {
  console.debug('Getting ERP template field values');

  const response = await svcGet(ERP_COLLECTIONS_URL, { headers });

  const transformed = ManageTransformer.erpTemplateFieldValuesTransformer(response);

  return transformed;
};

export const createErpRequest = async (params, _headers) => {
  console.debug('Creating ERP request');

  const { body, headers } = ManageTransformer.createErpRequestTransformer(params, _headers);

  const response = await svcPut(ERP_REQUEST_URL, body, { headers });

  const transformed = ManageTransformer.erpRequestTransformer(response);

  return transformed;
};

export const getErpRequest = async ({ taskId }, headers) => {
  console.debug(`Getting ERP request with task Id '${taskId}'`);

  const response = await svcGet(`${ERP_REQUEST_URL}/${taskId}`, { headers });

  const transformed = ManageTransformer.erpRequestTransformer(response);

  return transformed;
};

export const getErpRequestStatus = async ({ taskIds = [] }, headers) => {
  console.debug(`Getting ERP request with task Ids '${JSON.stringify(taskIds)}'`);

  const response = await svcGet(
    `${ERP_REQUEST_STATUS_URL}?query=erpStatus&taskIds=${taskIds.join(',')}`,
    {
      headers,
    },
  );

  const transformed = response.map(ManageTransformer.erpRequestStatusTransformer);

  return transformed;
};

export const getErpTranslations = async ({ language }, headers) => {
  console.debug(`Getting ERP translations for language '${language}'`);

  const response = await svcGet(`${ERP_TRANSLATIONS_URL}?language=${language}`, {
    headers,
  });

  const transformed = ManageTransformer.erpTranslationsTransformer(response);

  return transformed;
};
