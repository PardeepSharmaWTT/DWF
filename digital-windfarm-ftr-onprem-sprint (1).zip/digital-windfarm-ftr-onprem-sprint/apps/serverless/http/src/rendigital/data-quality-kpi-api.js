const { KpiCategoryDefs } = require('@ge/models/constants');
const { kpiRequestTransformer } = require('@ge/serverless-models/src/rendigital/transformers');
const { svcPost } = require('@ge/serverless-utils');

const BASE_URL = process.env.FS_DEV_BASE_URL;
const SERVICE_URL = '/performance/data-quality-metrics/v1';

const endpointDict = {
  [KpiCategoryDefs.EVENT_COVERAGE]: `${SERVICE_URL}/event-coverage`,
  [KpiCategoryDefs.IU_COVERAGE]: `${SERVICE_URL}/iu-coverage`,
  [KpiCategoryDefs.REPORTING_TURBINES_RATIO]: `${SERVICE_URL}/reporting-turbines`,
};

// the params are agnostic of a specific endpoint/implementation so that we
// can swap out endpoints dynamically based on deployment, not sure how easy that will be in practice
const getKpiData = ({ category, ...params }, headers) => {
  const endpoint = endpointDict[category];

  console.debug(`Calling endpoint '${endpoint}'`);

  const body = kpiRequestTransformer(params);

  return svcPost(endpoint, body, {
    baseURL: BASE_URL,
    headers,
  });
};

module.exports = {
  getKpiData,
};
