const { svcGet } = require('@ge/serverless-utils');

const SERVICE_URL = '/diagnostics/v1/casetemplate';
const SERVICE_URL_ROOTCAUSE = '/diagnostics/v1/casetemplate/rootcause';

const PARAMS = {
  forCaseTemplate: (id) => ({ caseTemplateId: id }),
  forRootCause: (ids) => ({ caseTemplateIds: ids.join(',') }),
};

const getCaseTemplate = (id, headers) =>
  svcGet(SERVICE_URL, { headers, params: PARAMS.forCaseTemplate(id) });

const getRootCauseForCaseTemplate = (ids, headers) =>
  svcGet(SERVICE_URL_ROOTCAUSE, { headers, params: PARAMS.forRootCause(ids) });

module.exports = {
  getById: getCaseTemplate,
  getRootCause: getRootCauseForCaseTemplate,
};
