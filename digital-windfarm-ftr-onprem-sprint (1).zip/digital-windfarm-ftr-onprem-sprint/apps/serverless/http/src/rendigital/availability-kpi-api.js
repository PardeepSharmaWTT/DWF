const { mergeAll } = require('ramda');

const { KpiCategoryDefs, SortDirection, KpiCategorySeriesType } = require('@ge/models/constants');
const {
  filtersTransformer,
  kpiRequestTransformer,
} = require('@ge/serverless-models/src/rendigital/transformers');
const { svcPost } = require('@ge/serverless-utils');

const BASE_URL = process.env.FS_DEV_BASE_URL;

const URLS = {
  AVAILABILITY: '/performance/availability-metrics/v1',
  CONTRACTUAL_REPORTING: '/contractual/availability/v1',
  // this is for site performance
  // techically it should be in PerformanceKpiApi, but we are using the exact same call
  // just swapping out a part of the url so putting in here for now
  PRODUCTION: '/performance/production-metrics/v1',
};

const getCategoryUrl = (category) =>
  ({
    [KpiCategoryDefs.CAPACITY_FACTOR]: URLS.PRODUCTION,
    [KpiCategoryDefs.PRODUCTION_ACTUAL]: URLS.PRODUCTION,
    [KpiCategoryDefs.PRODUCTION_LOST_CONTRACT]: URLS.PRODUCTION,
  }[category] || URLS.AVAILABILITY);

const SitePerformanceSortKey = {
  HIGHEST_PERFORMER: 'high-performer',
  LOWEST_PERFORMER: 'low-performer',
};

const sitePerformanceSortDirectionMap = {
  [SortDirection.ASC]: SitePerformanceSortKey.LOWEST_PERFORMER,
  [SortDirection.DESC]: SitePerformanceSortKey.HIGHEST_PERFORMER,
};

const kpiCategoryMap = {
  [KpiCategoryDefs.CAPACITY_FACTOR]: 'CF',
  [KpiCategoryDefs.PRODUCTION_ACTUAL]: 'AP',
  [KpiCategoryDefs.PRODUCTION_LOST_CONTRACT]: 'LPC',
};

const PBAendpointDict = {
  [KpiCategorySeriesType.TIME_SERIES]: `${URLS.AVAILABILITY}/production-based`,
  [KpiCategorySeriesType.ENTITY]: `${URLS.AVAILABILITY}/seriesweighted-pba-technical`,
};

const endpointDict = {
  [KpiCategoryDefs.AVAILABILITY_CONTRACT]: `${URLS.CONTRACTUAL_REPORTING}/reporting/availability`,
  [KpiCategoryDefs.PBA]: PBAendpointDict,
  [KpiCategoryDefs.TBA]: `${URLS.AVAILABILITY}/time-based`,
};

// the params are agnostic of a specific endpoint/implementation so that we
// can swap out endpoints dynamically based on deployment, not sure how easy that will be in practice
const getKpiData = async (params, headers, types) => {
  const { category } = params;

  const endpoint = endpointDict[category];

  console.debug(`Calling endpoint '${endpoint}'`);

  const body = kpiRequestTransformer(params);
  let result;

  if (category === KpiCategoryDefs.PBA) {
    const promises = types.map((type) => {
      const pbaEndpoint = endpoint[type];

      return svcPost(pbaEndpoint, body, {
        baseURL: BASE_URL,
        headers,
      });
    });

    const response = await Promise.all(promises);
    result = mergeAll(response);
  } else {
    result = svcPost(endpoint, body, {
      baseURL: BASE_URL,
      headers,
    });
  }

  return result;
};

const getSitePerformance = (
  {
    category,
    endDate,
    entityAggr,
    entityType,
    filters,
    pageIndex,
    pageSize,
    sortDirection,
    startDate,
    timeAggr,
  },
  headers,
) => {
  // can we leverage kpi request tranformer here?
  const body = {
    assetAggr: entityAggr,
    assetType: entityType,
    // TODO: remove this, it's just a placeholder for now because still required by backend
    // but that is supposed to change since not all calls expect entity ids
    // was told to just pass tenant id along for now
    assetValues: ['geservdrZp'],
    endDate,
    filters: filtersTransformer(filters),
    startDate,
    timeAggr,
  };

  const queryParams = {
    kpi: kpiCategoryMap[category] || category,
    pageIdx: pageIndex,
    // currently backend expects a count param, but requested changing to pageSize and exposing pageIdx as well
    pageSize,
    sortKey: sitePerformanceSortDirectionMap[sortDirection],
  };

  const url = getCategoryUrl(category);

  console.debug(`Getting data from url ${url}`);

  return svcPost(`${url}/sites-performance`, body, {
    baseURL: BASE_URL,
    headers,
    params: queryParams,
  });
};

module.exports = {
  getKpiData,
  getSitePerformance,
};
