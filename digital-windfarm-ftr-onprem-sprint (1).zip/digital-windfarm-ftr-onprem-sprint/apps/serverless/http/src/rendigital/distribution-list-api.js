const { EntityType } = require('@ge/models/constants');
const { svcGet } = require('@ge/serverless-utils');

const DISTRIBUTION_LIST_API_URL = '/assetmgmt/utils/v1/distribution-list';

const PARAMS = {
  forSite: (entityId, namespace, sourceId) => {
    let query = `entity.siteId=${entityId}`;
    if (namespace && sourceId) {
      query += `&distributionType.namespace=${namespace}&distributionType.sourceId=${sourceId}`;
    }
    return {
      query,
    };
  },
  forAsset: (entityId, namespace, sourceId, assetType) => {
    let query = `lookupType=hierarchy&assetType=${assetType}`;
    if (entityId && entityId.split(',').length > 1) {
      query += `&entity.assetIds=${entityId}`;
    } else {
      query += `&entity.assetId=${entityId}`;
    }
    if (namespace && sourceId) {
      query += `&distributionType.namespace=${namespace}&distributionType.sourceId=${sourceId}`;
    }
    return {
      query,
    };
  },
};

const getDistributionList = async (
  headers,
  { entityType, entityId, namespace, sourceId, assetType },
) => {
  let params = {};
  if (entityType === EntityType.ASSET) {
    params = PARAMS.forAsset(entityId, namespace, sourceId, assetType);
  } else {
    params = PARAMS.forSite(entityId, namespace, sourceId);
  }

  const resp = await svcGet(DISTRIBUTION_LIST_API_URL, {
    headers,
    params,
  });
  return resp;
};

module.exports = {
  getDistributionList,
};
