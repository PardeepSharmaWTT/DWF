const { AlertStatusCodeMapping } = require('@ge/models/constants');
const { svcGet, svcPost, svcPatch } = require('@ge/serverless-utils');

const BASE = '/monitor/v1';
const ALERTS = `${BASE}/alerts`;

const statusQuery = `status=${AlertStatusCodeMapping.OPEN},${AlertStatusCodeMapping.EXPIRED}`;

const PARAMS = {
  forSiteAlerts: ({ siteId, assetType }) => {
    if (!assetType) {
      return {
        query: `siteIds=${siteId}&${statusQuery}`,
      };
    }
    return {
      query: `siteIds=${siteId}&assetType=${assetType}&${statusQuery}`,
    };
  },
  forAssetAlerts: ({ assetId }) => ({
    query: `assetIds=${assetId}&${statusQuery}`,
  }),
  forAllAlerts: () => ({
    query: statusQuery,
  }),
  forAssetIds: ({ assetIds = [] }) => ({
    query: `assetIds=${assetIds.join(',')}&${statusQuery}`,
  }),
  forSiteIds: (siteIds) => ({
    query: `siteIds=${siteIds.join(',')}&${statusQuery}`,
  }),
};

const getAllAlerts = async (headers, queryStringParameters) =>
  await svcGet(ALERTS, {
    headers,
    params: PARAMS.forAllAlerts(queryStringParameters),
  });

const getSiteAlerts = async (headers, queryStringParameters) =>
  await svcGet(ALERTS, {
    headers,
    params: PARAMS.forSiteAlerts(queryStringParameters),
  });

const getAssetAlerts = async (headers, queryStringParameters) =>
  await svcGet(ALERTS, {
    headers,
    params: PARAMS.forAssetAlerts(queryStringParameters),
  });

const getAlertsForSiteIds = async (headers, siteIds) =>
  await svcGet(ALERTS, {
    headers,
    params: PARAMS.forSiteIds(siteIds),
  });

const getAlertsForAssetIds = async (headers, assetIds) =>
  await svcGet(ALERTS, {
    headers,
    params: PARAMS.forAssetIds(assetIds),
  });

const postAlert = async (headers, data) => await svcPost(ALERTS, data, { headers });

const patchAlert = async (headers, data) => await svcPatch(ALERTS, data, { headers });

const Alerts = {
  getAllAlerts,
  getSiteAlerts,
  getAssetAlerts,
  getAlertsForSiteIds,
  getAlertsForAssetIds,
  postAlert,
  patchAlert,
};

module.exports = {
  Alerts,
};
