const jwt = require('jsonwebtoken');
const jwksClient = require('jwks-rsa');

const { svcGetWithBaseURL, getHeader } = require('@ge/serverless-utils');

export const getAccessTokens = (event) => {
  console.log(`${JSON.stringify(event)}`);

  const authHeader = getHeader('Authorization', event.headers);
  const originHeader = getHeader('Origin', event.headers);
  const headers = {
    access_token: authHeader && authHeader.trim(),
    origin: originHeader && originHeader.trim(),
  };
  const baseURL = process.env.IAC_INTERNAL_BASE_URL;
  const tokenPath = `/iac/${process.env.IAC_VERSION}/token`;

  console.log('Sending request', tokenPath, baseURL, headers);

  return svcGetWithBaseURL(tokenPath, baseURL, { headers });
};

const keyClient = jwksClient({
  cache: true,
  cacheMaxAge: 86400000, // value in ms
  rateLimit: true,
  jwksRequestsPerMinute: 10,
  strictSsl: true,
  jwksUri: process.env.IAC_JWKS_URI,
});

const verificationOptions = {
  algorithms: 'RS256',
};

const getSigningKey = (header, callback) => {
  keyClient.getSigningKey(header.kid, (err, key) => {
    if (err) {
      console.log(`Unable to get signing key: ${JSON.stringify(err)}`);
    }

    const signingKey = key.publicKey || key.rsaPublicKey;
    callback(null, signingKey);
  });
};

const validateToken = (token, callback, methodArn) => {
  jwt.verify(token, getSigningKey, verificationOptions, (error) => {
    if (error) {
      console.log(`JWT validation failed: ${JSON.stringify(error)}`);

      const response = generateAuthResponse('user', 'Deny', methodArn);
      callback(null, response);
    } else {
      // TODO:
      // Need to make sure that token is lined up with requested resource.

      const response = generateAuthResponse('user', 'Allow', methodArn);
      callback(null, response);
    }
  });
};

const generateAuthResponse = (principalId, effect, methodArn) => {
  const policyDocument = generatePolicyDocument(effect, methodArn);

  return {
    principalId,
    policyDocument,
  };
};

const generatePolicyDocument = (effect, methodArn) => {
  if (!effect || !methodArn) return null;

  return {
    Version: '2012-10-17',
    Statement: [
      {
        Action: 'execute-api:Invoke',
        Effect: effect,
        Resource: methodArn,
      },
    ],
  };
};

export const authorize = (event, context, callback) => {
  const token = event.authorizationToken;

  // Allow access to all for now until we sort out how to restrict
  // running only the function specifed by the arn.
  //   const methodArn = event.methodArn;
  const methodArn = '*';

  console.log(`Method: ${event.methodArn}`);

  validateToken(token, callback, methodArn);
};
