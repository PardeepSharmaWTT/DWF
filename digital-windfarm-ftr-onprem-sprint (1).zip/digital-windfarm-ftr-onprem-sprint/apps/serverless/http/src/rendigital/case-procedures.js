const { svcGet } = require('@ge/serverless-utils');
const BASE = '/assetmgmt/v1';
const EVENT_CONFIG = `${BASE}/events-config/search`;
const CASE_PROCEDURES = `${BASE}/case-procedures/`;
const requiredHeaders = {
  ['Content-Type']: 'application/json',
};

const getCaseProcedureByProcId = (headers, procId) =>
  svcGet(CASE_PROCEDURES, {
    headers: { ...headers, ...requiredHeaders },
    params: {
      query: `procId==${procId}`,
    },
  });

const getEventConfigByMapId = (headers, queryParams) =>
  svcGet(EVENT_CONFIG, {
    headers: { ...headers, ...requiredHeaders },
    params: {
      query: `eventMapId==${queryParams.eventMapId}&events.eventId==${queryParams.eventCodeId}`,
    },
  });

const getEventConfigByProcId = (headers, procId) =>
  svcGet(EVENT_CONFIG, {
    headers: { ...headers, ...requiredHeaders },
    params: { query: `events.procProperties.procId==${procId}` },
  });

const Events = {
  getEventConfigByMapId,
  getEventConfigByProcId,
};

const CaseProcedure = {
  getCaseProcedureByProcId,
};

module.exports = { CaseProcedure, Events };
