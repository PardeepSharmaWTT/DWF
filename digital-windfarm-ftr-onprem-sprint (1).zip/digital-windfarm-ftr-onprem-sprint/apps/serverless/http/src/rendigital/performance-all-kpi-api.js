const { KpiCategorySeriesType } = require('@ge/models/constants');
const { KpiSubType } = require('@ge/serverless-models/src/rendigital/enums');
const { kpiRequestTransformer } = require('@ge/serverless-models/src/rendigital/transformers');
const { svcPost } = require('@ge/serverless-utils');

const BASE_URL = process.env.FS_DEV_BASE_URL;
const ALL_KPI_SERVICE_URL = '/performance/all-kpi-metrics/v1';

const allKpiMetricsEndpointDictionary = {
  [KpiCategorySeriesType.ENTITY]: `${ALL_KPI_SERVICE_URL}/kpis-seriesweighted?kpiSubType=${KpiSubType.CONTRACT}`,
  [KpiCategorySeriesType.TIME_SERIES]: `${ALL_KPI_SERVICE_URL}/kpis-dateweighted?kpiSubType=${KpiSubType.CONTRACT}`,
};

function getEntityAggr({ seriesEntityAggr, dateEntityAggr, entityAggr }, type) {
  if (type === KpiCategorySeriesType.ENTITY) {
    return seriesEntityAggr || entityAggr;
  }
  if (type === KpiCategorySeriesType.TIME_SERIES) {
    return dateEntityAggr || entityAggr;
  }
  return entityAggr;
}

const getAllKpiMetricsData = (params, headers, types) => {
  return types.map((type) => {
    const endpoint = allKpiMetricsEndpointDictionary[type];
    const entityAggr = getEntityAggr(params, type);
    const body = kpiRequestTransformer({ ...params, entityAggr });
    console.debug(`Calling endpoint '${endpoint} with transformed params ${JSON.stringify(body)}'`);

    return svcPost(endpoint, body, {
      baseURL: BASE_URL,
      headers,
    });
  });
};

module.exports = {
  getAllKpiMetricsData,
};
