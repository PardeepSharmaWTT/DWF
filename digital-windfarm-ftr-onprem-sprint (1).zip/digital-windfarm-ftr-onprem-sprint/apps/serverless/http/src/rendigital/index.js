const AlertApi = require('./alert-api');
const AnalysisTemplateApi = require('./analysis-template-api');
const AssetManagementApi = require('./asset-mgmt-api');
const AuthApi = require('./auth-api');
const AvailabilityKpiApi = require('./availability-kpi-api');
const CaseApi = require('./case-api');
const CaseProcedureApi = require('./case-procedures');
const CaseTemplateApi = require('./case-template-api');
const CommandsApi = require('./commands-api');
const CrewApi = require('./crew-api');
const DataQualityKpiApi = require('./data-quality-kpi-api');
const DispatchAPI = require('./dispatch-api');
const DistributionListApi = require('./distribution-list-api');
const EmailApi = require('./email-api');
const EntityApi = require('./entity-api');
const MachineDataApi = require('./machine-data-api');
const MonitorAlertsApi = require('./monitor-alerts-api');
const ManageApi = require('./mwp');
const NotesApi = require('./notes-special-instructions-api');
const PerformanceAllKpiApi = require('./performance-all-kpi-api');
const PerformanceKpiApi = require('./performance-kpi-api');
const InspectionsApi = require('./rei');
const ReliabilityApi = require('./reliability-api');
const ROCActionLogApi = require('./roc-action-log-api');
const SiteContactApi = require('./site-contact-api');
const TaskApi = require('./task-api');
const TaskTemplateApi = require('./task-template-api');
const TimeSeriesApi = require('./timeseries-api');
const UsersApi = require('./users-api');

// segment offerings

module.exports = {
  AlertApi,
  AnalysisTemplateApi,
  AssetManagementApi,
  AuthApi,
  AvailabilityKpiApi,
  CaseApi,
  CaseTemplateApi,
  DataQualityKpiApi,
  EntityApi,
  InspectionsApi,
  MachineDataApi,
  ManageApi,
  PerformanceAllKpiApi,
  PerformanceKpiApi,
  ReliabilityApi,
  TaskApi,
  TaskTemplateApi,
  TimeSeriesApi,
  CommandsApi,
  NotesApi,
  MonitorAlertsApi,
  UsersApi,
  ROCActionLogApi,
  EmailApi,
  CaseProcedureApi,
  SiteContactApi,
  DistributionListApi,
  CrewApi,
  DispatchAPI,
};
