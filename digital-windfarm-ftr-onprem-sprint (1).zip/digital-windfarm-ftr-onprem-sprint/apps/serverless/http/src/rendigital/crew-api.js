const { svcGet, svcPost, svcPut, svcDelete } = require('@ge/serverless-utils');

const URLS = {
  crews: '/manage/crew-svc/v1/crews',
};

const createCrew = (crew, headers) => svcPost(URLS.crews, crew, { headers }, 'service');
const getCrews = (headers, params) => svcGet(URLS.crews, { headers, params });
const getCrew = (headers, crewId) => svcGet(URLS.crews + '/' + crewId, { headers });
const editCrew = (crew, headers, crewId) =>
  svcPut(URLS.crews + '/' + crewId, crew, { headers }, 'service');
const deleteCrew = (headers, crewId) =>
  svcDelete(URLS.crews + '/' + crewId, { headers }, 'service');

const Crew = {
  create: createCrew,
  get: getCrews,
  edit: editCrew,
  delete: deleteCrew,
  getCrew: getCrew,
};

module.exports = { Crew };
