const asyncPool = require('tiny-async-pool');

// const { EntityParams } = require('@ge/serverless-models');
const { svcGet } = require('@ge/serverless-utils');

const URLS = {
  serviceGroups: '/assetmgmt/v1/service-groups',
  siteGroups: '/assetmgmt/v1/site-groups',
  sites: '/assetmgmt/v1/sites',
  siteControllers: '/assetmgmt/v1/wind-site-controllers',
  substations: '/assetmgmt/v1/substations',
  turbines: '/assetmgmt/v2/wind-turbines',
};

const PARAMS = {
  sites: {
    all: {
      pageSize: '100000',
      sortKey: 'id',
      orderDirection: 'ASC',
      derivedProperties: true,
    },
  },
  turbines: {
    all: {
      pageIdx: 0,
      pageSize: 1000,
      sortKey: 'id',
      orderDirection: 'ASC',
    },
    forSite: (siteId) => ({ query: `wind-turbines.connections.siteId=${siteId}` }),
  },
  siteGroups: {
    byRegions: {
      siteGroupType: 'Region',
    },
    byROCStations: {
      siteGroupType: 'ROC Station',
    },
  },
};

const getTurbineFilters = (filters) => filters.map((param) => param.from.join('.')).join(',');

const getAllSites = (headers) => svcGet(URLS.sites, { headers, params: PARAMS.sites.all });

const _getSite = (headers) => (siteId) => svcGet(`${URLS.sites}/${siteId}`, { headers });

const getSites = (siteIds, headers) => asyncPool(20, siteIds, _getSite(headers));

const Sites = {
  getAll: getAllSites,
  get: getSites,
  // currently wrapping in an array so it can be processed by entities orchestration
  getById: (headers, { id }) => getSites([id], headers),
};

const getAllRegions = (headers) =>
  svcGet(URLS.siteGroups, { headers, params: PARAMS.siteGroups.byRegions });

const getRocStations = (headers) =>
  svcGet(URLS.siteGroups, { headers, params: PARAMS.siteGroups.byROCStations });

const getSiteGroup = (siteGroupId, headers) =>
  svcGet(`${URLS.siteGroups}/${siteGroupId}`, { headers });

const SiteGroups = {
  getRegions: getAllRegions,
  getRocStations: getRocStations,
  get: getSiteGroup,
};

const getTurbinesByPage = async (headers, { pageIndex, pageSize, filters }) => {
  console.log(`Getting ${pageSize} turbines for page ${pageIndex}`);

  const response = await svcGet(URLS.turbines, {
    headers,
    params: {
      pageIdx: pageIndex,
      pageSize: pageSize,
      filter: getTurbineFilters(filters),
    },
  });

  // we get back empty/null response from domain if no items for page index
  // so coerce to an empty array before passing back
  return (response && response.turbines) || [];
};

const getTurbineById = (turbineId, config) => _getTurbine(config)(turbineId);

const getAllTurbines = async (headers) => {
  let response = [];
  let pageResponse = [];
  let pageIndex = 0;

  console.log('Getting all turbines');

  // currently domain returns nothing when page index is too large
  // but might need to circle back to this logic
  while (pageResponse) {
    console.debug(`Getting turbines for page ${pageIndex}`);

    pageResponse = await svcGet(URLS.turbines, {
      headers,
      params: {
        ...PARAMS.turbines.all,
        pageIdx: pageIndex++,
      },
    });

    if (pageResponse) {
      response.push(...pageResponse);
    }
  }

  return response;
};

const _getTurbine = (config) => (turbineId) => svcGet(`${URLS.turbines}/${turbineId}`, config);

const getTurbineWithComponents = (turbineId, headers) =>
  svcGet(`${URLS.turbines}/${turbineId}`, {
    headers,
    params: {
      components: true,
    },
  });

const getTurbines = (turbineIds, config) => asyncPool(20, turbineIds, _getTurbine(config));

const _getTurbinesForSite = (headers) => (siteId) => {
  return svcGet(URLS.turbines, { headers, params: PARAMS.turbines.forSite(siteId) });
};

const getTurbinesForSite = (siteId, headers) => _getTurbinesForSite(headers)(siteId);

const getTurbinesForSites = (siteIds, headers) =>
  asyncPool(20, siteIds, _getTurbinesForSite(headers));

const Turbines = {
  getAll: getAllTurbines,
  get: getTurbines,
  getWithComponents: getTurbineWithComponents,
  getByPage: getTurbinesByPage,
  getById: getTurbineById,
  // using this in orchestration to support making entry point generic
  getBySiteId: (headers, { siteId }) => getTurbinesForSite(siteId, headers),
  getForSite: getTurbinesForSite,
  getForSites: getTurbinesForSites,
};

const getSiteController = (controllerId, headers) =>
  svcGet(`${URLS.siteControllers}/${controllerId}`, { headers });

const getAllSiteControllers = (headers) => svcGet(URLS.siteControllers, { headers });

const SiteControllers = {
  getAll: getAllSiteControllers,
  get: getSiteController,
};

const getSubstation = (substationId, headers) =>
  svcGet(`${URLS.substations}/${substationId}`, { headers });

const getAllSubstations = (headers) => svcGet(URLS.substations, { headers });

const Substations = {
  getAll: getAllSubstations,
  get: getSubstation,
};

const getServiceGroups = (headers) => svcGet(URLS.serviceGroups, { headers });

const ServiceGroup = {
  getServiceGroups,
};

module.exports = {
  ServiceGroup,
  Sites,
  SiteControllers,
  SiteGroups,
  Substations,
  Turbines,
};
