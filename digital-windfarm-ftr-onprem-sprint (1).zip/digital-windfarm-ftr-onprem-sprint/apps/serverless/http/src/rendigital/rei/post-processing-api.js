const { svcGet, svcPost } = require('@ge/serverless-utils');

const BASE_URL = process.env.INSPECT_API_URL;

const GetAnnoationUrl = '/inspections/getAnnotations';
const GetImgUrl = '/inspections/getImage';
const GetImgsUrl = '/inspections/getImages';
const GetVideosUrl = '/inspections/getVideos';
const GetDamageTreeUrl = '/inspections/getDamageTreeDetails';
const UpldateAnnotationUrl = '/inspections/updateAnnotation';
const UpdateImageUrl = '/inspections/updateImage';
const UpdateVideoUrl = '/inspections/updateVideo';

export const getAnnotations = async (objId, headers) => {
  // massage dwf request into rendigital request
  console.debug(`Getting Annoations for the job ID ${objId} `);

  const response = svcGet(`${GetAnnoationUrl}/${objId}`, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getImage = async (imageId, headers) => {
  // massage dwf request into rendigital request
  console.debug(`Getting Image for the image ID ${imageId} `);

  const response = svcGet(`${GetImgUrl}/${imageId}`, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getImages = async (jobId, headers) => {
  // massage dwf request into rendigital request
  console.debug(`Getting Image for the image ID ${jobId} `);

  const response = svcGet(`${GetImgsUrl}/${jobId}`, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getVideos = async (jobId, headers) => {
  // massage dwf request into rendigital request
  console.debug(`Getting videos for the image ID ${jobId} `);

  const response = svcGet(`${GetVideosUrl}/${jobId}`, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getDamageTreeDetails = async (inspectionType, headers) => {
  // massage dwf request into rendigital request
  console.debug(`Getting DamageTree detail based on inspection type ${inspectionType}`);

  const response = svcGet(`${GetDamageTreeUrl}/${inspectionType}`, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const updateAnnotation = async (flagNew, body, headers) => {
  // massage dwf request into rendigital request
  console.log(`Updating Annotation with the data ${body}`);

  const response = svcPost(`${UpldateAnnotationUrl}/${flagNew}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const updateImage = async (flagNew, body, headers) => {
  // massage dwf request into rendigital request
  console.log(`Updating image with the data ${body}`);

  const response = svcPost(`${UpdateImageUrl}/${flagNew}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const updateVideo = async (flagNew, body, headers) => {
  // massage dwf request into rendigital request
  console.log(`Updating video with the data ${body}`);

  const response = svcPost(`${UpdateVideoUrl}/${flagNew}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};
