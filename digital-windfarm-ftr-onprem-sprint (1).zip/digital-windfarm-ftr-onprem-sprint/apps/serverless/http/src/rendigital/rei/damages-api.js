const { filtersTransformer } = require('@ge/serverless-models/src/rendigital/transformers');
const { svcGet, svcPost } = require('@ge/serverless-utils');

const BASE_URL = process.env.INSPECT_API_URL;
const GetAllDamagesUrl = '/inspections/getDamages/';
const GetDamageReportUrl = '/inspections/getDamageReport/';
const GetDamageDetailsUrl = '/inspections/getDamageDetails';

export const getDamages = async ({ filters, ...params }, headers) => {
  const body = {
    ...params,
    filters: filtersTransformer(filters),
  };
  console.debug(`damages-api - calling getDamages with transformed body ${JSON.stringify(body)} `);
  const response = await svcPost(`${GetAllDamagesUrl}`, body, {
    baseURL: BASE_URL,
    headers,
  });
  console.debug(`damages-api - response from getDamages ${JSON.stringify(response)} `);
  return response;
};

export const getDamageReport = async (body, options, headers) => {
  // massage dwf request into rendigital request
  console.debug('Getting damage report with body', JSON.stringify(body));
  console.debug('Getting damage report with option', JSON.stringify(options));
  console.debug('Getting damage report with headers', JSON.stringify(headers));

  const response = svcPost(`${GetDamageReportUrl}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  console.debug(`damage report ${response} `);
  console.debug('type of resposne', typeof response);
  console.debug('options', { options });
  return response;
};

export const getDamageDetails = async (damageId, headers) => {
  // massage dwf request into rendigital request
  console.debug(`Getting damage detail with damage ID ${damageId} `);

  const response = svcGet(`${GetDamageDetailsUrl}/${damageId}`, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};
