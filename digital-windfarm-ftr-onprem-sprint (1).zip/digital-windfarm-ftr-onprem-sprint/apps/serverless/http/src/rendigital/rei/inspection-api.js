const { filtersTransformer } = require('@ge/serverless-models/src/rendigital/transformers');
const { svcPost, svcGetWithBaseURL, svcDelete } = require('@ge/serverless-utils');

const BASE_URL = process.env.INSPECT_API_URL;

const CHANGE_WORKFLOW = '/inspections/changeJobWorkflow';
const JOB_URL = '/inspections/getAllJobs';
const UPLOAD_STAGE_INFO = '/inspections/getUploadStageInfo';
const EXECUTION_STAGE_INFO = '/inspections/getExecutionStageInfo';
const POST_PROCESSING_STAGE_INFO = '/inspections/getPostProcessStageInfo';
const JOB_BY_ID = '/inspections/getJob';
// const S3_DIR_NAME = '/inspections/getS3DirName';
const CREATE_JOB_EXECUTION = '/inspections/createJobExecution';
// const GET_JOB_EXECUTION = '/inspections/getJobExecution';
const DELETE_INSPECTION = 'inspections/setDeleteFlag';

export const changeJobWorkflow = async (jobId, body, headers) => {
  // massage dwf request into rendigital request

  console.debug('changing job workflow', jobId, body);

  const response = svcPost(`${CHANGE_WORKFLOW}/${jobId}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getUploadStageInfo = async (jobId, headers) => {
  // massage dwf request into rendigital request

  console.debug('get upload stage information', jobId);
  console.log('BASE URL', BASE_URL);
  console.log('Endpoint', `${UPLOAD_STAGE_INFO}/${jobId}`);

  const response = svcGetWithBaseURL(`${UPLOAD_STAGE_INFO}/${jobId}`, BASE_URL, {
    headers,
  });

  return response;
};

export const getExecutionStageInfo = async (jobId, headers) => {
  // massage dwf request into rendigital request

  console.debug('get execution stage information', jobId);

  const response = svcGetWithBaseURL(`${EXECUTION_STAGE_INFO}/${jobId}`, BASE_URL, {
    headers,
  });

  return response;
};

export const getPostProcessStageInfo = async (jobId, headers) => {
  // massage dwf request into rendigital request

  console.debug('get post processing stage information', jobId);

  const response = svcGetWithBaseURL(`${POST_PROCESSING_STAGE_INFO}/${jobId}`, BASE_URL, {
    headers,
    // params: PARAMS.forNumber(jobId),
  });

  return response;
};

export const getJobById = async (jobId, headers) => {
  // massage dwf request into rendigital request

  console.debug('get job with id', jobId);

  const response = svcGetWithBaseURL(`${JOB_BY_ID}/${jobId}`, BASE_URL, {
    headers,
    // params: PARAMS.forNumber(jobId),
  });

  return response;
};

export const getAllJobs = async (number, { filters, ...params }, headers) => {
  // massage dwf request into rendigital request
  const body = {
    ...params,
    filters: filtersTransformer(filters),
  };
  console.debug('URL', `${BASE_URL}${JOB_URL}/${number}`);

  const response = await svcPost(`${JOB_URL}/${number}`, body, {
    baseURL: BASE_URL,
    headers,
  });
  return response;
};
export const deleteJob = async (jobId, headers) => {
  // massage dwf request into rendigital request

  console.debug('deleteing inspection', jobId);

  const response = svcDelete(`${DELETE_INSPECTION}/${jobId}`, {
    baseURL: BASE_URL,
    headers,
    // params: PARAMS.forNumber(jobId),
  });

  return response;
};

export const createJobExecution = async (jobId, body, headers) => {
  // massage dwf request into rendigital request

  console.debug('create job execution request', jobId);

  const response = svcPost(`${CREATE_JOB_EXECUTION}/${jobId}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};
