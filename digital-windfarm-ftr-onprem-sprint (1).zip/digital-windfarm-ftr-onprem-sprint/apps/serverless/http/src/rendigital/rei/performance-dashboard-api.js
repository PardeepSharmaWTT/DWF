const {
  filtersTransformer,
  Inspections,
} = require('@ge/serverless-models/src/rendigital/transformers');
const { svcPost } = require('@ge/serverless-utils');

const { performanceDashboardTransformer } = Inspections;

const BASE_URL = process.env.INSPECT_API_URL;
// put this somewhere more central?
const PERFORMANCE_DASHBOARD_URL = '/inspections/dashboard/performance-data/';
const PERFORMANCE_DASHBOARD_REPORT_URL = '/inspections/dashboard/performance-report/';

export const getPerformanceDashboard = async ({ filters, ...params }, headers) => {
  // massage dwf request into rendigital request
  const body = {
    ...params,
    filters: filtersTransformer(filters),
  };

  console.debug(
    `fetching performance dashboard from endpoint '${PERFORMANCE_DASHBOARD_URL}' with body '${JSON.stringify(
      body,
    )}'`,
  );

  const response = await svcPost(PERFORMANCE_DASHBOARD_URL, body, {
    baseURL: BASE_URL,
    headers,
  });

  console.debug('transforming performance dashboard response');

  // massage rendigital response into dwf response
  const transformed = performanceDashboardTransformer(response);

  return transformed;
};

export const getPerformanceDashboardReport = async ({ filters, ...params }, headers) => {
  // massage dwf request into rendigital request
  const body = {
    ...params,
    filters: filtersTransformer(filters),
  };

  console.debug(
    `fetching performance dashboard from endpoint '${PERFORMANCE_DASHBOARD_REPORT_URL}' with body '${JSON.stringify(
      body,
    )}'`,
  );

  const response = await svcPost(PERFORMANCE_DASHBOARD_REPORT_URL, body, {
    baseURL: BASE_URL,
    headers,
  });

  console.debug('transforming performance dashboard response');

  // massage rendigital response into dwf response

  return response;
};
