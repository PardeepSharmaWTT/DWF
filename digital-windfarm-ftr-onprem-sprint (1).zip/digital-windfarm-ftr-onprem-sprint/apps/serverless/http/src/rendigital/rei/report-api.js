const { filtersTransformer } = require('@ge/serverless-models/src/rendigital/transformers');
const { svcGetWithBaseURL, svcPost } = require('@ge/serverless-utils');

const BASE_URL = process.env.INSPECT_API_URL;

const DATA_REPORT_GENERATION = '/report/getDataForReportGeneration';
const REPORT_STAGE_INFO = '/report/getReportStageInfo';
const UPDATE_REPORT = '/report/updateReport';
const DOWNLOAD_REPORT = '/report/downloadReportsPdf/';
const COMPLETE_REPORT = '/report/complete/';
const SITE_NAMES_FOR_COMPLETED_REPORT = '/report/getSiteNamesByStage/report/complete';
const REPORT_COMPLETED_JOBS = '/report/getReportCompletedJobs/';

export const getDataForReportGeneration = async (jobId, headers) => {
  // massage dwf request into rendigital request

  console.debug('generate report from data', `${DATA_REPORT_GENERATION}/${jobId}`);

  const response = svcGetWithBaseURL(`${DATA_REPORT_GENERATION}/${jobId}`, BASE_URL, {
    headers,
  });

  return response;
};

export const getReportStageInfo = async (jobId, headers) => {
  // massage dwf request into rendigital request

  console.debug('get report stage information', jobId);

  const response = svcGetWithBaseURL(`${REPORT_STAGE_INFO}/${jobId}`, BASE_URL, {
    headers,
    // params: PARAMS.forNumber(jobId),
  });

  return response;
};

export const updateReport = async (jobId, body, headers) => {
  // massage dwf request into rendigital request

  const response = svcPost(`${UPDATE_REPORT}/${jobId}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getBulkReportDownloadUrl = async (body, headers) => {
  // massage dwf request into rendigital request

  const response = svcPost(DOWNLOAD_REPORT, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const completeReport = async (jobId, body, headers) => {
  // massage dwf request into rendigital request

  console.debug('changing job workflow', jobId);

  const response = svcPost(`${COMPLETE_REPORT}/${jobId}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getSiteNamesByStage = async (headers) => {
  // massage dwf request into rendigital request

  console.debug('Getting site names for completed report');

  const response = svcGetWithBaseURL(`${SITE_NAMES_FOR_COMPLETED_REPORT}`, BASE_URL, {
    headers,
  });

  return response;
};

export const getAllJobsWithReportCompleted = async ({ filters, ...params }, headers) => {
  // massage dwf request into rendigital request
  const body = {
    ...params,
    filters: filtersTransformer(filters),
  };
  console.debug(`report-api.js- calling getDamages with transformed body ${JSON.stringify(body)} `);

  const response = await svcPost(`${REPORT_COMPLETED_JOBS}`, body, {
    baseURL: BASE_URL,
    headers,
  });
  console.debug(`report-api.js - response from getReports ${JSON.stringify(response)} `);

  return response;
};
