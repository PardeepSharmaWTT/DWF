const { svcGet, svcGetWithBaseURL, svcPost, svcPatch } = require('@ge/serverless-utils');

const BASE_URL = process.env.INSPECT_API_URL;
// put this somewhere more central?
const TURBINE_TYPES_URL = '/inspections/getTurbineTypes/';
const SITES_URL = '/inspections/sites/';
const GET_IMAGE_PRESIGNED_URL = '/inspections/getImagePresignedUrl/';
const UPDATE_MANUFACTURER_URL = '/inspections/updateManufacturerByJobId';
const UPLOAD_SPREADSHEET_FILE_URL = 'inspections/processAnnotationForImage/';

export const getTurbineTypes = async (headers) => {
  // massage dwf request into rendigital request
  console.debug(`fetching turbine types from endpoint '${TURBINE_TYPES_URL}'`);

  const response = svcGet(`${TURBINE_TYPES_URL}`, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getTurbineDetails = async (siteId, headers) => {
  // massage dwf request into rendigital request
  const TURBINE_DETAILS_URL = `${SITES_URL}/${siteId}/turbines`;
  console.debug(
    `fetching Turbine details from endpoint '${TURBINE_DETAILS_URL}' as per site id '${siteId}'`,
  );

  const response = svcGetWithBaseURL(`${TURBINE_DETAILS_URL}`, BASE_URL, {
    headers,
  });

  return response;
};

export const getComponentDetailList = async (turbineAssetId, headers) => {
  // massage dwf request into rendigital request

  const COMPONENT_DETAIL_LIST_URL = `/inspections/turbines/${turbineAssetId}/components/`;
  console.debug(
    `fetching component details from endpoint '${COMPONENT_DETAIL_LIST_URL}' as per turbineAsset id '${turbineAssetId}'`,
  );

  const response = svcGetWithBaseURL(`${COMPONENT_DETAIL_LIST_URL}`, BASE_URL, {
    headers,
  });

  return response;
};

export const postJob = async (jobId, version, body, headers) => {
  // massage dwf request into rendigital request
  const UPLOAD_NEW_INSPECTION_DATA_URL = `/inspections/postJob/${jobId}?${version}`;
  // console.debug(`Uploading images and videos for new inspection '${JSON.stringify(body)}'`);

  const response = svcPost(`${UPLOAD_NEW_INSPECTION_DATA_URL}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const postMetadata = async (jobId, version, body, headers) => {
  // massage dwf request into rendigital request
  const UPDATE_METADATA_URL = `/inspections/${jobId}/metadata?${version}`;
  // console.debug(`Updating metadata for new inspection '${JSON.stringify(body)}'`);

  const response = svcPost(`${UPDATE_METADATA_URL}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const patchMetadata = async (jobId, parameter, body, headers) => {
  // massage dwf request into rendigital request
  const PATCH_METADATA_URL = `/inspections/jobs/${jobId}/metadata/${parameter}`;
  // console.debug(`Updating metadata for new inspection '${JSON.stringify(body)}'`);

  const response = svcPatch(`${PATCH_METADATA_URL}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const getPresignedUrl = async (body, headers) => {
  // massage dwf request into rendigital request
  console.debug(`fetching image pre-signed url from '${GET_IMAGE_PRESIGNED_URL}'`);

  const response = svcPost(`${GET_IMAGE_PRESIGNED_URL}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const updateManufacturerByJobId = async (jobId, body, headers) => {
  // massage dwf request into rendigital request
  console.debug(`Updating Manufacturer by job ID ${jobId} , ${body}`);

  const response = svcPost(`${UPDATE_MANUFACTURER_URL}/${jobId}`, body, {
    baseURL: BASE_URL,
    headers,
  });

  return response;
};

export const uploadSpreadsheetFile = async (body, headers) => {
  console.debug(`inspection-api.js -calling upload spreadsheet upload ${JSON.stringify(body)} `);
  const response = await svcPost(`${UPLOAD_SPREADSHEET_FILE_URL}`, body, {
    baseURL: BASE_URL,
    headers,
  });
  console.debug(`inspection-api.js -response from spreadsheet upload ${JSON.stringify(response)} `);
  return response;
};
