# GE Renewable Energy Digital Windfarm
For simplicity of MVP development, the client and server codebases are housed in a single repository (referred to here as a monorepo). This can be re-evaluated in the future when it is incorporated into GE source code management. Since both client and server will be leveraging JavaScript, we have the opportunity to create shared code and contract alignment between services and initial consumers. This also creates a structure from which to grow to include future applications such as an on-prem Express application and a React Native application for field techs.

## Getting Started
Please review this entire README for required context for working in the monorepo, but if you need the `TL;DR`, here it is.

In order to support the QA environment within GE, the application runs on local.rendigital.apps.ge.com as opposed to localhost.  In order to accomidate this, the etc/hosts file must be altered to include the following entry:
```bash
127.0.0.1	localhost local.rendigital.apps.ge.com
```

Run the following command in the root of the repo or in the base folder of the project you are working on (see below) to bootstrap dependencies.
```
$ yarn
```
From there, you can run any of the scripts in the `package.json` file at the root of the repo or in the base folder of any project. For example, from the root of the repo, you can run the following command to start the React web client development server:
```
$ yarn start:web
```
> DON'T STOP HERE! Make sure you keep reading to understand how the projects work. Future you will thank you.

## Monorepo structure
The monorepo uses [Yarn Workspaces](https://yarnpkg.com/lang/en/docs/workspaces/) to manage dependencies for all projects in the repository. This is useful for creating inter-project dependencies without requiring an external npm publish. In the future, [Lerna](https://github.com/lerna/lerna) may be a valuable tool for adding version management and publishing management in the event that packages developed in this repository have value to external consumers as well as internal.

### `/apps`
Complete applications that run and provide a specific user value. These applications will leverage the shared and common packages that are present in the `/packages` folder. For the Digital Windfarm PoC, this folder contains the following applications:

#### React Web Client (`/web-client`)
The core web-based application for managing and monitoring renewables assets. For more detail on application architecture and instructions for getting started, refer to the `README.md` in the application root.

#### Serverless Back-end (`/serverless`)
Services and back-end functionality to provide data and middle-tier business logic in support of client applications. Currently supporting AWS SAM deployment on DynamoDB. In the future, another application will be added as a peer to this one to support an on-premisis deployment of the same functionality.

### `/packages`
Shared packages that support applications or can be deployed into a private npm repository for reference outside the monorepo.

#### Components (`/components`)
Re-usable React components that can be shared across any React application in the repo. These are configured to be pulled in as source for application-level compilation via import from `@ge/components/{component}`.

#### Mocks (`/mocks`)
Static mock JSON objects representing the data required for the web client to render correctly. This provides a shared package for contract-driven development between the services layer and the client. This package also includes the generators that are used to dynamically build these JSON objects, so active development should happen in the generators _not_ the entity JSON files themselves.

#### Tokens (`/tokens`)
Common codified design decisions such as color palette, typography, spacing, etc.

### `/.circleci`
Configurations required for CircleCI to perform CI/CD workflows.

### `/.deploy`
AWS CloudFormation templates and required dependencies for environment deploys.

## Branching strategy
The MVP project will follow a simple Git Flow model to allow for a stable demo branch (`master`), a bleeding-edge completed feature branch (`develop`), and multiple feature branches (`{feature|bug|chore}/{ticket_number}-{short-description-with-hyphens}`).

> NOTE: Due to AWS stack naming limitations, the branch name cannot exceed 35 characters!

## Continuous Integration and Delivery
The PoC is built using AWS SAM and CloudFormation templates deployed using CircleCI. These infrastructure definitions can be ported to any build tool (e.g. - Jenkins) and the templates will function in the same way within the GE AWS environment.

### Branch deployments
Upon branch creation, a full serverless stack is automatically created and deployed using the code from the feature branch. Each commit runs the full build/test/analysis pipeline and, upon success, deploys deltas to the environment. This is a valuable tool for sharing in-flight work for feedback, review, UAT, etc.

## Local DynamoDB Setup
DynamoDb can run as a docker container on the local system and can be developed against by changing the DynamoDb endpoint that the local Lambda function uses.

### Create a local DynamoDb instance
1. `docker pull amazon/dynamodb-local`
2. `docker run -p 8000:8000 --name dynamo amazon/dynamodb-local`

### Set up a DynamoDb table to use
1. Define the table in a JSON file. If the table name in the template.yaml is the branch name + a suffix, the local branch name will resolve to "local".
Example: If the table is $branch + "_Users", the JSON will look like
```
{
    "TableName": "local_Users",
    "AttributeDefinitions": [
      { "AttributeName": "ID", "AttributeType": "S" },
      { "AttributeName": "EN_TYPE", "AttributeType": "S" }
    ],
    "KeySchema": [
      { "AttributeName": "ID", "KeyType": "HASH" }
    ],
    "ProvisionedThroughput": {
      "ReadCapacityUnits": 1,
      "WriteCapacityUnits": 1
    },
    "GlobalSecondaryIndexes": [
        {
            "IndexName": "EntityIndex",
            "KeySchema": [
                { "AttributeName": "EN_TYPE", "KeyType": "HASH" }
            ],
            "Projection": {
                "ProjectionType": "ALL"
            },
            "ProvisionedThroughput": {
                "ReadCapacityUnits": 1,
                "WriteCapacityUnits": 1
            }
        }
    ]
}
```
2. `aws dynamodb create-table --cli-input-json file://test-db/users-table.json --endpoint-url http://localhost:8000`
  * _Note: If the Docker container is removed, the table will need to be recreated._

### Useful DynamoDb commands
* List tables
  * `aws dynamodb list-tables --endpoint-url http://localhost:8000`
* Show all data in a table
  * `aws dynamodb scan --table-name local_Users --endpoint-url http://localhost:8000`

### Running Lambda functions against local DynamoDb
The DynamoDb utils in the serverless code checks if the function is being run locally and dynamically sets up the DynamoDb client to run against http://localhost:8000.  Nothing needs to be done to run a Lambda function locally against DynamoDb.
Example:
  * `yarn build; sam local invoke -e test-events/GetPrefs.json --debug GetUsersPrefs`

