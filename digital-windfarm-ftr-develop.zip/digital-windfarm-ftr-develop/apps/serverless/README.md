# Serverless Setup
Prerequisites for serverless development:
  * Local development system setup (Install the tooling necessary to build and deploy the code to AWS)
  * AWS cloud environment setup (One time setup of the AWS assets required for deployment)

## Windows Development Setup
1. Use RSA Token with F5 VPN
   * F5 VPN for accessing AWS
   * Disconnect from VPN for accessing public github Crux repo

2. Set proxies in Powershell:<br>
   dir env:
   ```
   $env:http_proxy = 'http://PITC-Zscaler-EMEA-Amsterdam3PR.proxy.corporate.ge.com'
   $env:https_proxy = 'https://PITC-Zscaler-EMEA-Amsterdam3PR.proxy.corporate.ge.com:80'
   ```

3. Install AWS CLI
   https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2-windows.html

4. Install AWS SAM CLI
   https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/serverless-sam-cli-install-windows.html

5. Download CA Certificate from GE to allow CLI access to ~/.aws
   https://static.gecirtnotification.com/browser_remediation/packages/GE_External_Root_CA_2_1.crt

6. Configure AWS Tooling
   File:
   ```
   C:\Users\USERNAME\.aws\config
   ```
   Contents:
   ```
   [default]
   aws_access_key_id = your_access_key_id
   aws_secret_access_key = your_secret_access_key
   region = us-east-1
   ca_bundle = ~/.aws/GE_External_Root_CA_2_1.crt
   ```

7. Install NodeJS
   https://nodejs.org/en/download/
   * Update the NPM proxies:
   ```
   npm config set proxy http://grc-india-pitc-bangaz.proxy.corporate.gtm.ge.com:8080/
   npm config set https-proxy http://grc-india-pitc-bangaz.proxy.corporate.gtm.ge.com:8080/
   ```
   * Globally configure npm:
   ```
   npm config set strict-ssl false
   npm install -g windows-build-tools
   ```

8. Install Yarn
https://classic.yarnpkg.com/en/docs/install/#windows-stable
   ```
   yarn config set "strict-ssl" false -g
   ```

## <a name="testing-locally"></a>Testing Functions Locally
1. Prerequisites:
    * AWS CLI (Installed in dev setup above)
    * SAM CLI (Installed in dev setup above)
    * Docker - https://docs.docker.com/get-docker/

2. Change to the directory of the function to test (i.e. `/api`) and create a test event
in the `test-events` directory.  Assuming the trigger is rest, the format will be close
to the following:
    ```
    {
      "httpMethod": "GET",
      "pathParameters": {
        "id": "5dad4e5350b3aecc4c861b12"
      }
    }

    ```

3. Once the test event is created, compile and build the function by running `yarn build`.
4. Finally, execute the function locally referencing the test event you just created using parameter overrides for the correct GE backend environment:
    ```
    sam local invoke SiteManagerTaskScheduleFunc -e test-events/SiteManagerTaskScheduleFunc.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
   ```

## Debugging Functions Locally
1. Prerequisites:
    * AWS CLI (Installed in dev setup above)
    * SAM CLI (Installed in dev setup above)
    * Docker - https://docs.docker.com/get-docker/
    * VSCode

2. Follow the steps from [Testing Functions Locally](#testing-locally) to create a test event.

3. Running `yarn build` will generate the debug configurations necessary for VSCode.

4. Execute the following command to execute the function with a debug port enabled with the same parameter overrides for the correct GE backend environment:
    ```
    sam local invoke SiteManagerTaskScheduleFunc -e test-events/SiteManagerTaskScheduleFunc.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com -d 5858
    ```

5. Once the function is listening, set a breakpoint and execute the appropriate VSCode debug configuration,
in this case `SiteManagerTaskScheduleFunc`
    * https://code.visualstudio.com/docs/editor/debugging

## Static AWS Assets Setup (Only needs to be set up one time by an administrator)
1. Register a new domain in Route53
	Example:  `gedwf.com`

2. Create a wildcard certificate in AWS Certificate Manager under us-east-1
    Example:  One certificate for the domains `gedwf.com` and `*.gedwf.com`

3. Create a new user pool in Cognito under us-east-1<br>
    Example name: `ge-dwf`<br>
    Defaults for everything except:
    * Attributes:
        * Uncheck `Enable case insensitivity for username input`
        * Uncheck `Required attribute email`
    * Policies:
        * Only allow administrators to create users
    * MFA and Verifications:
        * No verification

4. Create an Amazon Cognito domain under the new user pool<br>
    Example: https://gedwf.auth.us-east-1.amazoncognito.com

5. Register a new SSO Client with GE to be used with Cognito
    https://oidcapi.corporate.ge.com <br><br>
    Example redirect from Cognito for SSE Client:
    * https://gedwf.auth.us-east-1.amazoncognito.com/oauth2/idpresponse

6. Create a new OIDC Identity Provider under new user pool
    Example:
    * Provider Name: GESSO (Arbitrary name to indicate SSO IPD)
    * Client ID:  <provided by GE SSO registration>
    * Client Secret:  <provided by GE SSO registration - not optional for GE>
    * Attribute request method: GET
    * Authorize scope: profile openid
    * Issuer: https://fssfed.ge.com/fss
    * Endpoint details found from: https://fssfed.ge.com/fss/.well-known/openid-configuration

7. Create private bucket for AWS SAM deployment target<br>
    Example: gedwf-sam-deploy

8. Create DWFCleanupBucketRole in AWS IAM
    * Lambda use case
    * Attach Policies:
      * AmazonS3FullAccess
      * AWSLambdaBasicExecutionRole

9. Create DWFCleanupBucket lambda function
    * us-east-1
    * Author from scratch
    * Python 3.7
    * Permissions - use existing role: DWFCleanupBucketRole
    * Python Function: from ge-digital-windfarm-ops repository
      * DWFCleanupBucket.py

10. Create DWFLookupClientIdRole in AWS IAM
    * Lambda use case
    * Attach Policies:
      * AmazonCognitoReadOnly
      * AWSLambdaBasicExecutionRole

11. Create DWFLookupClientId lambda function
    * us-east-1
    * Author from scratch
    * Node 12.x
    * Permissions - use existing role: DWFLookupClientIdRole
    * Python Function: from ge-digital-windfarm-ops repository
      * DWFLookupClientIdRole.js

12. Create API Gateway for client lookup function
    * Rest API
    * Name:  DWF-API
    * Endpoint Type: Regional
    * Create resources:  `/auth/client-id/{poolid}`
      * Enable CORS
      * No Proxy Resources
    * Create GET method on `/auth/client-id/{poolid}`
      * Lambda Function
      * Use Lambda Proxy Integration: YES
      * us-east-1
      * DWFLookupClientId
    * Deploy API to `prod` stage
    * Note the deployed URL for the DWF UI `.env.prod` file
