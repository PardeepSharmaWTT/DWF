import { InputEntityType } from '@ge/serverless-models/src/rendigital/enums';
import { Analyze } from '@ge/serverless-orchestration';
import {
  bodyParserInterceptor,
  buildAuthHeader,
  intercept,
  responses,
  getTenantId,
} from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';

export const getIecCategory = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    console.debug(`Getting IEC data with params '${JSON.stringify(params)}'`);

    const { categories, endDate, entityId, entityType, startDate } = params;

    requireNotEmpty({ categories, endDate, entityType, startDate });

    const headers = buildAuthHeader(event);
    const tenantId = getTenantId(event);

    const entityIds = entityType === InputEntityType.FLEET ? [tenantId] : [entityId];

    const data = await Analyze.reliability.getIecData({ ...params, entityIds }, headers);

    console.debug('Returning data in response');

    const response = { data };

    return responses.success(response);
  } catch (err) {
    console.error(err);

    return responses.error(err);
  }
});

export const getIecCategoryAssets = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    console.debug(`Getting IEC asset data with params '${JSON.stringify(params)}'`);

    const { category, endDate, entityType, entityId, iecStates, startDate } = params;

    const headers = buildAuthHeader(event);
    const tenantId = getTenantId(event);

    const entityIds = entityType === InputEntityType.FLEET ? [tenantId] : [entityId];

    requireNotEmpty({ category, endDate, entityType, iecStates, startDate });

    const data = await Analyze.reliability.getIecAssetData({ ...params, entityIds }, headers);

    console.debug('Returning data in response');

    const response = { data };

    return responses.success(response);
  } catch (err) {
    console.error(err);

    return responses.error(err);
  }
});

export const getOemCategoryAssets = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    const { category, endDate, entityId = 'geservdrZp', entityType, startDate } = params;

    console.debug(`Getting OEM asset data with params '${JSON.stringify(params)}'`);

    requireNotEmpty({ category, endDate, entityType, startDate });

    const headers = buildAuthHeader(event);

    const data = await Analyze.reliability.getOemAssetData({ ...params, entityId }, headers);

    console.debug('Returning data in response');

    const response = { data };

    return responses.success(response);
  } catch (err) {
    console.error(err);

    return responses.error(err);
  }
});

export const getIecTurbineMetadataByCategory = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    console.debug(`Getting IEC Turbine Meta-data with params '${JSON.stringify(params)}'`);

    const { category, endDate, entityId, entityType, startDate } = params;

    requireNotEmpty({ category, endDate, entityType, startDate });

    const headers = buildAuthHeader(event);
    const tenantId = getTenantId(event);

    const entityIds = entityType === InputEntityType.FLEET ? [tenantId] : [entityId];
    const data = await Analyze.reliability.getIecTurbineMetadataByKpiCategory({
      headers,
      entityIds,
      ...params,
    });

    console.debug('Returning data in response');

    const response = { data };

    return responses.success(response);
  } catch (err) {
    console.error(err);

    return responses.error(err);
  }
});
