const { Analyze } = require('@ge/serverless-orchestration');
const {
  bodyParserInterceptor,
  intercept,
  buildAuthHeader,
  responses,
} = require('@ge/serverless-utils');
export const getFileDetailsForWindTurbines = intercept([bodyParserInterceptor], async (event) => {
  const headers = buildAuthHeader(event);
  const {
    queryStringParameters: {
      siteId,
      assetId,
      categoryId,
      subCategoryId,
      startTime,
      endTime,
      fileType,
    },
  } = event;
  try {
    const resp = await Analyze.fileData.FileDetails.getFileDetailsForWindTurbines(
      siteId,
      assetId,
      categoryId,
      subCategoryId,
      startTime,
      endTime,
      fileType,
      headers,
    );
    return responses.success(resp);
  } catch (err) {
    console.error(err);
    return responses.error(err);
  }
});
export const getFileDownloadData = intercept([bodyParserInterceptor], async (event) => {
  const headers = buildAuthHeader(event);
  const {
    queryStringParameters: { s3FileKey },
  } = event;
  console.log('s3FileKey=================new============', s3FileKey);
  try {
    const resp = await Analyze.fileData.FileDetails.downloadFilesService(s3FileKey, headers);
    console.debug(resp);
    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
});
/* export const getFileDetailsForWindTurbines = intercept([bodyParserInterceptor], async (event) => {
  const headers = buildAuthHeader(event);
  const { body: fileInputParameters } = event;
  try {
    const resp = await Analyze.fileData.FileDetails.getFileDetailsForWindTurbines(
      fileInputParameters,
      headers,
    );
    return responses.success(resp);
  } catch (err) {
    console.error(err);
    return responses.error(err);
  }
});

export const getFileDownloadData = intercept([bodyParserInterceptor], async (event) => {
  const headers = buildAuthHeader(event);
  const { body: data } = event;
  const s3FileKey = data.selectedKeys;
  try {
    const resp = await Analyze.fileData.FileDetails.downloadFilesService(s3FileKey, headers);
    console.debug(resp);
    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
}); */
