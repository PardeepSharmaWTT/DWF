/* test locally
sam local invoke ConditionsKpiData -e test-events/ConditionsKpiData.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
*/

import { Analyze } from '@ge/serverless-orchestration';
import { bodyParserInterceptor, buildAuthHeader, intercept, responses } from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';

export const getConditionsKpiData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    console.debug(`Getting condition data with params '${JSON.stringify(params)}'`);

    const { categories, endDate, startDate } = params;

    requireNotEmpty({ categories, endDate, startDate });

    const headers = buildAuthHeader(event);

    const response = await Analyze.conditionsByKpi(params, headers);

    console.debug('Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
