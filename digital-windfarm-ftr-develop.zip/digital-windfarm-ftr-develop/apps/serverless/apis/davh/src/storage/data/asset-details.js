const assetDetails = {
  customerId: '101',
  customerName: 'Customer 1',
  siteId: '1001',
  siteName: 'Storage Site 1',
  assetId: 'GESTO_BLXW_MVSG01_XFR01_INV01',
  assetName: 'PCS 01',
  inverterMake: 'GE',
  internalTemp: '22',
  units: {
    internalTemp: '°C',
  },
};
module.exports = { assetDetails };
