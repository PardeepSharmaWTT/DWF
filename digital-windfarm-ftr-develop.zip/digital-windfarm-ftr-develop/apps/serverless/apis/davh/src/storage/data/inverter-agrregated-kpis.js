const siteAggregatedKpis = {
    data: {
        kpis: {
            availability: {
                value: 99,
                unit: '%',
            },
            efficiency: {
                charge: {
                    value: 85,
                    unit: '%',
                },
                discharge: {
                    value: 85,
                    unit: '%',
                },
            },
            conversionEfficiency: {
                charge: {
                    value: 70,
                    unit: '%',
                },
                discharge: {
                    value: 60,
                    unit: '%',
                },
            },
        },
    },
};
module.exports = { siteAggregatedKpis };
