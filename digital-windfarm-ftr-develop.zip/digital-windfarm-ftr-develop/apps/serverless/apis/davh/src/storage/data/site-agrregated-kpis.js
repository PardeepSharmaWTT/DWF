const siteAggregatedKpis = {
  data: {
    kpis: {
      availability: {
        value: 99,
        unit: '%',
      },
      efficiency: {
        charge: {
          value: 85,
          unit: '%',
        },
        discharge: {
          value: 85,
          unit: '%',
        },
      },
      activeEnergyUsage: {
        charge: {
          value: 3900,
          unit: 'MWh',
        },
        discharge: {
          value: 3900,
          unit: 'MWh',
        },
      },
      reactiveEnergyUsage: {
        charge: {
          value: 3900,
          unit: 'MVarh',
        },
        discharge: {
          value: 3900,
          unit: 'MVarh',
        },
      },
      soc: {
        value: 10,
        unit: '%',
      },
      soh: {
        value: 20,
        unit: '%',
      },
    },
  },
};
module.exports = { siteAggregatedKpis };
