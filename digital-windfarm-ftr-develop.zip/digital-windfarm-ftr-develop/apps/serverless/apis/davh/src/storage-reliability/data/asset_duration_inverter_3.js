const assetDurationInverter3 = {
  data: [
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV01',
      value: 15,
      type: 3,
      title: 'PCS 01',
      kpiValue: 0.01,
      totalEvents: 13,
      events: [
        {
          eventId: 1004,
          eventName: 'Loss of DC Controller communication',
          value: 5,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1005,
          eventName: 'Loss of PCS communication',
          value: 4,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1006,
          eventName: 'Loss of Site Controller communication',
          value: 6,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV02',
      value: 10,
      type: 3,
      title: 'PCS 02',
      kpiValue: 0.05,
      totalEvents: 13,
      events: [
        {
          eventId: 1011,
          eventName: 'AC Controller timed out waiting for minimum number of strings connected',
          value: 5,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1012,
          eventName: 'Minimum number of battery strings are not available for startup',
          value: 2,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2005,
          eventName: 'DC booster temperature fault',
          value: 3,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV03',
      value: 30,
      type: 3,
      title: 'PCS 03',
      kpiValue: 0.05,
      totalEvents: 14,
      events: [
        {
          eventId: 2006,
          eventName: 'Inverter general fault',
          value: 8,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2008,
          eventName: 'Inverter general fault',
          value: 8,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2009,
          eventName: 'Line Inverter current fault',
          value: 7,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2010,
          eventName: 'Line Inverter temperature fault',
          value: 7,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV04',
      value: 10,
      type: 3,
      title: 'PCS 04',
      kpiValue: 0.05,
      totalEvents: 12,
      events: [
        {
          eventId: 2011,
          eventName: 'Line Inverter general fault',
          value: 7,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2016,
          eventName: 'Brilliance PCS fault code(s) active, check I/O Variables to identify code(s)',
          value: 3,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG02_XFR01_INV01',
      value: 30,
      type: 3,
      title: 'PCS 05',
      kpiValue: 0.05,
      totalEvents: 15,
      events: [
        {
          eventId: 2021,
          eventName: 'Sleep contactor state fault',
          value: 6,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2027,
          eventName: 'DC booster current fault',
          value: 9,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2040,
          eventName: 'PCS HW E-Stop"',
          value: 7,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 3005,
          eventName: 'Voltage out of tolerance during startup',
          value: 6,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 3006,
          eventName: 'Tray voltage imbalance protection fault',
          value: 2,
          siteName: 'Storage Site 1',
        },
      ],
    },
  ],
  total: 95,
  unit: 'hours',
};

module.exports = { assetDurationInverter3 };
