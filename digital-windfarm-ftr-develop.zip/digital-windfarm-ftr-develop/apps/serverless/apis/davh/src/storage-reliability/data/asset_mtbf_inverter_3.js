const assetMtbfInverter3 = {
  data: [
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV01',
      value: 60,
      type: 3,
      title: 'PCS 01',
      kpiValue: 0.01,
      totalEvents: 6,
      events: [
        {
          eventId: 1004,
          eventName: 'Loss of DC Controller communication',
          value: 13.5,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1005,
          eventName: 'Loss of PCS communication',
          value: 11.5,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1006,
          eventName: 'Loss of Site Controller communication',
          value: 10,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1011,
          eventName: 'AC Controller timed out waiting for minimum number of strings connected',
          value: 10,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1012,
          eventName: 'Minimum number of battery strings are not available for startup',
          value: 10,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2005,
          eventName: 'DC booster temperature fault',
          value: 5,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV02',
      value: 50,
      type: 3,
      title: 'PCS 02',
      kpiValue: 0.05,
      totalEvents: 3,
      events: [
        {
          eventId: 1011,
          eventName: 'AC Controller timed out waiting for minimum number of strings connected',
          value: 14.5,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 1012,
          eventName: 'Minimum number of battery strings are not available for startup',
          value: 14.5,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2005,
          eventName: 'DC booster temperature fault',
          value: 20,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV03',
      value: 40,
      type: 3,
      title: 'PCS 03',
      kpiValue: 0.05,
      totalEvents: 4,
      events: [
        {
          eventId: 2006,
          eventName: 'Inverter general fault',
          value: 10,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2008,
          eventName: 'Inverter general fault',
          value: 10,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2009,
          eventName: 'Line Inverter current fault',
          value: 10,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2010,
          eventName: 'Line Inverter temperature fault',
          value: 10,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG01_XFR01_INV04',
      value: 50,
      type: 3,
      title: 'PCS 04',
      kpiValue: 0.05,
      totalEvents: 2,
      events: [
        {
          eventId: 2011,
          eventName: 'Line Inverter general fault',
          value: 25,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2016,
          eventName: 'Brilliance PCS fault code(s) active, check I/O Variables to identify code(s)',
          value: 25,
          siteName: 'Storage Site 1',
        },
      ],
    },
    {
      id: 'GESTO_BLXW_MVSG02_XFR01_INV01',
      value: 45,
      type: 3,
      title: 'PCS 05',
      kpiValue: 0.05,
      totalEvents: 5,
      events: [
        {
          eventId: 2021,
          eventName: 'Sleep contactor state fault',
          value: 15,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2027,
          eventName: 'DC booster current fault',
          value: 10,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 2040,
          eventName: 'PCS HW E-Stop"',
          value: 8,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 3005,
          eventName: 'Voltage out of tolerance during startup',
          value: 7,
          siteName: 'Storage Site 1',
        },
        {
          eventId: 3006,
          eventName: 'Tray voltage imbalance protection fault',
          value: 5,
          siteName: 'Storage Site 1',
        },
      ],
    },
  ],
  total: 245,
  unit: 'hours',
};

module.exports = { assetMtbfInverter3 };
