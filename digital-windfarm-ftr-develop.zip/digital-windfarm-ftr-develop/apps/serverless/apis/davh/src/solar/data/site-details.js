/* eslint-disable prettier/prettier */
const siteDetails = {
  id: '1001',
  featureFlags: {
    analyze: true,
    common: true,
    undefined: true,
    manage: true,
    monitor: true,
  },
  name: 'Solar Site 1',
  country: 'England',
  customer: {
    id: 'GE INDIA INDUSTRIAL PRIVATE LIMITED',
    name: 'Customer 1',
  },
  timezone: 'Europe/London',
  region: {
    id: 'reg_apac',
  },
};
module.exports = { siteDetails };
