const assetDetails = {
  customerId: '101',
  customerName: 'Customer 1',
  siteId: '1001',
  siteName: 'Solar Site 1',
  assetId: 'TECO_BB1_B02_INV03',
  assetName: 'Inverter 01',
  inverterMake: 'GE',
  internalTemp: '22',
  units: {
    internalTemp: '°C',
  },
};
module.exports = { assetDetails };
