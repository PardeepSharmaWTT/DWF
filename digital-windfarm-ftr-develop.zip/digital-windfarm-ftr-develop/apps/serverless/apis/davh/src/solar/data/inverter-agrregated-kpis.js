const inverterAggregatedKpis = {
    data: {
      kpis: {
        availability: {
            value: 99,
            unit: '%',
        },
        yield: {
            value: 3,
            unit: 'kWh/kWp',
        },
        energy: {
            value: 2303,
            unit: 'MWh',
        },
        efficiency: {
            value: 94,
            unit: '%'
        }
      }
    }
  };
  module.exports = { inverterAggregatedKpis };
  
