const { intercept } = require('@ge/serverless-utils/src/interceptor-utils');
const { responses } = require('@ge/serverless-utils/src/serverless-utils');

const { assetDetails } = require('./data/asset-details');
const { inverterData } = require('./data/inverter-list');
const { siteAggregatedKpis } = require('./data/site-agrregated-kpis');
const { siteDetails } = require('./data/site-details');
const { inverterAggregatedKpis } = require('./data/inverter-agrregated-kpis');

export const getInverterList = intercept([], async () => {
  try {
    let responseData;
    responseData = JSON.stringify(inverterData);
    return responses.success(responseData);
  } catch (err) {
    return responses.error(err);
  }
});

export const getsiteAggregatedKpis = intercept([], async (event) => {
  try {
    const { assetType } = JSON.parse(event.body);
    let responseData;
    if (assetType === 'inverter') {
      responseData = JSON.stringify(inverterAggregatedKpis);
    } else {
      responseData = JSON.stringify(siteAggregatedKpis);
    }
    return responses.success(responseData);
  } catch (err) {
    return responses.error(err);
  }
});

export const getsiteDetails = intercept([], async (event) => {
  try {
    const { id } = JSON.parse(event.body);
    siteDetails.id = id;
    let responseData;
    responseData = JSON.stringify(siteDetails);
    return responses.success(responseData);
  } catch (err) {
    return responses.error(err);
  }
});

export const getAssetDetails = intercept([], async (event) => {
  try {
    const { id } = JSON.parse(event.body);
    assetDetails.id = id;
    let responseData;
    responseData = JSON.stringify(assetDetails);
    return responses.success(responseData);
  } catch (err) {
    return responses.error(err);
  }
});
