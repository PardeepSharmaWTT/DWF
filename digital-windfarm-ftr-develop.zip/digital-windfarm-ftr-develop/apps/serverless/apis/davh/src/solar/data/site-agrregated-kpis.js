const siteAggregatedKpis = {
  data: {
    kpis: {
      yield: {
        value: 3,
        unit: 'kWh/kWp',
      },
      availability: {
        value: 99,
        unit: '%',
      },
      power: {
        value: 2303,
        unit: 'MW',
      },
      energy: {
        value: 3900,
        unit: 'MWh',
      },
      capacityFactor: {
        value: 3,
        unit: '%',
      },
    },
  },
};
module.exports = { siteAggregatedKpis };
