const availabilityTrend = {
  data: {
    availability: {
      timeSeriesData: [
        {
          date: 1654041600000,
          value: 91,
        },
        {
          date: 1654128000000,
          value: 92,
        },
        {
          date: 1654214400000,
          value: 90,
        },
        {
          date: 1654300800000,
          value: 94,
        },
        {
          date: 1654387200000,
          value: 96,
        },
        {
          date: 1654473600000,
          value: 94,
        },
        {
          date: 1654560000000,
          value: 92,
        },
        {
          date: 1654646400000,
          value: 90,
        },
        {
          date: 1654732800000,
          value: 97,
        },
        {
          date: 1654819200000,
          value: 98,
        },
        {
          date: 1654905600000,
          value: 94,
        },
        {
          date: 1654992000000,
          value: 96,
        },
        {
          date: 1655078400000,
          value: 99,
        },
        {
          date: 1655164800000,
          value: 95,
        },
      ],
      units: '%',
    },
  },
};

module.exports = { availabilityTrend };
