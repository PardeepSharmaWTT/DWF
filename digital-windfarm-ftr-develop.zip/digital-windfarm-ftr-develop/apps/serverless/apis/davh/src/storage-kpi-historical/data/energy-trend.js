const energyTrend = {
  data: {
    bessChargeEnergy: {
      timeSeriesData: [
        {
          date: 1654041600000,
          value: 8,
        },
        {
          date: 1654128000000,
          value: 12,
        },
        {
          date: 1654214400000,
          value: 14,
        },
        {
          date: 1654300800000,
          value: 22,
        },
        {
          date: 1654387200000,
          value: 16,
        },
        {
          date: 1654473600000,
          value: 24,
        },
        {
          date: 1654560000000,
          value: 19,
        },
        {
          date: 1654646400000,
          value: 18,
        },
        {
          date: 1654732800000,
          value: 22,
        },
        {
          date: 1654819200000,
          value: 26,
        },
        {
          date: 1654905600000,
          value: 16,
        },
        {
          date: 1654992000000,
          value: 26,
        },
        {
          date: 1655078400000,
          value: 20,
        },
        {
          date: 1655164800000,
          value: 22,
        },
      ],
      units: 'MWh',
    },
    bessDischargeEnergy: {
      timeSeriesData: [
        {
          date: 1654041600000,
          value: 2,
        },
        {
          date: 1654128000000,
          value: 2.4,
        },
        {
          date: 1654214400000,
          value: 4,
        },
        {
          date: 1654300800000,
          value: 3.6,
        },
        {
          date: 1654387200000,
          value: 4.6,
        },
        {
          date: 1654473600000,
          value: 4,
        },
        {
          date: 1654560000000,
          value: 6,
        },
        {
          date: 1654646400000,
          value: 3.8,
        },
        {
          date: 1654732800000,
          value: 4,
        },
        {
          date: 1654819200000,
          value: 8,
        },
        {
          date: 1654905600000,
          value: 7,
        },
        {
          date: 1654992000000,
          value: 6.5,
        },
        {
          date: 1655078400000,
          value: 8,
        },
        {
          date: 1655164800000,
          value: 10,
        },
      ],
      units: 'MWh',
    },
  },
};
module.exports = { energyTrend };
