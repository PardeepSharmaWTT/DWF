const { intercept } = require('@ge/serverless-utils/src/interceptor-utils');
const { responses } = require('@ge/serverless-utils/src/serverless-utils');

const { availabilityTrend } = require('./data/availability-trend');
const { energyTrend } = require('./data/energy-trend');
const { inverterProductionTrendData } = require('./data/inverter-production-trend.js');
const { powerTrend } = require('./data/power-trend');
const { weatherTrendChart } = require('./data/weather-trend-chart');

export const getkpiSiteStorageHistorical = intercept([], async (event) => {
  try {
    const { kpiList } = JSON.parse(event.body);
    let responseData;
    if (kpiList[0] === 'activePower') {
      responseData = JSON.stringify(powerTrend);
      return responses.success(responseData);
    } else if (kpiList[0] === 'bessChargeEnergy' && kpiList[1] === 'bessDischargeEnergy') {
      responseData = JSON.stringify(energyTrend);
      return responses.success(responseData);
    } else if (kpiList[0] === 'availability') {
      responseData = JSON.stringify(availabilityTrend);
      return responses.success(responseData);
    } else if (kpiList[0] === 'ambTemp' && kpiList[1] === 'moduleTemp') {
      responseData = JSON.stringify(weatherTrendChart);
      return responses.success(responseData);
    }
    return responses.success([]);
  } catch (err) {
    return responses.error(err);
  }
});

export const getkpiStorageInverterHistorical = intercept([], async (event) => {
  try {
    const { kpiList } = JSON.parse(event.body);
    let responseData;
    if (kpiList[0] === 'actualPower') {
      responseData = JSON.stringify(inverterProductionTrendData);
      return responses.success(responseData);
    }
    return responses.success([]);
  } catch (err) {
    return responses.error(err);
  }
});
