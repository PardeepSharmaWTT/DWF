const inverterCapacityFactorTrend = {
  data: {
    capacityFactor: {
      timeSeriesData: [
        {
          date: 1654041600000,
          value: 2,
        },
        {
          date: 1654128000000,
          value: 2.5,
        },
        {
          date: 1654214400000,
          value: 3,
        },
        {
          date: 1654300800000,
          value: 2.8,
        },
        {
          date: 1654387200000,
          value: 3.4,
        },
        {
          date: 1654473600000,
          value: 2.2,
        },
        {
          date: 1654560000000,
          value: 2.8,
        },
        {
          date: 1654646400000,
          value: 2.8,
        },
        {
          date: 1654732800000,
          value: 3.6,
        },
        {
          date: 1654819200000,
          value: 2.5,
        },
        {
          date: 1654905600000,
          value: 3.5,
        },
        {
          date: 1654992000000,
          value: 2.8,
        },
        {
          date: 1655078400000,
          value: 3.4,
        },
        {
          date: 1655164800000,
          value: 4,
        },
      ],
      units: '%',
    },
  },
};
module.exports = { inverterCapacityFactorTrend };
