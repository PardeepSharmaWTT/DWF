const prTrend = {
  data: {
    pr: {
      timeSeriesData: [
        {
          date: 1654041600000,
          value: 70,
        },
        {
          date: 1654128000000,
          value: 75,
        },
        {
          date: 1654214400000,
          value: 78,
        },
        {
          date: 1654300800000,
          value: 80,
        },
        {
          date: 1654387200000,
          value: 75,
        },
        {
          date: 1654473600000,
          value: 76,
        },
        {
          date: 1654560000000,
          value: 82,
        },
        {
          date: 1654646400000,
          value: 70,
        },
        {
          date: 1654732800000,
          value: 80,
        },
        {
          date: 1654819200000,
          value: 85,
        },
        {
          date: 1654905600000,
          value: 82,
        },
        {
          date: 1654992000000,
          value: 88,
        },
        {
          date: 1655078400000,
          value: 78,
        },
        {
          date: 1655164800000,
          value: 90,
        },
      ],
      units: '%',
    },
  },
};
module.exports = { prTrend };
