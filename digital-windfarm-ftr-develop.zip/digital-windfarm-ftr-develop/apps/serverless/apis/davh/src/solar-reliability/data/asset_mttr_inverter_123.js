const assetMttrInverter4 = {
  data: [
    {
      id: 'TECO_BB1_B02_INV03',
      value: 2,
      type: 4,
      title: 'INV 01',
      kpiValue: 0.01,
      totalEvents: 13,
      events: [
        {
          eventId: 3502,
          eventName: 'GFDI HAS TRIPPED',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 8713,
          eventName: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
          value: 1,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 3517,
          eventName: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV02',
      value: 3,
      type: 4,
      title: 'INV 02',
      kpiValue: 0.05,
      totalEvents: 13,
      events: [
        {
          eventId: 3601,
          eventName: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 3112,
          eventName: 'GFDI HAS TRIPPED',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 1223,
          eventName: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 'TECO_BB1_B01_INV04',
      value: 5,
      type: 4,
      title: 'INV 03',
      kpiValue: 0.05,
      totalEvents: 14,
      events: [
        {
          eventId: 8713,
          eventName: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
          value: 1,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2008,
          eventName: 'Inverter general fault',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2009,
          eventName: 'Line Inverter current fault',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2010,
          eventName: 'Line Inverter temperature fault',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV01',
      value: 1,
      type: 4,
      title: 'INV 04',
      kpiValue: 0.05,
      totalEvents: 12,
      events: [
        {
          eventId: 2011,
          eventName: 'Line Inverter general fault',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2016,
          eventName: 'Brilliance INV fault code(s) active, check I/O Variables to identify code(s)',
          value: 1,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV04',
      value: 2,
      type: 4,
      title: 'INV 05',
      kpiValue: 0.05,
      totalEvents: 15,
      events: [
        {
          eventId: 2021,
          eventName: 'Sleep contactor state fault',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2027,
          eventName: 'DC booster current fault',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2040,
          eventName: 'INV HW E-Stop"',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 3005,
          eventName: 'Voltage out of tolerance during startup',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 3006,
          eventName: 'Tray voltage imbalance protection fault',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
  ],
  total: 13,
  unit: 'hours',
};

module.exports = { assetMttrInverter4 };
