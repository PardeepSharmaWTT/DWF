const durationInverter2 = {
  data: [
    {
      id: 3517,
      value: 1104.3,
      type: 2,
      title: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
      kpiValue: 0.01,
      totalAssets: 7,
      assets: [
        {
          assetId: 'TECO_BB1_B02_INV03',
          assetName: 'INV 01',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV02',
          assetName: 'INV 02',
          value: 1,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B01_INV04',
          assetName: 'INV 03',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV01',
          assetName: 'INV 04',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV04',
          assetName: 'INV 05',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 3601,
      value: 1,
      type: 2,
      title: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
      kpiValue: 0.51,
      totalAssets: 8,
      assets: [
        {
          assetId: 'TECO_BB1_B01_INV03',
          assetName: 'INV 06',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B01_INV05',
          assetName: 'INV 07',
          value: 1,
          siteName: 'Solar Site 1',
        },
      ],
    },
  ],
  total: 1105.3,
  unit: 'hours',
};

module.exports = { durationInverter2 };
