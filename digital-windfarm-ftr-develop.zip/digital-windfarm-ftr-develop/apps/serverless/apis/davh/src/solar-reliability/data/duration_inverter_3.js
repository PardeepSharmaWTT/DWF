const durationInverter3 = {
  data: [
    {
      id: 2211,
      value: 10,
      type: 3,
      title: 'GFDI HAS TRIPPED',
      kpiValue: 0.01,
      totalAssets: 7,
      assets: [
        {
          assetId: 'TECO_BB1_B02_INV03',
          assetName: 'INV 01',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV02',
          assetName: 'INV 02',
          value: 1,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B01_INV04',
          assetName: 'INV 03',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV01',
          assetName: 'INV 04',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV04',
          assetName: 'INV 05',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 3245,
      value: 11,
      type: 3,
      title: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
      kpiValue: 0.05,
      totalAssets: 8,
      assets: [
        {
          assetId: 'TECO_BB1_B01_INV03',
          assetName: 'INV 06',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B01_INV05',
          assetName: 'INV 07',
          value: 1,
          siteName: 'Solar Site 1',
        },
      ],
    },
  ],
  total: 21,
  unit: 'hours',
};

module.exports = { durationInverter3 };
