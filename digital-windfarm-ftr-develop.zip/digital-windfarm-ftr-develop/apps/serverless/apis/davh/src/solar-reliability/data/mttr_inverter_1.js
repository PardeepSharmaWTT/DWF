const mttrInverter1 = {
  data: [
    {
      id: 3501,
      value: 73.6,
      type: 1,
      title: 'INSULATION MONITORING DEVICE HAS MEASURED A TOO LOW GROUNDING RESISTANCE',
      kpiValue: 0.01,
      totalAssets: 15,
      assets: [
        {
          assetId: 'TECO_BB1_B02_INV03',
          assetName: 'INV 01',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV02',
          assetName: 'INV 02',
          value: 1,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B01_INV04',
          assetName: 'INV 03',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV01',
          assetName: 'INV 04',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B02_INV04',
          assetName: 'INV 05',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 8713,
      value: 0.1,
      type: 1,
      title: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
      kpiValue: 0.01,
      totalAssets: 12,
      assets: [
        {
          assetId: 'TECO_BB1_B01_INV03',
          assetName: 'INV 06',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          assetId: 'TECO_BB1_B01_INV05',
          assetName: 'INV 07',
          value: 1,
          siteName: 'Solar Site 1',
        },
      ],
    },
  ],
  total: 73.7,
  unit: 'hours',
};

module.exports = { mttrInverter1 };
