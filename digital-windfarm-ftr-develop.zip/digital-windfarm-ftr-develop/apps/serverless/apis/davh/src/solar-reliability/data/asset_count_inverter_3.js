const assetCountInverter3 = {
  data: [
    {
      id: 'TECO_BB1_B02_INV03',
      value: 2,
      type: 3,
      title: 'INV 01',
      kpiValue: 0.01,
      totalEvents: 13,
      events: [
        {
          eventId: 3502,
          eventName: 'GFDI HAS TRIPPED',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 8713,
          eventName: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
          value: 1,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 3517,
          eventName: 'INSULATION MEASUREMENT BEING PERFORMED - INVERTER IS IN STANDBY MODE',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 'TECO_BB1_B02_INV02',
      value: 3,
      type: 3,
      title: 'INV 02',
      kpiValue: 0.05,
      totalEvents: 13,
      events: [
        {
          eventId: 3601,
          eventName: 'ISOLATED OPERATION - LEAKAGE CURRENT TO GROUND AT PV MODULES',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 3112,
          eventName: 'GFDI HAS TRIPPED',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 1223,
          eventName: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
    {
      id: 'TECO_BB1_B01_INV04',
      value: 5,
      type: 3,
      title: 'INV 03',
      kpiValue: 0.05,
      totalEvents: 14,
      events: [
        {
          eventId: 8713,
          eventName: 'FAILURE OF POWER SETPOINTS TRANSMITTED VIA COMMUNICATION',
          value: 1,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2008,
          eventName: 'Inverter general fault',
          value: 2,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2009,
          eventName: 'Line Inverter current fault',
          value: 3,
          siteName: 'Solar Site 1',
        },
        {
          eventId: 2010,
          eventName: 'Line Inverter temperature fault',
          value: 2,
          siteName: 'Solar Site 1',
        },
      ],
    },
  ],
  total: 10,
  unit: 'hours',
};

module.exports = { assetCountInverter3 };
