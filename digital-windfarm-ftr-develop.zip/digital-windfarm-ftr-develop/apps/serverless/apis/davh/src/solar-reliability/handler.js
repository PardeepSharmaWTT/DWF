const { intercept } = require('@ge/serverless-utils/src/interceptor-utils');
const { responses } = require('@ge/serverless-utils/src/serverless-utils');

const { allAssets } = require('./data/all_assets_for_event');
const { allEvents } = require('./data/all_events_for_assets');
const { assetCountInverter1 } = require('./data/asset_count_inverter_1');
const { assetCountInverter4 } = require('./data/asset_count_inverter_123');
const { assetCountInverter2 } = require('./data/asset_count_inverter_2');
const { assetCountInverter3 } = require('./data/asset_count_inverter_3');
const { assetDurationInverter1 } = require('./data/asset_duration_inverter_1');
const { assetDurationInverter4 } = require('./data/asset_duration_inverter_123');
const { assetDurationInverter2 } = require('./data/asset_duration_inverter_2');
const { assetDurationInverter3 } = require('./data/asset_duration_inverter_3');
const { assetMtbfInverter1 } = require('./data/asset_mtbf_inverter_1');
const { assetMtbfInverter4 } = require('./data/asset_mtbf_inverter_123');
const { assetMtbfInverter2 } = require('./data/asset_mtbf_inverter_2');
const { assetMtbfInverter3 } = require('./data/asset_mtbf_inverter_3');
const { assetMttrInverter1 } = require('./data/asset_mttr_inverter_1');
const { assetMttrInverter4 } = require('./data/asset_mttr_inverter_123');
const { assetMttrInverter2 } = require('./data/asset_mttr_inverter_2');
const { assetMttrInverter3 } = require('./data/asset_mttr_inverter_3');
const { countInverter1 } = require('./data/count_inverter_1');
const { countInverter4 } = require('./data/count_inverter_123');
const { countInverter2 } = require('./data/count_inverter_2');
const { countInverter3 } = require('./data/count_inverter_3');
const { durationInverter1 } = require('./data/duration_inverter_1');
const { durationInverter4 } = require('./data/duration_inverter_123');
const { durationInverter2 } = require('./data/duration_inverter_2');
const { durationInverter3 } = require('./data/duration_inverter_3');
const { mtbfInverter1 } = require('./data/mtbf_inverter_1');
const { mtbfInverter4 } = require('./data/mtbf_inverter_123');
const { mtbfInverter2 } = require('./data/mtbf_inverter_2');
const { mtbfInverter3 } = require('./data/mtbf_inverter_3');
const { mttrInverter1 } = require('./data/mttr_inverter_1');
const { mttrInverter4 } = require('./data/mttr_inverter_123');
const { mttrInverter2 } = require('./data/mttr_inverter_2');
const { mttrInverter3 } = require('./data/mttr_inverter_3');

export const getReliability = intercept([], async (event) => {
  try {
    let { groupBy, reportBy, severity, allAssetsForEvent, allEventsForAsset } = JSON.parse(
      event.body,
    );
    if (allAssetsForEvent || allEventsForAsset) {
      reportBy = 'all';
      severity = 1;
    }
    const reliabilityData = {
      assets: {
        count: {
          1: assetCountInverter1,
          2: assetCountInverter2,
          3: assetCountInverter3,
          4: assetCountInverter4,
        },
        duration: {
          1: assetDurationInverter1,
          2: assetDurationInverter2,
          3: assetDurationInverter3,
          4: assetDurationInverter4,
        },
        mttr: {
          1: assetMttrInverter1,
          2: assetMttrInverter2,
          3: assetMttrInverter3,
          4: assetMttrInverter4,
        },
        mtbf: {
          1: assetMtbfInverter1,
          2: assetMtbfInverter2,
          3: assetMtbfInverter3,
          4: assetMtbfInverter4,
        },
        all: {
          1: allEvents,
        },
      },
      events: {
        count: {
          1: countInverter1,
          2: countInverter2,
          3: countInverter3,
          4: countInverter4,
        },
        duration: {
          1: durationInverter1,
          2: durationInverter2,
          3: durationInverter3,
          4: durationInverter4,
        },
        mttr: {
          1: mttrInverter1,
          2: mttrInverter2,
          3: mttrInverter3,
          4: mttrInverter4,
        },
        mtbf: {
          1: mtbfInverter1,
          2: mtbfInverter2,
          3: mtbfInverter3,
          4: mtbfInverter4,
        },
        all: {
          1: allAssets,
        },
      },
    };

    if (
      typeof reliabilityData[groupBy] !== 'undefined' &&
      typeof reliabilityData[groupBy][reportBy] !== 'undefined' &&
      typeof reliabilityData[groupBy][reportBy][severity] !== 'undefined'
    ) {
      let responseData = reliabilityData[groupBy][reportBy][severity] || [];
      return responses.success(JSON.stringify(responseData));
    }
    return responses.success(JSON.stringify([]));
  } catch (err) {
    return responses.error(err);
  }
});
