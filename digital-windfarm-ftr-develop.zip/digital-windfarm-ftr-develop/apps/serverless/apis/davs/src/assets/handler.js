/* test locally
sam local invoke AssetDataExplorer -e test-events/AssetDataExplorer.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
sam local invoke AnalyzeAssetsSignals -e test-events/AssetsSignals.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
*/

import { TimeAggr } from '@ge/models/constants';
import { EntityApi } from '@ge/serverless-http';
import { InputEntityType } from '@ge/serverless-models/src/rendigital/enums';

const analyze = require('@ge/mocks-logic/analyze');
const { Analyze } = require('@ge/serverless-orchestration');
const {
  bodyParserInterceptor,
  buildAuthHeader,
  intercept,
  noMocksInterceptor,
  responses,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getAssetCards = intercept([noMocksInterceptor], async () => {
  try {
    console.debug('Getting all asset KPI cards');

    const response = analyze.getAssetKpiCards();

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getAssetKpiDataBySite = intercept([noMocksInterceptor], async (event) => {
  try {
    const {
      pathParameters: { id },
      queryStringParameters: { categories = [] },
    } = event;
    const categoryArray = categories.split(',');

    console.debug(`Getting Asset KPI data ${categoryArray.join(', ')} for Site ${id}`);

    const response = analyze.getAssetKpiBySite(id, categoryArray);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getAssetKpiData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      body,
      pathParameters: { id },
    } = event;

    console.debug(`Getting KPI data for Asset '${id}' with params '${JSON.stringify(body)}'`);

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      entityType = InputEntityType.TURBINE,
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;
    const entityIds = [id];

    const { data } = await Analyze.kpi.getKpiData(
      {
        ...params,
        entityIds,
        entityType,
        timeAggr,
      },
      headers,
    );

    console.debug('Returning data in response');

    return responses.success({ data });
  } catch (err) {
    return responses.error(err);
  }
});

export const getAssetIecCategory = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      body,
      pathParameters: { id: entityId },
    } = event;

    console.debug(`Getting IEC data for Asset '${entityId}' with params '${JSON.stringify(body)}'`);

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      entityType = InputEntityType.TURBINE,
      ...params
    } = body;

    const data = await Analyze.reliability.getIecData(
      {
        ...params,
        entityIds: [entityId],
        entityType,
      },
      headers,
    );

    console.debug('Returning data in response');

    const response = { data };

    return responses.success(response);
  } catch (err) {
    console.error(err);

    return responses.error(err);
  }
});

export const getAssetPowerCurve = (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { start, end },
  } = event;

  requireNonNull({ start, end });

  const { regression } = event.queryStringParameters || {};
  const regressionBool = regression === 'true';
  console.debug(`Getting asset${regressionBool ? ' regression ' : ' '}power curve for ${id}`);

  const headers = buildAuthHeader(event);

  return Analyze.machineData
    .powerCurveForAsset({ headers, assetId: id, startTime: start, endTime: end })
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
};

export const getAssetDataExplorer = (event) => {
  const {
    queryStringParameters: { assets: assetParam },
  } = event;
  const assetArr = assetParam.split(',');
  console.debug(`Getting data explorer overview for assets ${assetArr}`);

  const headers = buildAuthHeader(event);

  return Analyze.dataExplorer
    .overviewForAssets(assetArr, headers)
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
};

export const getAssetMetricChart = intercept([noMocksInterceptor], async () => {
  try {
    console.debug('Getting metric chart for Asset');

    const response = await analyze.getAssetMetricChart();

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getAssetSignalData = async (event) => {
  const {
    pathParameters: { id: assetId },
    queryStringParameters: { start, end, signalIds },
  } = event;

  try {
    requireNonNull({ start, end, signalIds });
    const signalArr = signalIds.split(',');

    const headers = buildAuthHeader(event);
    const resp = await Analyze.machineData.signalDataForAsset({
      assetId,
      headers,
      startTime: start,
      endTime: end,
      signalIds: signalArr,
    });

    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAssetsSignalData = async (event) => {
  const {
    queryStringParameters: { assetIds, start, end, signalIds, sourceSignalIds, timeAggr },
  } = event;

  try {
    requireNonNull({ assetIds, start, end, signalIds });
    const assetArr = assetIds ? assetIds.split(',') : [];
    const signalArr = signalIds ? signalIds.split(',') : [];
    const sourceSignalArr = sourceSignalIds ? sourceSignalIds.split(',') : [];

    const headers = buildAuthHeader(event);
    const resp = await Analyze.machineData.signalDataForAssets({
      assetIds: assetArr,
      headers,
      startTime: start,
      endTime: end,
      signalIds: signalArr,
      sourceSignalIds: sourceSignalArr,
      timeAggr,
    });

    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getConditionAggregates = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      body,
      pathParameters: { id },
    } = event;

    console.debug(
      `Getting condition data for Asset '${id}' with params '${JSON.stringify(body)}''`,
    );

    const headers = buildAuthHeader(event);

    const { startDate, endDate, ...params } = body;

    requireNonNull({ startDate, endDate });

    const response = await Analyze.conditionsForEntity({
      ...params,
      endDate,
      entityType: InputEntityType.TURBINE,
      headers,
      id,
      startDate,
    });

    console.debug('Returning data in response');

    return responses.success(response);
  } catch (e) {
    return responses.error(e);
  }
});

export const getAssetInfoByID = async (event) => {
  const {
    pathParameters: { id },
  } = event;

  requireNonNull({ id });

  console.debug(`Getting asset info for asset ${id}`);

  const headers = buildAuthHeader(event);

  return EntityApi.Turbines.getWithComponents(id, headers)
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
};
