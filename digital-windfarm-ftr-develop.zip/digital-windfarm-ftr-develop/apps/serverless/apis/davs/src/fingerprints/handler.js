import { fp } from '@ge/serverless-orchestration/src/rendigital/dav';
import { buildAuthHeader } from '@ge/serverless-utils/src/external-api';
import { requireNonNull } from '@ge/util/object-utils';
import { executionTimer } from '@ge/serverless-utils';

const { bodyParserInterceptor, intercept, responses } = require('@ge/serverless-utils');

export const getSensorData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      body: { objectId, detectionId },
    } = event;

    const headers = buildAuthHeader(event);

    requireNonNull({ objectId, detectionId });

    console.debug(
      `[getSensorData] Getting sensor data for objectId ${objectId} and detectionId ${detectionId}`,
    );

    const stopTimer = executionTimer(
      `Api Call Time for sensor data for objectId ${objectId} and detectionId ${detectionId}`,
    );

    const res = await fp.getSensorData(
      {
        objectId,
        detectionId,
      },
      headers,
    );

    stopTimer();
    console.debug('[getSensorData] Returning data in response');

    return responses.success(res);
  } catch (err) {
    return responses.error(err);
  }
});
