const Analyze = require('@ge/serverless-orchestration/src/rendigital/dav');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');

const addOrUpdateMalEvent = async (event) => {
  const { body } = event;

  const headers = buildAuthHeader(event);

  try {
    const response = await Analyze.malEvents.addOrUpdateMalEvent(headers, body);
    return responses.success(response);
  } catch (e) {
    console.error(e);
    return responses.error(e);
  }
};

const deleteMalEvent = async (event) => {
  const { body } = event;

  const headers = buildAuthHeader(event);

  try {
    const response = await Analyze.malEvents.deleteMalEvent(headers, body);
    return responses.success(response);
  } catch (e) {
    console.error(e);
    return responses.error(e);
  }
};

const getAllMalEvents = async (event) => {
  const { body } = event;

  const headers = buildAuthHeader(event);

  try {
    let response = await Analyze.malEvents.getAllMalEvents(headers, body);
    return responses.success(response);
  } catch (e) {
    console.error(e);
    return responses.error(e);
  }
};

const getMalCategories = async (event) => {
  const { queryStringParameters } = event;

  const headers = buildAuthHeader(event);
  const iecCategory = queryStringParameters && queryStringParameters.iecCategory;

  try {
    const response = await Analyze.malEvents.getMalCategories(headers, iecCategory);
    return responses.success(response);
  } catch (e) {
    console.error(e);
    return responses.error(e);
  }
};

module.exports = { addOrUpdateMalEvent, deleteMalEvent, getAllMalEvents, getMalCategories };
