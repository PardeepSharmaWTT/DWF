/* test locally
sam local invoke AnalyzeFleetKpiData -e test-events/AnalyzeFleetKpiData.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
*/

import { SortDirection, TimeAggr } from '@ge/models/constants';
import { InputEntityType } from '@ge/serverless-models/src/rendigital/enums';
import Analyze from '@ge/serverless-orchestration/src/rendigital/dav';
import AvailabilityKpi from '@ge/serverless-orchestration/src/rendigital/dav/availability-kpi';
import { executionTimer } from '@ge/serverless-utils';

const {
  bodyParserInterceptor,
  buildAuthHeader,
  intercept,
  responses,
} = require('@ge/serverless-utils');

export const getFleetKpiData = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      // do we need to map incoming type to internal type?
      entityAggr = InputEntityType.REGION,
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;

    console.debug(
      `[getFleetKpiData] Getting fleet KPI data with headers '${JSON.stringify(
        headers,
      )}' and body '${JSON.stringify(body)}'`,
    );

    // TODO: remove this, it's just a placeholder for now because still required by backend
    // but that is supposed to change since not all calls expect entity ids
    // was told to just pass tenant id along for now
    const entityIds = ['geservdrZp'];
    const entityType = InputEntityType.FLEET;

    const stopTimer = executionTimer(
      `[getFleetKpiData] Api Call Time for fleet KPI with categories ${params &&
        params.categories} is`,
    );
    const response = await Analyze.kpi.getKpiData(
      {
        ...params,
        entityAggr,
        entityIds,
        entityType,
        timeAggr,
      },
      headers,
    );

    stopTimer();
    console.debug('[getFleetKpiData] Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getSitePerformance = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body } = event;

    const headers = buildAuthHeader(event);

    const {
      // assign default params
      pageIndex = 0,
      pageSize = 10,
      // do we need to map incoming type to internal type?
      sortDirection = SortDirection.ASC,
      // is this the right default for this endpoint?
      timeAggr = TimeAggr.DAILY,
      ...params
    } = body;

    console.debug(
      `[getSitePerformance] Getting fleet site performance data with headers '${JSON.stringify(
        headers,
      )}' and body '${JSON.stringify(body)}'`,
    );

    const stopTimer = executionTimer(
      '[getSitePerformance] Api Call Time for fleet site performance is',
    );
    const data = await AvailabilityKpi.getSitePerformance(
      {
        ...params,
        entityAggr: InputEntityType.SITE,
        entityType: InputEntityType.FLEET,
        pageIndex,
        pageSize,
        sortDirection,
        timeAggr,
      },
      headers,
    );

    const response = { data };
    stopTimer();
    console.debug('[getSitePerformance] Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
