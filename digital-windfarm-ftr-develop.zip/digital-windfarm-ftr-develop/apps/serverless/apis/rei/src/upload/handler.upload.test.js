import * as UploadApi from '@ge/serverless-http/src/rendigital/rei/upload-api';
import { buildResponse } from '@ge/serverless-utils';

import * as mockRequest from '../../__mocks__/request/upload';
import * as mockResponse from '../../__mocks__/response/upload';

import * as Uploadfn from './handler';

const mockEvent = {
  headers: mockRequest.sitesNamesInput.headers,
};

const mockEventGetTurbineDetails = {
  headers: mockRequest.sitesNamesInput.headers,
  pathParameters: { siteId: '50003218' },
};

const mockEventGetComponentDetailList = {
  headers: mockRequest.sitesNamesInput.headers,
  pathParameters: { turbineAssetId: '32183887' },
};

const mockFailureRes = {
  config: {},
  message: 'GE Service Error: Request failed with status code 500',
};

describe('Upload', () => {
  describe('handler', () => {
    it('getTurbineTypes Success', async () => {
      jest.spyOn(UploadApi, 'getTurbineTypes').mockImplementation(() => mockResponse.turbineTypes);
      expect(await Uploadfn.getTurbineTypes(mockEvent)).toEqual(
        buildResponse(200, mockResponse.turbineTypes),
      );
    });

    it('getTurbineTypes Failure', async () => {
      jest.spyOn(UploadApi, 'getTurbineTypes').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.getTurbineTypes(mockEvent)).toEqual(buildResponse(500, mockFailureRes));
    });

    it('getTurbineDetails Success', async () => {
      jest
        .spyOn(UploadApi, 'getTurbineDetails')
        .mockImplementation(() => mockResponse.turbineDetails);
      expect(await Uploadfn.getTurbineDetails(mockEventGetTurbineDetails)).toEqual(
        buildResponse(200, mockResponse.turbineDetails),
      );
    });

    it('getTurbineDetails Failure', async () => {
      jest.spyOn(UploadApi, 'getTurbineDetails').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.getTurbineDetails(mockEventGetTurbineDetails)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('getComponentDetailList Success', async () => {
      jest
        .spyOn(UploadApi, 'getComponentDetailList')
        .mockImplementation(() => mockResponse.componentDetailList);
      expect(await Uploadfn.getComponentDetailList(mockEventGetComponentDetailList)).toEqual(
        buildResponse(200, mockResponse.componentDetailList),
      );
    });

    it('getComponentDetailList Failure', async () => {
      jest.spyOn(UploadApi, 'getComponentDetailList').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.getComponentDetailList(mockEventGetComponentDetailList)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('postJob Success', async () => {
      jest.spyOn(UploadApi, 'postJob').mockImplementation(() => mockResponse.postJob);
      expect(await Uploadfn.postJob(mockRequest.postJobInput)).toEqual(
        buildResponse(200, mockResponse.postJob),
      );
    });

    it('postJob Failure', async () => {
      jest.spyOn(UploadApi, 'postJob').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.postJob(mockRequest.postJobInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('patchJob Success', async () => {
      jest.spyOn(UploadApi, 'patchJob').mockImplementation(() => mockResponse.postJob);
      expect(await Uploadfn.patchJob(mockRequest.patchJobInput)).toEqual(
        buildResponse(200, mockResponse.postJob),
      );
    });

    it('patchJob Failure', async () => {
      jest.spyOn(UploadApi, 'patchJob').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.patchJob(mockRequest.patchJobInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('postMetadata Success', async () => {
      jest.spyOn(UploadApi, 'postMetadata').mockImplementation(() => mockResponse.postMetadata);
      expect(await Uploadfn.postMetadata(mockRequest.postMetadataInput)).toEqual(
        buildResponse(200, mockResponse.postMetadata),
      );
    });

    it('postMetadata Failure', async () => {
      jest.spyOn(UploadApi, 'postMetadata').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.postMetadata(mockRequest.postMetadataInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('patchMetadata Success', async () => {
      jest.spyOn(UploadApi, 'patchMetadata').mockImplementation(() => mockResponse.postMetadata);
      expect(await Uploadfn.patchMetadata(mockRequest.patchMetadataInput)).toEqual(
        buildResponse(200, mockResponse.postMetadata),
      );
    });

    it('patchMetadata Failure', async () => {
      jest.spyOn(UploadApi, 'patchMetadata').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.patchMetadata(mockRequest.patchMetadataInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });

    it('getPresignedUrl Success', async () => {
      jest.spyOn(UploadApi, 'getPresignedUrl').mockImplementation(() => mockResponse.presignedUrl);
      expect(await Uploadfn.getPresignedUrl(mockRequest.getPresignedUrlInput)).toEqual(
        buildResponse(200, mockResponse.presignedUrl),
      );
    });

    it('getPresignedUrl Failure', async () => {
      jest.spyOn(UploadApi, 'getPresignedUrl').mockRejectedValue(mockFailureRes);
      expect(await Uploadfn.getPresignedUrl(mockRequest.getPresignedUrlInput)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });
});
