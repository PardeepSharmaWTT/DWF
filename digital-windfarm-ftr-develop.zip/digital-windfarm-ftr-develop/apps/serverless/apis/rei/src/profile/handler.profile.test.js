import * as UserProfileApi from '@ge/serverless-http/src/rendigital/rei/user-profile-api';
import { buildResponse } from '@ge/serverless-utils';

import mockRequest from '../../__mocks__/request/profile/userprofile.json';
import userData from '../../__mocks__/response/profile/userdata.json';

import * as ProfileFn from './handler';

const mockEvent = {
  headers: mockRequest.headers,
};

const mockFailureRes = {
  config: {},
  message: 'GE Service Error: Request failed with status code 500',
};

describe('User profile test cases', () => {
  describe('get user information sucess call', () => {
    it('should return user information', async () => {
      jest.spyOn(UserProfileApi, 'getUserProfile').mockImplementation(() => userData);
      expect(await ProfileFn.getUsersData(mockEvent)).toEqual(buildResponse(200, userData));
    });

    it('get users failure', async () => {
      jest.spyOn(UserProfileApi, 'getUserProfile').mockRejectedValue(mockFailureRes);
      expect(await ProfileFn.getUsersData(mockEvent)).toEqual(buildResponse(500, mockFailureRes));
    });
  });
});
