import { InspectionsApi } from '@ge/serverless-http';
import { buildAuthHeader, responses } from '@ge/serverless-utils';

export const getUsersData = async (event) => {
  try {
    console.log('Getting Users');

    const headers = buildAuthHeader(event);

    const response = await InspectionsApi.getUserProfile(headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
