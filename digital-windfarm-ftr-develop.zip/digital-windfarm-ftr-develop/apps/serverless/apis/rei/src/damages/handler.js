import { InspectionsApi } from '@ge/serverless-http';
import { buildAuthHeader, responses, intercept, bodyParserInterceptor } from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';

export const getDamages = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;
    const { filters } = params;

    requireNotEmpty({ filters });

    const headers = buildAuthHeader(event);

    const response = await InspectionsApi.getDamages(params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getDamageReport = intercept([bodyParserInterceptor], async (event) => {
  const { body: data, headers: options } = event;
  try {
    const body = data;
    const opt = options;
    requireNotEmpty({ body });

    const headers = buildAuthHeader(event);

    let response = await InspectionsApi.getDamageReport(body, opt, headers);

    const resp = responses.success(response);
    resp.headers['Content-Disposition'] = 'attachment; filename=damagereport.xlsx';
    resp.headers['Content-Type'] =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    return resp;
  } catch (err) {
    console.log('error', err);
    return responses.error(err);
  }
});

export const getDamageDetails = async (event) => {
  try {
    const {
      pathParameters: { damageId },
    } = event;
    requireNotEmpty({ damageId });
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getDamageDetails(damageId, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const createPacCase = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    requireNotEmpty({ params });

    const headers = buildAuthHeader(event);

    const response = await InspectionsApi.createPacCase(params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
