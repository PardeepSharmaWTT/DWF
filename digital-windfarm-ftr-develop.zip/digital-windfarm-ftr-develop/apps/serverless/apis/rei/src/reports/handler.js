import { InspectionsApi } from '@ge/serverless-http';
import { buildAuthHeader, bodyParserInterceptor, responses, intercept } from '@ge/serverless-utils';
import { requireNonNull, requireNotEmpty } from '@ge/util/object-utils';

export const getDataForReportGeneration = async (event) => {
  const {
    pathParameters: { jobId },
  } = event;
  try {
    requireNonNull({ jobId });
    console.log('get report data for report generation page');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getDataForReportGeneration(jobId, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getReportStageInfo = async (event) => {
  try {
    const {
      pathParameters: { jobId },
    } = event;

    requireNonNull({ jobId });
    console.log('getting report stage information');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getReportStageInfo(jobId, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const updateReport = intercept([bodyParserInterceptor], async (event) => {
  const {
    pathParameters: { jobId },
    body: data,
  } = event;
  try {
    const body = data;
    requireNotEmpty({ jobId, body });
    console.log('update report meta data');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.updateReport(jobId, body, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getBulkReportDownloadUrl = async (event) => {
  const { body: data } = event;
  try {
    const body = data;
    requireNotEmpty({ body });

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getBulkReportDownloadUrl(body, headers);
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const completeReport = intercept([bodyParserInterceptor], async (event) => {
  try {
    const {
      pathParameters: { jobId },
      body: data,
    } = event;

    requireNonNull({ jobId, data });
    console.log('changing job workflow for report');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.completeReport(jobId, data, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getReportCompletedJobs = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;
    const { filters } = params;

    requireNotEmpty({ filters });

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getAllJobsWithReportCompleted(params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
