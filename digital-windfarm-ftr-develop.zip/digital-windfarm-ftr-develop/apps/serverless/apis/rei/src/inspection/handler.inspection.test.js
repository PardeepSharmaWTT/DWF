import * as InspectionApi from '@ge/serverless-http/src/rendigital/rei/inspection-api';
import { buildResponse } from '@ge/serverless-utils';

import mockRequestExecution from '../../__mocks__/request/inspection/createJobExecution.json';
import * as mockResponse from '../../__mocks__/response/inspection';
import mockRequest from '../../test-events/GetAllJobs.json';

import * as Inspectionfn from './handler';

const mockEvent = {
  headers: mockRequest.headers,
  pathParameters: {
    jobId: 4108,
  },
};

const postMockEvent = {
  headers: mockRequest.headers,
  pathParameters: {
    jobId: 4108,
  },
  body: {
    data: {
      stage_status: 'complete',
      uploadcompletion_date: 1648557387,
      workflow_stage: 'upload',
    },
  },
};

const mockFailureRes = {
  config: {},
  message: 'GE Service Error: Request failed with status code 500',
};

describe('Inspection test cases', () => {
  describe('getUploadStageInfo function', () => {
    it('should return sucess upload stage info', async () => {
      jest
        .spyOn(InspectionApi, 'getUploadStageInfo')
        .mockImplementation(() => mockResponse.uploadJson);
      expect(await Inspectionfn.getUploadStageInfo(mockEvent)).toEqual(
        buildResponse(200, mockResponse.uploadJson),
      );
    });

    it('should return failure upload stage info', async () => {
      jest.spyOn(InspectionApi, 'getUploadStageInfo').mockRejectedValue(mockFailureRes);
      expect(await Inspectionfn.getUploadStageInfo(mockEvent)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('getExecutionStageInfo function', () => {
    it('should return success execution stage info', async () => {
      jest
        .spyOn(InspectionApi, 'getExecutionStageInfo')
        .mockImplementation(() => mockResponse.executionJsonSucess);
      expect(await Inspectionfn.getExecutionStageInfo(mockEvent)).toEqual(
        buildResponse(200, mockResponse.executionJsonSucess),
      );
    });

    it('should return failure execution stage info', async () => {
      jest.spyOn(InspectionApi, 'getExecutionStageInfo').mockRejectedValue(mockFailureRes);
      expect(await Inspectionfn.getExecutionStageInfo(mockEvent)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('getPostProcessStageInfo function', () => {
    it('should return success post processing stage info', async () => {
      jest
        .spyOn(InspectionApi, 'getPostProcessStageInfo')
        .mockImplementation(() => mockResponse.getPostProcessStageInfo);
      expect(await Inspectionfn.getPostProcessStageInfo(mockEvent)).toEqual(
        buildResponse(200, mockResponse.getPostProcessStageInfo),
      );
    });

    it('should return failure post processing stage info', async () => {
      jest.spyOn(InspectionApi, 'getPostProcessStageInfo').mockRejectedValue(mockFailureRes);
      expect(await Inspectionfn.getPostProcessStageInfo(mockEvent)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('getJobByIdfunction', () => {
    it('should get success job with id', async () => {
      jest.spyOn(InspectionApi, 'getJobById').mockImplementation(() => mockResponse.getJobById);
      expect(await Inspectionfn.getJobById(mockEvent)).toEqual(
        buildResponse(200, mockResponse.getJobById),
      );
    });

    it('should get failure job with id', async () => {
      jest.spyOn(InspectionApi, 'getJobById').mockRejectedValue(mockFailureRes);
      expect(await Inspectionfn.getJobById(mockEvent)).toEqual(buildResponse(500, mockFailureRes));
    });
  });

  describe('changeJobWorkflow', () => {
    it('should change the job stage successfully', async () => {
      jest
        .spyOn(InspectionApi, 'changeJobWorkflow')
        .mockImplementation(() => ({ status: 'Success updating workflow for this job.' }));
      expect(await Inspectionfn.changeJobWorkflow(postMockEvent)).toEqual(
        buildResponse(200, { status: 'Success updating workflow for this job.' }),
      );
    });

    it('should change the job stage failure', async () => {
      jest.spyOn(InspectionApi, 'changeJobWorkflow').mockRejectedValue(mockFailureRes);
      expect(await Inspectionfn.changeJobWorkflow(postMockEvent)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('deletejob', () => {
    it('should delete job by id success ', async () => {
      jest.spyOn(InspectionApi, 'deleteJob').mockImplementation(() => mockResponse.deleteSucess);
      expect(await Inspectionfn.deleteJob(mockEvent)).toEqual(
        buildResponse(200, mockResponse.deleteSucess),
      );
    });

    it('should delete job by id success ', async () => {
      jest.spyOn(InspectionApi, 'deleteJob').mockRejectedValue(mockFailureRes);
      expect(await Inspectionfn.deleteJob(mockEvent)).toEqual(buildResponse(500, mockFailureRes));
    });
  });

  describe('createJobExecution', () => {
    it('should successfully create job execution', async () => {
      jest
        .spyOn(InspectionApi, 'createJobExecution')
        .mockImplementation(() => mockResponse.createJobExecution);
      expect(await Inspectionfn.createJobExecution(mockRequestExecution)).toEqual(
        buildResponse(200, mockResponse.createJobExecution),
      );
    });

    it('should failure create job execution', async () => {
      jest.spyOn(InspectionApi, 'createJobExecution').mockRejectedValue(mockFailureRes);
      expect(await Inspectionfn.createJobExecution(mockRequestExecution)).toEqual(
        buildResponse(500, mockFailureRes),
      );
    });
  });

  describe('getAllJobs', () => {
    it('should get all jobs success ', async () => {
      jest.spyOn(InspectionApi, 'getAllJobs').mockImplementation(() => mockResponse.allJobs);
      expect(
        await Inspectionfn.getAllJobs({
          headers: mockRequest.headers,
          pathParameters: {
            number: 2,
          },
          body: {
            filters: {
              cod: null,
              coreFleet: 'all',
              sites: ['50006099'],
            },
          },
        }),
      ).toEqual(buildResponse(200, mockResponse.allJobs));
    });
    it('should get all jobs failure', async () => {
      jest.spyOn(InspectionApi, 'getAllJobs').mockRejectedValue(mockFailureRes);
      expect(
        await Inspectionfn.getAllJobs({
          headers: mockRequest.headers,
          pathParameters: {
            number: 2,
          },
          body: {
            filters: {
              cod: null,
              coreFleet: 'all',
              sites: ['50006099'],
            },
          },
        }),
      ).toEqual(buildResponse(500, mockFailureRes));
    });
  });
});
