import { InspectionsApi } from '@ge/serverless-http';
import { bodyParserInterceptor, buildAuthHeader, intercept, responses } from '@ge/serverless-utils';
import { requireNotEmpty, requireNonNull } from '@ge/util/object-utils';

export const changeJobWorkflow = intercept([bodyParserInterceptor], async (event) => {
  const {
    pathParameters: { jobId },
    body: data,
  } = event;
  try {
    const body = data;
    requireNotEmpty({ jobId, body });
    console.log('changing job workflow');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.changeJobWorkflow(jobId, body, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getUploadStageInfo = async (event) => {
  try {
    const {
      pathParameters: { jobId },
    } = event;

    requireNonNull({ jobId });
    console.log('getting upload stage information');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getUploadStageInfo(jobId, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getExecutionStageInfo = async (event) => {
  const {
    pathParameters: { jobId },
  } = event;

  try {
    requireNonNull({ jobId });
    console.log('getting execution stage information');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getExecutionStageInfo(jobId, headers);

    return responses.success(response);
  } catch (err) {
    console.log('error', err);
    return responses.error(err);
  }
};

export const getPostProcessStageInfo = async (event) => {
  try {
    const {
      pathParameters: { jobId },
    } = event;

    requireNonNull({ jobId });

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getPostProcessStageInfo(jobId, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getJobById = async (event) => {
  try {
    const {
      pathParameters: { jobId },
    } = event;

    requireNonNull({ jobId });
    console.log('getting post processing stage information');

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getJobById(jobId, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAllJobs = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;
    const {
      pathParameters: { number },
    } = event;

    requireNotEmpty({ number });

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.getAllJobs(number, params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
export const deleteJob = async (event) => {
  const {
    pathParameters: { jobId },
  } = event;
  try {
    requireNonNull({ jobId });
    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.deleteJob(jobId, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const createJobExecution = intercept([bodyParserInterceptor], async (event) => {
  const {
    pathParameters: { jobId },
    body: data,
  } = event;

  try {
    const body = data;
    requireNotEmpty({ jobId, body });

    const headers = buildAuthHeader(event);
    const response = await InspectionsApi.createJobExecution(jobId, body, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
