/* test locally
sam local invoke GetPerformanceDashboard -e test-events/GetPerformanceDashboard.json --parameter-overrides InspectApiUrl=https://apis-intra-dev.rendigital.apps.ge.com/inspect/v1
*/

// NOTE: do we want to create reninspect buckets for the orchestrator and http stuff as opposed to dropping everything in rendigital

import { InspectionsApi } from '@ge/serverless-http';
import { Inspections } from '@ge/serverless-orchestration';
import { bodyParserInterceptor, buildAuthHeader, intercept, responses } from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';

export const getPerformanceDashboard = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    const { endDate, filters, startDate } = params;

    requireNotEmpty({ endDate, filters, startDate });

    console.debug(`Getting performance dashboard data with params '${JSON.stringify(params)}'`);

    const headers = buildAuthHeader(event);

    const response = await Inspections.getPerformanceDashboard(params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getPerformanceDashboardReport = intercept([bodyParserInterceptor], async (event) => {
  try {
    const { body: params } = event;

    const { endDate, filters, startDate } = params;

    requireNotEmpty({ endDate, filters, startDate });

    console.debug(`Getting performance dashboard data with params '${JSON.stringify(params)}'`);

    const headers = buildAuthHeader(event);

    const response = await InspectionsApi.getPerformanceDashboardReport(params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
