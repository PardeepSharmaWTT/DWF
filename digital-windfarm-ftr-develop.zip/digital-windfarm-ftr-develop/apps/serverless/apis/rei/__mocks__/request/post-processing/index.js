import getAnnotationsInput from './GetAnnotations.json';
import getDamageTreeDetailsInput from './GetDamageTreeDetails.json';
import getImageInput from './GetImage.json';
import getImagesInput from './GetImages.json';
import getVideosInput from './GetVideos.json';
import updateAnnotationInput from './UpdateAnnotation.json';
import updateImageInput from './UpdateImage.json';
import updateVideoInput from './UpdateVideo.json';
import deleteAnnotationInput from './DeleteAnnotation.json';

export {
  getAnnotationsInput,
  getImageInput,
  getImagesInput,
  getVideosInput,
  getDamageTreeDetailsInput,
  updateAnnotationInput,
  updateImageInput,
  updateVideoInput,
  deleteAnnotationInput,
};
