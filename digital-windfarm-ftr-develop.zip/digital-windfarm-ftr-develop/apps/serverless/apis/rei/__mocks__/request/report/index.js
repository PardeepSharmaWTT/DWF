import updateReport from './updateReport.json';

export { updateReport };
