import componentDetailList from './getComponentDetailList.json';
import presignedUrl from './getPresignedUrl.json';
import regions from './getRegions.json';
import sites from './getSites.json';
import turbineDetails from './getTurbineDetails.json';
import turbineTypes from './getTurbineTypes.json';
import patchMetadata from './patchMetadata.json';
import postJob from './postJob.json';
import postMetadata from './postMetadata.json';
import sitesNames from './sites-names.json';
import updateManufacturer from './updateManufacturerByJobId.json';

export {
  sitesNames,
  turbineTypes,
  sites,
  regions,
  turbineDetails,
  componentDetailList,
  postJob,
  postMetadata,
  patchMetadata,
  presignedUrl,
  updateManufacturer,
};
