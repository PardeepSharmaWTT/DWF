# Setting Up the BFF to Run Locally

## Prerequisites

- [ ] Need to have [gossamer3](https://github.com/GESkunkworks/gossamer3) installed and functional (Windows or Main OS)

## Setting Up WSL 2
>Skip this step if you work in a UNIX environment

If you DO NOT have WSL 2 already please follow the instructions here to install WSL 2 (**ONLY up to step 4**):
https://devcloud.swcoe.ge.com/devspace/display/NBJXM/Setup+WSL+2+on+Windows+10

> IMPORTANT: If you run into any SSL or proxy errors during installation of anything below, try disconnecting from MyApps and VPN
### 1. Installing Docker Daemon (ON WSL)

> Once you have WSL 2 installed, install docker daemon and CLI. (Note: This does NOT use docker desktop)

Follow These instructions to install docker daemon:
https://docs.docker.com/engine/install/ubuntu/

>At the end of the docker install instructions it will tell you to run
> `sudo docker run hello-world`. This will fail. You must start the daemon first with `sudo service docker start`

### 3. Installing SAM and AWS CLI (ON WSL)

Install unzip
```shell
sudo apt install unzip
 ```
Download sam cli zip
```shell
wget https://github.com/aws/aws-sam-cli/releases/latest/download/aws-sam-cli-linux-x86_64.zip
```
Install sam cli
```shell
sudo unzip aws-sam-cli-linux-x86_64.zip -d sam-installation && sudo ./sam-installation/install && sudo rm aws-sam-cli-linux-x86_64.zip & sudo rm -r sam-installation
```
Download and install aws cli
```shell
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
```
Now we must link our Windows .aws directory to Linux so gossamer3 can share credentials
```shell
sudo ln -s ~/.aws  /mnt/c/Users/503257153/.aws
```

### Install Node to run proxy (ON WSL)

```shell
curl -fsSL https://fnm.vercel.app/install | bash
bash exec
fnm use 14
```

### Installing npm package [`local-cors-proxy`](https://github.com/garmeeh/local-cors-proxy)

First get latest NPM

```shell
npm install -g npm
```
Then install proxy

```shell
npm install -g local-cors-proxy
```
> This package is necessary because sam local does not support CORS out of the box yet. All this does is allow us to use CORS (Like options request) without changing any code.

## Running BFF endpoint locally

> NOTE: Right now, you have to run separate instances of each endpoint. DAV/RTMC/CMN/MWP

> IMPORTANT: You must run `yarn build` in `apps/serverless/apis/[ENDPOINT-HERE]` in windows (if your code is there) for the endpoint you want to launch at least once.
1. Ensure Docker daemon is running in WSL.

```shell
sudo service docker start
```

1. Navigate to the endpoint that you want to run in the WSL terminal.

**Example:**

```shell
cd /mnt/c/Users/503257153/WebstormProjects/digital-windfarm/apps/serverless/apis/dav
```

2. Run
> **Must be run in WSL**

Make sure you are logged in with gossamer3
If it still does not work, try running with in sudo.
```shell
#This will set the local variables, start the proxy and run sam local start-api
 yarn start
```

3. Uncomment the endpoint you are running locally in the file `apps/web-client/.env.development.local`

**Example:**

```conf
HOST=local.rendigital.apps.ge.com

REACT_APP_ENV=development

REACT_APP_WALK_ME_ENABLED=false

# Uncomment the api you would like to use locally

#REACT_APP_DIGITAL_WIND_FARM_CMN_API=http://localhost:3013/proxy
REACT_APP_DIGITAL_WIND_FARM_DAV_API=http://localhost:3011/proxy
#REACT_APP_DIGITAL_WIND_FARM_MWP_API=http://localhost:3014/proxy
#REACT_APP_DIGITAL_WIND_FARM_RTMC_API=http://localhost:3012/proxy
```


# Running lambda functions locally just by using lambda-tester node module

Following confluence page can be referred to for running lambda functions locally for different endpoints

Right now for mwp related lambdas it was done.Similarly it can be done for other apis as well
https://devcloud.swcoe.ge.com/devspace/display/NBJXM/Unit+testing+lambda+functions+locally+with+help+of+lambda-tester+node+module