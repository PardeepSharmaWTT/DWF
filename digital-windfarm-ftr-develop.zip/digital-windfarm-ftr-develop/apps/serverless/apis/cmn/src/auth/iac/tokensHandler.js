const { AuthApi } = require('@ge/serverless-http');
const Transformers = require('@ge/serverless-models/src/rendigital/transformers');
const { responses } = require('@ge/serverless-utils');

export const getAccessTokens = async (event) => {
  try {
    const tokenResp = await AuthApi.getAccessTokens(event);
    console.log(`IAC response: ${JSON.stringify(tokenResp)}`);

    return responses.success(Transformers.IAC.toLogical(tokenResp));
  } catch (e) {
    console.error('Error fetching tokens: ', e);
    return responses.error(e);
  }
};
