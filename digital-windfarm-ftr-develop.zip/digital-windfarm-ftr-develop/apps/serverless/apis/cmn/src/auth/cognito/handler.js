const jwt = require('jsonwebtoken');
const jwksClient = require('jwks-rsa');

const keyClient = jwksClient({
  cache: true,
  cacheMaxAge: 86400000, // value in ms
  rateLimit: true,
  jwksRequestsPerMinute: 10,
  strictSsl: true,
  jwksUri: process.env.JWKS_URI,
});

const verificationOptions = {
  algorithms: 'RS256',
};

const getSigningKey = (header, callback) => {
  keyClient.getSigningKey(header.kid, (err, key) => {
    if (err) {
      console.log(`Unable to get signing key: ${JSON.stringify(err)}`);
    }

    const signingKey = key.publicKey || key.rsaPublicKey;
    callback(null, signingKey);
  });
};

const validateCognitoToken = (token, callback, methodArn) => {
  jwt.verify(token, getSigningKey, verificationOptions, (error) => {
    if (error) {
      console.log(`JWT validation failed: ${JSON.stringify(error)}`);

      const response = generateAuthResponse('user', 'Deny', methodArn);
      callback(null, response);
    } else {
      const response = generateAuthResponse('user', 'Allow', methodArn);
      callback(null, response);
    }
  });
};

exports.authorizer = (event, context, callback) => {
  const token = event.authorizationToken;

  // Allow access to all for now until we sort out how to restrict
  // running only the function specifed by the arn.
  //   const methodArn = event.methodArn;
  const methodArn = '*';

  console.log(`Method: ${event.methodArn}`);

  validateCognitoToken(token, callback, methodArn);
};

const generateAuthResponse = (principalId, effect, methodArn) => {
  const policyDocument = generatePolicyDocument(effect, methodArn);

  return {
    principalId,
    policyDocument,
  };
};

const generatePolicyDocument = (effect, methodArn) => {
  if (!effect || !methodArn) return null;

  return {
    Version: '2012-10-17',
    Statement: [
      {
        Action: 'execute-api:Invoke',
        Effect: effect,
        Resource: methodArn,
      },
    ],
  };
};
