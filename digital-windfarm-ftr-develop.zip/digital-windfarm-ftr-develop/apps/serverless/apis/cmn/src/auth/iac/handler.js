import axios from 'axios';

import { AuthApi } from '@ge/serverless-http';
import { getHeader } from '@ge/serverless-utils/src/serverless-utils';

const { responses } = require('@ge/serverless-utils');

export const authorize = AuthApi.authorize;

export const getOidcConfig = async (event) => {
  const origin = getHeader('origin', event.headers);
  const iacVersion = process.env.IAC_VERSION;
  const queryStringParameters = event.queryStringParameters || {};
  const { idpName } = queryStringParameters;
  let headers = {
    origin,
    ...(iacVersion && { tokenVersion: iacVersion }),
    ...(idpName && { idpName: idpName }),
  };

  // Pass-through a call to the IAC to get the OIDC config data
  // for the user surfing from the specific origin.
  return axios
    .get(process.env.OIDC_TENANT_CONFIG_URL, { headers })
    .then(({ data }) => responses.success(data))
    .catch((e) => responses.error(e));
};
