const { is } = require('ramda');

const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  responses,
  bodyParserInterceptor,
  intercept,
  getSiteIdsFilter,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getNotesAndSpecialInstructions = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { pageSize, pageIndex, creationDate, id, assetType },
    } = event;

    requireNonNull({ pageIndex, pageSize, creationDate, id, assetType });

    const _notesResp = await Common.notesSI.getNotes(
      {
        headers,
        pageIndex,
        pageSize,
        creationDate,
        id,
        assetType,
      },
      true,
    );

    return responses.success(_notesResp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getNotes = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { pageSize, pageIndex, creationDate, id, assetType },
    } = event;

    requireNonNull({ pageIndex, pageSize, creationDate, id, assetType });
    const response = await Common.notesSI.getNotes({
      headers,
      pageIndex,
      pageSize,
      creationDate,
      id,
      assetType,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getSpecialInstructions = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { pageSize, pageIndex, id, assetType, isActive, siteId },
    } = event;

    requireNonNull({ pageIndex, pageSize, id, assetType, isActive });
    const response = await Common.notesSI.getSpecialInstructions({
      headers,
      pageIndex,
      pageSize,
      id,
      assetType,
      isActive,
      siteId,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getEntitiesNotes = intercept([bodyParserInterceptor], async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      body: { ids: idsParam, entityType },
    } = event;

    requireNonNull({ ids: idsParam, entityType });

    console.log(`Getting notes for entityIs [${idsParam}] and entityType [${entityType}]`);

    const ids = idsParam.split(',');
    const response = await Common.notesSI.getEntitiesNotes({
      headers,
      ids,
      entityType,
    });

    console.debug('Returning data in response');

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const editNotes = intercept([bodyParserInterceptor], async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
      body: data,
      queryStringParameters: { assetType },
    } = event;
    const { files, json, ...rest } = data || {};
    const parsedData = is(String, json) ? { ...rest, ...JSON.parse(json) } : { ...rest };

    requireNonNull({ id, assetType, parsedData });

    const response = await Common.notesSI.editAddNotes({
      headers,
      id,
      assetType,
      data: parsedData,
      files,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const editSpecialInstructions = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
      body: data,
      queryStringParameters: { assetType },
    } = event;
    const parsedData = await JSON.parse(data);

    requireNonNull({ id, assetType, parsedData });
    const response = await Common.notesSI.editAddSpecialInstructions({
      headers,
      id,
      assetType,
      data: parsedData,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const addNotes = intercept([bodyParserInterceptor], async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      body: data,
      queryStringParameters: { assetType },
    } = event;
    const { files, json, ...rest } = data || {};
    const parsedData = is(String, json) ? { ...rest, ...JSON.parse(json) } : { ...rest };

    requireNonNull({ assetType, parsedData });

    const response = await Common.notesSI.editAddNotes({
      headers,
      assetType,
      data: parsedData,
      files,
      newRecord: true,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const addSpecialInstructions = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      body: data,
      queryStringParameters: { assetType },
    } = event;
    const parsedData = await JSON.parse(data);

    requireNonNull({ assetType, data });
    const response = await Common.notesSI.editAddSpecialInstructions({
      headers,
      assetType,
      data: parsedData,
      newRecord: true,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const deleteNote = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { id },
      queryStringParameters: { assetType },
    } = event;
    requireNonNull({ id, assetType });
    const response = await Common.notesSI.deleteNotesOrSpecialInstructions({
      headers,
      id,
      assetType,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getActiveSIsForSiteAndAssets = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const parsedData = await JSON.parse(data);
    const { siteIds, assetIds } = parsedData || {};
    requireNonNull({ siteIds, assetIds });

    const response = await Common.notesSI.getActiveSIs({
      headers,
      data: parsedData,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAllSiteActiveSIs = async (event) => {
  const headers = buildAuthHeader(event);
  const siteIds = await getSiteIdsFilter(event);
  try {
    const resp = await Common.notesSI.getAllSiteActiveSIs({
      headers,
      siteIds,
    });
    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAssetsActiveSIs = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const parsedData = await JSON.parse(data);
    const { assetIds } = parsedData || {};
    requireNonNull({ assetIds });

    const resp = await Common.notesSI.getAssetsActiveSIs({
      headers,
      assetIds,
    });
    return responses.success(resp);
  } catch (err) {
    return responses.error(err);
  }
};
