const { is } = require('ramda');

const { Common } = require('@ge/serverless-orchestration');
const {
  intercept,
  bodyParserInterceptor,
  responses,
  buildAuthHeader,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getAlerts = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const {
      queryStringParameters: { siteId, assetId, assetType },
    } = event;
    console.log('Trying to fetch Monitor Alerts');
    const response = await Common.monitorAlerts.getAlerts(headers, {
      siteId,
      assetId,
      assetType,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getAssetAlerts = intercept([bodyParserInterceptor], async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { assetIds, assetType } = event.body;
    console.log('Trying to fetch Monitor Alerts for assetIds', assetIds, assetType);
    const response = await Common.monitorAlerts.getAlerts(headers, {
      assetId: assetIds,
      assetType: assetType,
    });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const postAlert = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const { files, payload } = is(String, data) ? JSON.parse(data) : {};
    const parsedData = payload && JSON.parse(payload);
    requireNonNull({ parsedData });
    console.log('Trying to add a Monitor Alert');
    const response = await Common.monitorAlerts.createAlert({ headers, data: parsedData, files });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

// TODO: Integration of update alert with UI.
export const updateAlert = async (event) => {
  try {
    const headers = buildAuthHeader(event);
    const { body: data } = event;
    const { files, payload } = is(String, data) ? JSON.parse(data) : {};
    const parsedData = payload && JSON.parse(payload);
    requireNonNull({ parsedData });
    console.log('Trying to update a Monitor Alert');
    const response = await Common.monitorAlerts.editAlert({ headers, data: parsedData, files });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
