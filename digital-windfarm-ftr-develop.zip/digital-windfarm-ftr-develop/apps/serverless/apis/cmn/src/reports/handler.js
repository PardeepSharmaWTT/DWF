/* test locally
sam local invoke CreateReportTemplate -e test-events/CreateReportTemplate.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
sam local invoke GetReportWidgetData -e test-events/GetWidgetData_PlannedWork.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
sam local invoke GetSentReports -e test-events/GetSentReports.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
*/

const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  intercept,
  responses,
  segmentTokensInterceptor,
  bodyParserInterceptor,
} = require('@ge/serverless-utils');
const { requireNonNull, requireNotEmpty } = require('@ge/util/object-utils');

export const getReportTemplates = async (event) => {
  try {
    console.log('getting report template data');
    // expected query parms (optional): { createdBy, endDate, filename, startDate, type, sortKey, orderDirection, pageIdx, pageSize }
    const params = event.queryStringParameters || {};
    const headers = buildAuthHeader(event);
    const templateData = await Common.reports.getReportTemplates({ headers, params });
    return responses.success(templateData);
  } catch (err) {
    return responses.error(err);
  }
};

export const getReportTemplateById = async (event) => {
  try {
    console.log('getting report by template');
    const headers = buildAuthHeader(event);
    const {
      pathParameters: { templateId },
    } = event;
    console.log('templateId', templateId);
    requireNonNull({ templateId });
    const reportTemplate = await Common.reports.getReportTemplateById({
      headers,
      templateId,
    });
    return responses.success(reportTemplate);
  } catch (err) {
    return responses.error(err);
  }
};

export const createReport = intercept([bodyParserInterceptor], async (event) => {
  try {
    console.debug('Creating new report');

    const { body: data } = event;

    // expected params: json, reportFile, attachments (optional)
    const { json, files } = data || {};

    const parsedData = json ? JSON.parse(json) : {};

    requireNotEmpty({ parsedData, files });

    const headers = buildAuthHeader(event);

    console.debug('Creating new report for template', parsedData);

    // NOTE: The first file sent is the reportFile.  Any other files are attachments.
    const reportFile = files && files.length > 0 ? files.shift() : {};
    const attachments = files || [];

    const response = await Common.reports.createReport({
      headers,
      json: parsedData,
      attachments,
      reportFile,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const createReportTemplate = intercept([bodyParserInterceptor], async (event) => {
  try {
    console.debug('Creating report template from base template');

    const { body: params } = event;

    // expected params: baseId, dateRange, description, distributionList, name, scope, scopeType, type
    const { baseId, dateRange, name, scope, scopeType, type } = params || {};

    requireNotEmpty({ baseId, dateRange, name, scope, scopeType, type });

    console.debug(
      `Creating report template '${name}' from base template with Id '${baseId}' and type '${type}'`,
    );

    const headers = buildAuthHeader(event);

    const response = await Common.reports.createReportTemplate(params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});

export const getReportWidgetData = intercept(
  [segmentTokensInterceptor],
  async ({ body, queryStringParameters }) => {
    try {
      console.log('Getting widget data for report');

      const { serviceUrls, startDate, endDate } = queryStringParameters || {};
      const { segmentTokens, siteIds } = body;

      console.debug(`Attempting to get widget data for ${serviceUrls}`);
      console.debug(
        `serviceUrls: ${serviceUrls} || startDate: ${startDate} || endDate: ${endDate}`,
      );
      console.debug(`siteIds: ${siteIds}`);

      const response = await Common.reports.getWidgetData({
        segmentTokens,
        serviceUrls,
        startDate,
        endDate,
        siteIds,
      });

      console.debug(`Retrieved widget data for ${serviceUrls}`);

      return responses.success(response);
    } catch (err) {
      return responses.error(err);
    }
  },
);

export const getSentReports = async (event) => {
  try {
    console.debug('Getting sent reports');

    // expected query parms (optional): { createdBy, endDate, filename, startDate, type, sortKey, orderDirection, pageIdx, pageSize }
    const params = event.queryStringParameters || {};
    const headers = buildAuthHeader(event);

    const response = await Common.reports.getSentReports({ headers, params });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const sendReport = intercept([bodyParserInterceptor], async (event) => {
  try {
    console.debug('Sending new report');

    const { body: params } = event;

    // expected params: reportId, distributionList (optional)
    const { reportId, distributionList } = params || {};

    requireNotEmpty({ reportId });

    console.debug('Report ID: ', reportId);
    console.debug(
      `Sending to ${
        distributionList && distributionList.length > 0
          ? distributionList.length + ' users'
          : 'original distirubtion list'
      }`,
    );

    const headers = buildAuthHeader(event);

    const response = await Common.reports.sendReport(reportId, params, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
});
