const lambdaTester = require('lambda-tester');

const lambdaIndex = require('../src/tasks/handler');

jest.setTimeout(30000);

/* authorization tokens need to be updated while testing for different success scenarios below
   also in external-api.js axiosintance baseurl  needs to be updated to be updated to exact url pointed for FS_FTR_BASE_URL in Setup.groovy
   Below tests also include failure case scenarios for understanding*/
// in package.json any desired test case can be run by changing -t parameter
// get tasks test case
test('getTasks', async () => {
  return await lambdaTester(lambdaIndex.getTasks)
    .event({
      headers: {
        Authorization:
          'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIyNFVhVHJ0bk9DOW80OWNhU0xLVEl4WHVGM3ItbEhkd3BRUkpxVm40em1rIn0.eyJleHAiOjE2Mzk3NDI1ODksImlhdCI6MTYzOTc0MDc4OSwiYXV0aF90aW1lIjoxNjM5NzQwNzg0LCJqdGkiOiI5MDg3NWZmOC01YjQyLTQ1NTQtODk3Ni01YmZhMTZjOTQwNzYiLCJpc3MiOiJodHRwczovL2FwaXMtcWEucmVuZGlnaXRhbC5hcHBzLmdlLmNvbS9hdXRoL3JlYWxtcy9SRU5EUyIsImF1ZCI6ImdlLXJlbi1jbGllbnQiLCJzdWIiOiI1ZjhhNDhiNC0zZGUwLTRlNjctODgwYS0xZjQwOWJlOTQwNjIiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJnZS1yZW4tY2xpZW50Iiwic2Vzc2lvbl9zdGF0ZSI6IjljOWYxYTljLTYwMWUtNDhlNy05MDVmLWVhMDFiYmNlMzUyZiIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsibW9uaXRvcmluZy1hZG1pbiIsImFuYWx5dGljcy12aWV3IiwiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXIiLCJtb25pdG9yaW5nLXZpZXciXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJhdXRob3JpemF0aW9uIjp7InBlcm1pc3Npb25zIjpbeyJzY29wZXMiOlsidmlldyIsImVkaXQiLCJjcmVhdGUiXSwiY2xhaW1zIjp7ImNhcGFiaWxpdHkiOlsiRmllbGQgVGFza3MiXX0sInJzaWQiOiI4YzZhNzRlNy0yNmJkLTRjN2YtYmYxOS00ODk3MDI2MTExNmEiLCJyc25hbWUiOiJtYW5hZ2VfRmllbGQgVGFza3MifSx7InNjb3BlcyI6WyJ2aWV3IiwiZWRpdCIsImNyZWF0ZSJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJGaWVsZCBUYXNrcyJdfSwicnNpZCI6IjNkODg5M2U3LTRhYmItNDBjZi1hMGMzLWY5NTFlMjJkYzRmMyIsInJzbmFtZSI6Im1hbmFnZS1maWVsZC10YXNrX0ZpZWxkIFRhc2tzIn0seyJzY29wZXMiOlsidmlldyJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJBc3NldCBNYW5hZ2VtZW50Il19LCJyc2lkIjoiMzE4MDJkNTMtODhhYi00YzVmLWJmZTItY2NlNTRiYTFiMjk3IiwicnNuYW1lIjoiYXNzZXRtZ210X0Fzc2V0IE1hbmFnZW1lbnQifV19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBwcm9maWxlIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJlbnRpdHlfZ3JvdXAiOiJbe1wiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXJcIjp7fX0se1wibW9uaXRvcmluZy1hZG1pblwiOnt9fSx7XCJhbmFseXRpY3Mtdmlld1wiOnt9fSx7XCJtb25pdG9yaW5nLXZpZXdcIjp7fX1dIiwibmFtZSI6IkRXRiBkd2YtdGVzdC1hbGwiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiI1MDI4Mjg0NTEiLCJnaXZlbl9uYW1lIjoiRFdGIiwiZmFtaWx5X25hbWUiOiJkd2YtdGVzdC1hbGwiLCJ0ZW5hbnQiOnsidGVuYW50SWQiOiJnZXNlcnZnRXVjIiwicmVzb3VyY2VzIjp7InNpdGVzIjpbIkFMTCJdfX0sImVtYWlsIjoiZHdmLmR3Zi10ZXN0LWFsbEBnZS5jb20ifQ.iEytg2eSahBp9b1CMJzeRFTxgOh_DgMnq3tgdGFPGybIunuOj3HjNoZBde11Xly4j--L-f4Yi6FzR8AH3jBy5beLkgQgLhE8NOIRlXrUBXwrJSS-kCBK6_UYuZD7Ll-nQkQc5WyN3DJXyR6sfeLkEFUvEkk05yrc4HIJOUO465vxHtGvUDKvgJJvnk2uch8zYFRdX1JAo9NJ35sq7zyIY1sbzB_coQ-espwaBBeC934uAl9Txcz6KaDQ1hEBdTPE06ZgO1jfYmGFlPYwKUfvTFzsn-HxS0Cg6XS8Vs8y3qgpxPsWdItno3H9PNKOHN9624MZnp5LScVgGXFZzTSu3A',
      },
    })
    .expectResult((result) => {
      const res = JSON.parse(result.body);
      console.log('response', res);
      if (res.message) expect(res.message).not.toContain('GE Service Error:');
      expect(res.error).not.toBeDefined();
      /* we can mention different format in expect based on how
         errors are returned for failure scenarios*/
    });
});
// get task by id test case
test('getTaskByTaskId', async () => {
  return await lambdaTester(lambdaIndex.getTask)
    .event({
      headers: {
        Authorization:
          'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIyNFVhVHJ0bk9DOW80OWNhU0xLVEl4WHVGM3ItbEhkd3BRUkpxVm40em1rIn0.eyJleHAiOjE2NDAyNTg0OTksImlhdCI6MTY0MDI1NjY5OSwiYXV0aF90aW1lIjoxNjQwMjU2NjkxLCJqdGkiOiIzMDNiN2E5ZS01OGExLTQ3NjctYWRlMC1jZDZjNzBlOGY5ZDQiLCJpc3MiOiJodHRwczovL2FwaXMtcWEucmVuZGlnaXRhbC5hcHBzLmdlLmNvbS9hdXRoL3JlYWxtcy9SRU5EUyIsImF1ZCI6ImdlLXJlbi1jbGllbnQiLCJzdWIiOiI1ZjhhNDhiNC0zZGUwLTRlNjctODgwYS0xZjQwOWJlOTQwNjIiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJnZS1yZW4tY2xpZW50Iiwic2Vzc2lvbl9zdGF0ZSI6Ijg2NGY2NDIyLWQ2ZjQtNGRiNi05ZGVjLTM1OGNhMTNiOWUxYiIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsibW9uaXRvcmluZy1hZG1pbiIsImFuYWx5dGljcy12aWV3IiwiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXIiLCJtb25pdG9yaW5nLXZpZXciXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJhdXRob3JpemF0aW9uIjp7InBlcm1pc3Npb25zIjpbeyJzY29wZXMiOlsidmlldyIsImVkaXQiLCJjcmVhdGUiXSwiY2xhaW1zIjp7ImNhcGFiaWxpdHkiOlsiRmllbGQgVGFza3MiXX0sInJzaWQiOiI4YzZhNzRlNy0yNmJkLTRjN2YtYmYxOS00ODk3MDI2MTExNmEiLCJyc25hbWUiOiJtYW5hZ2VfRmllbGQgVGFza3MifSx7InNjb3BlcyI6WyJ2aWV3IiwiZWRpdCIsImNyZWF0ZSJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJGaWVsZCBUYXNrcyJdfSwicnNpZCI6IjNkODg5M2U3LTRhYmItNDBjZi1hMGMzLWY5NTFlMjJkYzRmMyIsInJzbmFtZSI6Im1hbmFnZS1maWVsZC10YXNrX0ZpZWxkIFRhc2tzIn0seyJzY29wZXMiOlsidmlldyJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJBc3NldCBNYW5hZ2VtZW50Il19LCJyc2lkIjoiMzE4MDJkNTMtODhhYi00YzVmLWJmZTItY2NlNTRiYTFiMjk3IiwicnNuYW1lIjoiYXNzZXRtZ210X0Fzc2V0IE1hbmFnZW1lbnQifV19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBwcm9maWxlIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJlbnRpdHlfZ3JvdXAiOiJbe1wiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXJcIjp7fX0se1wibW9uaXRvcmluZy1hZG1pblwiOnt9fSx7XCJhbmFseXRpY3Mtdmlld1wiOnt9fSx7XCJtb25pdG9yaW5nLXZpZXdcIjp7fX1dIiwibmFtZSI6IkRXRiBkd2YtdGVzdC1hbGwiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiI1MDI4Mjg0NTEiLCJnaXZlbl9uYW1lIjoiRFdGIiwiZmFtaWx5X25hbWUiOiJkd2YtdGVzdC1hbGwiLCJ0ZW5hbnQiOnsidGVuYW50SWQiOiJnZXNlcnZnRXVjIiwicmVzb3VyY2VzIjp7InNpdGVzIjpbIkFMTCJdfX0sImVtYWlsIjoiZHdmLmR3Zi10ZXN0LWFsbEBnZS5jb20ifQ.EcU36F0XvOPkPTiIlv6xA0RoepmNE69hmTEvw4i-NzEHV0CLPRHUhZ0eanT4NmAt_xQ6JAHlMqdiVe8dQOkyEHX_MSuT0TvM_PUcnyCQZWqebYGTncLyIFwg5jF7CauNYXt9NEY6cKcpvZuDuM2qf854Rx6eSolTia7-nlTRPswt4nv-ZEq8LKmu-cIa3SNoHN4T7otK2pTM_CJ0KKZHTJ_6heJs3KB7QB4LsbigbCkAvdMtn-QUGT_7NVlXXBLiMahc67Q692NztxOx-N4-8846IONWSupw7RVcNaTX7Bn8b1T9tjA0ALz2Byx2ho_5_jTtZ-cUAS5UUN3-q6KnDw',
      },
      pathParameters: {
        taskId: '617ddbc4bcf0b2751d8c1da6',
      },
    })
    .expectResult((result) => {
      const res = JSON.parse(result.body);
      console.log('response', res);
      if (res.message) expect(res.message).not.toContain('GE Service Error:');
      expect(res.error).not.toBeDefined();
    });
});

test('createTaskSuccess', async () => {
  return await lambdaTester(lambdaIndex.createTask)
    .event({
      headers: {
        Authorization:
          'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIyNFVhVHJ0bk9DOW80OWNhU0xLVEl4WHVGM3ItbEhkd3BRUkpxVm40em1rIn0.eyJleHAiOjE2Mzk2NjQ0ODAsImlhdCI6MTYzOTY2MjY4MCwiYXV0aF90aW1lIjoxNjM5NjYyNjc2LCJqdGkiOiJjN2QxMDM3OS1lNmMxLTRjNDctODM2Ny01ZWI3NDE5YTRmZTciLCJpc3MiOiJodHRwczovL2FwaXMtcWEucmVuZGlnaXRhbC5hcHBzLmdlLmNvbS9hdXRoL3JlYWxtcy9SRU5EUyIsImF1ZCI6ImdlLXJlbi1jbGllbnQiLCJzdWIiOiI1ZjhhNDhiNC0zZGUwLTRlNjctODgwYS0xZjQwOWJlOTQwNjIiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJnZS1yZW4tY2xpZW50Iiwic2Vzc2lvbl9zdGF0ZSI6IjliNTBjOTczLTI3M2YtNGE1Zi1iOTdiLTcwODNiNWFiMmM4ZCIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsibW9uaXRvcmluZy1hZG1pbiIsImFuYWx5dGljcy12aWV3IiwiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXIiLCJtb25pdG9yaW5nLXZpZXciXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJhdXRob3JpemF0aW9uIjp7InBlcm1pc3Npb25zIjpbeyJzY29wZXMiOlsidmlldyIsImVkaXQiLCJjcmVhdGUiXSwiY2xhaW1zIjp7ImNhcGFiaWxpdHkiOlsiRmllbGQgVGFza3MiXX0sInJzaWQiOiI4YzZhNzRlNy0yNmJkLTRjN2YtYmYxOS00ODk3MDI2MTExNmEiLCJyc25hbWUiOiJtYW5hZ2VfRmllbGQgVGFza3MifSx7InNjb3BlcyI6WyJ2aWV3IiwiZWRpdCIsImNyZWF0ZSJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJGaWVsZCBUYXNrcyJdfSwicnNpZCI6IjNkODg5M2U3LTRhYmItNDBjZi1hMGMzLWY5NTFlMjJkYzRmMyIsInJzbmFtZSI6Im1hbmFnZS1maWVsZC10YXNrX0ZpZWxkIFRhc2tzIn0seyJzY29wZXMiOlsidmlldyJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJBc3NldCBNYW5hZ2VtZW50Il19LCJyc2lkIjoiMzE4MDJkNTMtODhhYi00YzVmLWJmZTItY2NlNTRiYTFiMjk3IiwicnNuYW1lIjoiYXNzZXRtZ210X0Fzc2V0IE1hbmFnZW1lbnQifV19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBwcm9maWxlIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJlbnRpdHlfZ3JvdXAiOiJbe1wiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXJcIjp7fX0se1wibW9uaXRvcmluZy1hZG1pblwiOnt9fSx7XCJhbmFseXRpY3Mtdmlld1wiOnt9fSx7XCJtb25pdG9yaW5nLXZpZXdcIjp7fX1dIiwibmFtZSI6IkRXRiBkd2YtdGVzdC1hbGwiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiI1MDI4Mjg0NTEiLCJnaXZlbl9uYW1lIjoiRFdGIiwiZmFtaWx5X25hbWUiOiJkd2YtdGVzdC1hbGwiLCJ0ZW5hbnQiOnsidGVuYW50SWQiOiJnZXNlcnZnRXVjIiwicmVzb3VyY2VzIjp7InNpdGVzIjpbIkFMTCJdfX0sImVtYWlsIjoiZHdmLmR3Zi10ZXN0LWFsbEBnZS5jb20ifQ.TvGCMPoFI0_okuaDlsCjmF9zyDmrYs_BefVfcqt5O0AZZPv8ZQPg_t_8S0M1XXrxV8U7d3hXsADcrz9xr5R_SWhOnO9s4vOLtaGY6w1plDgK1x8EpJ6USgM5Z44l-0oyfpwPYizbZ1w7BcngZQRqVqsa3vkVq3G4J0s1-ccrmRL_YcQXdLrbpEV3SVAT9i-O8XZ4aRnUwXT4um0hXOwIXMVheWyoTPQwe9ggyn-Fkq5nXp1uCOEi5GjjxIGY7De6lnr5ShrYHu6npkQ_V8bO3GKK278hpdWd78U6VOPeWm-gI-toO-AGGM7KqDpaa-L0TanBSRGwGlakY7tzHv7E3A',
      },
      body: JSON.stringify({
        type: 'maintenance',
        priority: 'medium',
        category: 'field',
        title: 'Testing create task12',
        description: 'Testing create task description12',
        dueDate: null,
        eligibleStartDate: null,
        estDurationHours: 8,
        estDurationMinutes: 0,
        estTechs: 3,
        laborHours: 24,
        laborMinutes: 0,
        scheduleDate: null,
        recurrence: { recurrenceEndByDate: '2021-12-17T09:06:54.833Z' },
        expectedParts: null,
        consumedParts: null,
        status: null,
        site: { id: '5000562' },
        asset: { id: '16122387' },
        taskLevel: 'asset',
        entityList: ['16122387'],
      }),
    })
    .expectResult((result) => {
      const res = JSON.parse(result.body);
      console.log('response', res);
      expect(res.error).not.toBeDefined();
    });
});

// run without changing token to understand an expected failure test case getting passed due to the expired token
test('createTaskFailure', async () => {
  return await lambdaTester(lambdaIndex.createTask)
    .event({
      headers: {
        Authorization:
          'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIyNFVhVHJ0bk9DOW80OWNhU0xLVEl4WHVGM3ItbEhkd3BRUkpxVm40em1rIn0.eyJleHAiOjE2Mzk3MzM0NDYsImlhdCI6MTYzOTczMTY0NiwiYXV0aF90aW1lIjoxNjM5NzMxNjM5LCJqdGkiOiJiOTgyMGYxNS1mZDNiLTQyNjItYmYwYi05MTVlOWRkZjZkOWMiLCJpc3MiOiJodHRwczovL2FwaXMtcWEucmVuZGlnaXRhbC5hcHBzLmdlLmNvbS9hdXRoL3JlYWxtcy9SRU5EUyIsImF1ZCI6ImdlLXJlbi1jbGllbnQiLCJzdWIiOiI1ZjhhNDhiNC0zZGUwLTRlNjctODgwYS0xZjQwOWJlOTQwNjIiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJnZS1yZW4tY2xpZW50Iiwic2Vzc2lvbl9zdGF0ZSI6IjMzZjIyNDFhLTVmNzQtNDUzYS1hZjRmLTkzMDliZGUzNzMyMSIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsibW9uaXRvcmluZy1hZG1pbiIsImFuYWx5dGljcy12aWV3IiwiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXIiLCJtb25pdG9yaW5nLXZpZXciXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJhdXRob3JpemF0aW9uIjp7InBlcm1pc3Npb25zIjpbeyJzY29wZXMiOlsidmlldyIsImVkaXQiLCJjcmVhdGUiXSwiY2xhaW1zIjp7ImNhcGFiaWxpdHkiOlsiRmllbGQgVGFza3MiXX0sInJzaWQiOiI4YzZhNzRlNy0yNmJkLTRjN2YtYmYxOS00ODk3MDI2MTExNmEiLCJyc25hbWUiOiJtYW5hZ2VfRmllbGQgVGFza3MifSx7InNjb3BlcyI6WyJ2aWV3IiwiZWRpdCIsImNyZWF0ZSJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJGaWVsZCBUYXNrcyJdfSwicnNpZCI6IjNkODg5M2U3LTRhYmItNDBjZi1hMGMzLWY5NTFlMjJkYzRmMyIsInJzbmFtZSI6Im1hbmFnZS1maWVsZC10YXNrX0ZpZWxkIFRhc2tzIn0seyJzY29wZXMiOlsidmlldyJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJBc3NldCBNYW5hZ2VtZW50Il19LCJyc2lkIjoiMzE4MDJkNTMtODhhYi00YzVmLWJmZTItY2NlNTRiYTFiMjk3IiwicnNuYW1lIjoiYXNzZXRtZ210X0Fzc2V0IE1hbmFnZW1lbnQifV19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBwcm9maWxlIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJlbnRpdHlfZ3JvdXAiOiJbe1wiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXJcIjp7fX0se1wibW9uaXRvcmluZy1hZG1pblwiOnt9fSx7XCJhbmFseXRpY3Mtdmlld1wiOnt9fSx7XCJtb25pdG9yaW5nLXZpZXdcIjp7fX1dIiwibmFtZSI6IkRXRiBkd2YtdGVzdC1hbGwiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiI1MDI4Mjg0NTEiLCJnaXZlbl9uYW1lIjoiRFdGIiwiZmFtaWx5X25hbWUiOiJkd2YtdGVzdC1hbGwiLCJ0ZW5hbnQiOnsidGVuYW50SWQiOiJnZXNlcnZnRXVjIiwicmVzb3VyY2VzIjp7InNpdGVzIjpbIkFMTCJdfX0sImVtYWlsIjoiZHdmLmR3Zi10ZXN0LWFsbEBnZS5jb20ifQ.TZaj64K7d3cpUvlp1v6pOGB7Vpn40xqgmp_HFmx6S8LEQgGelF2OU9N0vmq6vqR2RMgYOIYDBvVijlZH9hwOJyRQGGtRerUmomvk7FX_IyLaOOxprUReMn8KBUjpWn32eW3juvgY--iKydYkhKjYFqVLBZD8L00l9XJlbGXDYIZUUTNTRy0YhUf4Fn3ySKDSUf2ATYQgX5O-WMeix2WJblVJTFAzCTrpcig9VK05QO1H1btQNREmhIiQ4XbHzrQ1d1Mmx0LuJEIbP7uRzdnqF9VJJcLIHovhPjGg5TQJ-E6Yhx4_2A4nekkUu4mnq2XdlL7JjiN0L-J4J2M4ElHP4A2',
      },
      body: JSON.stringify({
        type: 'maintenance',
        priority: 'medium',
        category: 'field',
        title: 'Testing create task1',
        description: 'Testing create task description1',
        dueDate: null,
        eligibleStartDate: null,
        estDurationHours: 8,
        estDurationMinutes: 0,
        estTechs: 3,
        laborHours: 24,
        laborMinutes: 0,
        scheduleDate: null,
        recurrence: { recurrenceEndByDate: '2021-12-17T09:06:54.833Z' },
        expectedParts: null,
        consumedParts: null,
        status: null,
        site: { id: '5000562' },
        asset: { id: '16122387' },
        taskLevel: 'asset',
        entityList: ['16122387'],
      }),
    })
    .expectResult((result) => {
      const res = JSON.parse(result.body);
      console.log('response', res);
      expect(res.error).toBeDefined();
      // changing it to .not.toBeDefined() will fail this expected failure scenario
    });
});

// edit taks success scenario
test('editTaskSuccess', async () => {
  return await lambdaTester(lambdaIndex.editTask)
    .event({
      headers: {
        Authorization:
          'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIyNFVhVHJ0bk9DOW80OWNhU0xLVEl4WHVGM3ItbEhkd3BRUkpxVm40em1rIn0.eyJleHAiOjE2Mzk3MzY3NTYsImlhdCI6MTYzOTczNDk1NiwiYXV0aF90aW1lIjoxNjM5NzMxNjM5LCJqdGkiOiJkZDJmMGYxYy0wOGU4LTRmOGEtYmE0NC1jYzY0YTNjNTdiMjgiLCJpc3MiOiJodHRwczovL2FwaXMtcWEucmVuZGlnaXRhbC5hcHBzLmdlLmNvbS9hdXRoL3JlYWxtcy9SRU5EUyIsImF1ZCI6ImdlLXJlbi1jbGllbnQiLCJzdWIiOiI1ZjhhNDhiNC0zZGUwLTRlNjctODgwYS0xZjQwOWJlOTQwNjIiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJnZS1yZW4tY2xpZW50Iiwic2Vzc2lvbl9zdGF0ZSI6IjMzZjIyNDFhLTVmNzQtNDUzYS1hZjRmLTkzMDliZGUzNzMyMSIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsibW9uaXRvcmluZy1hZG1pbiIsImFuYWx5dGljcy12aWV3IiwiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXIiLCJtb25pdG9yaW5nLXZpZXciXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJhdXRob3JpemF0aW9uIjp7InBlcm1pc3Npb25zIjpbeyJzY29wZXMiOlsidmlldyIsImVkaXQiLCJjcmVhdGUiXSwiY2xhaW1zIjp7ImNhcGFiaWxpdHkiOlsiRmllbGQgVGFza3MiXX0sInJzaWQiOiI4YzZhNzRlNy0yNmJkLTRjN2YtYmYxOS00ODk3MDI2MTExNmEiLCJyc25hbWUiOiJtYW5hZ2VfRmllbGQgVGFza3MifSx7InNjb3BlcyI6WyJ2aWV3IiwiZWRpdCIsImNyZWF0ZSJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJGaWVsZCBUYXNrcyJdfSwicnNpZCI6IjNkODg5M2U3LTRhYmItNDBjZi1hMGMzLWY5NTFlMjJkYzRmMyIsInJzbmFtZSI6Im1hbmFnZS1maWVsZC10YXNrX0ZpZWxkIFRhc2tzIn0seyJzY29wZXMiOlsidmlldyJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJBc3NldCBNYW5hZ2VtZW50Il19LCJyc2lkIjoiMzE4MDJkNTMtODhhYi00YzVmLWJmZTItY2NlNTRiYTFiMjk3IiwicnNuYW1lIjoiYXNzZXRtZ210X0Fzc2V0IE1hbmFnZW1lbnQifV19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBwcm9maWxlIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJlbnRpdHlfZ3JvdXAiOiJbe1wiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXJcIjp7fX0se1wibW9uaXRvcmluZy1hZG1pblwiOnt9fSx7XCJhbmFseXRpY3Mtdmlld1wiOnt9fSx7XCJtb25pdG9yaW5nLXZpZXdcIjp7fX1dIiwibmFtZSI6IkRXRiBkd2YtdGVzdC1hbGwiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiI1MDI4Mjg0NTEiLCJnaXZlbl9uYW1lIjoiRFdGIiwiZmFtaWx5X25hbWUiOiJkd2YtdGVzdC1hbGwiLCJ0ZW5hbnQiOnsidGVuYW50SWQiOiJnZXNlcnZnRXVjIiwicmVzb3VyY2VzIjp7InNpdGVzIjpbIkFMTCJdfX0sImVtYWlsIjoiZHdmLmR3Zi10ZXN0LWFsbEBnZS5jb20ifQ.ZyC17HrpsIP_S5GQ5S7zZlFdxA75iKlKnKXsJk70FRkWGWWIwOpxIjiJe_Aj8I2zkfBQfjkuoKLIHECzK4p2rYWLVsIwaG6YX9cwFFftd_chpK_sqlw9HQejwf4q365cYzrGYuK2kJQ4ZcaazA4HozzcKP3RPJDYzAfEYS65IxXmVaaxPfF7AauQ6xlGOf8rgnzohtB5Ir-zVK8hN1pbwHNb-JG0csEpPjQ6XAI03Tfv4bfS6WsdDvQxhG1tkJ-S1gHHg_GVmbMh3cXRGQI1VVTJL8DMm2P_6OfgtTurjv0Joe0g9csLR58ybuePVGzC74FnMEt7bQ4g__TTTpYKHQ',
      },
      pathParameters: {
        taskId: '61bc549575afa9748879a613',
      },
      body: JSON.stringify({ description: 'Test17', title: 'Test17' }),
    })
    .expectResult((result) => {
      const res = JSON.parse(result.body);
      console.log('response', res);
      expect(res.id).toBeDefined();
      expect(res.taskId).toBeDefined();
    });
});
// don't change token and run to understand failure scenario to be passed by passing invalid token
test('editTaskFailure', async () => {
  return await lambdaTester(lambdaIndex.editTask)
    .event({
      headers: {
        Authorization:
          'e1yJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIyNFVhVHJ0bk9DOW80OWNhU0xLVEl4WHVGM3ItbEhkd3BRUkpxVm40em1rIn0.eyJleHAiOjE2Mzk3MzY3NTYsImlhdCI6MTYzOTczNDk1NiwiYXV0aF90aW1lIjoxNjM5NzMxNjM5LCJqdGkiOiJkZDJmMGYxYy0wOGU4LTRmOGEtYmE0NC1jYzY0YTNjNTdiMjgiLCJpc3MiOiJodHRwczovL2FwaXMtcWEucmVuZGlnaXRhbC5hcHBzLmdlLmNvbS9hdXRoL3JlYWxtcy9SRU5EUyIsImF1ZCI6ImdlLXJlbi1jbGllbnQiLCJzdWIiOiI1ZjhhNDhiNC0zZGUwLTRlNjctODgwYS0xZjQwOWJlOTQwNjIiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJnZS1yZW4tY2xpZW50Iiwic2Vzc2lvbl9zdGF0ZSI6IjMzZjIyNDFhLTVmNzQtNDUzYS1hZjRmLTkzMDliZGUzNzMyMSIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsibW9uaXRvcmluZy1hZG1pbiIsImFuYWx5dGljcy12aWV3IiwiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXIiLCJtb25pdG9yaW5nLXZpZXciXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJhdXRob3JpemF0aW9uIjp7InBlcm1pc3Npb25zIjpbeyJzY29wZXMiOlsidmlldyIsImVkaXQiLCJjcmVhdGUiXSwiY2xhaW1zIjp7ImNhcGFiaWxpdHkiOlsiRmllbGQgVGFza3MiXX0sInJzaWQiOiI4YzZhNzRlNy0yNmJkLTRjN2YtYmYxOS00ODk3MDI2MTExNmEiLCJyc25hbWUiOiJtYW5hZ2VfRmllbGQgVGFza3MifSx7InNjb3BlcyI6WyJ2aWV3IiwiZWRpdCIsImNyZWF0ZSJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJGaWVsZCBUYXNrcyJdfSwicnNpZCI6IjNkODg5M2U3LTRhYmItNDBjZi1hMGMzLWY5NTFlMjJkYzRmMyIsInJzbmFtZSI6Im1hbmFnZS1maWVsZC10YXNrX0ZpZWxkIFRhc2tzIn0seyJzY29wZXMiOlsidmlldyJdLCJjbGFpbXMiOnsiY2FwYWJpbGl0eSI6WyJBc3NldCBNYW5hZ2VtZW50Il19LCJyc2lkIjoiMzE4MDJkNTMtODhhYi00YzVmLWJmZTItY2NlNTRiYTFiMjk3IiwicnNuYW1lIjoiYXNzZXRtZ210X0Fzc2V0IE1hbmFnZW1lbnQifV19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBwcm9maWxlIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJlbnRpdHlfZ3JvdXAiOiJbe1wiZ2VzZXJ2Z0V1Yy1DcnV4X1VzZXJcIjp7fX0se1wibW9uaXRvcmluZy1hZG1pblwiOnt9fSx7XCJhbmFseXRpY3Mtdmlld1wiOnt9fSx7XCJtb25pdG9yaW5nLXZpZXdcIjp7fX1dIiwibmFtZSI6IkRXRiBkd2YtdGVzdC1hbGwiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiI1MDI4Mjg0NTEiLCJnaXZlbl9uYW1lIjoiRFdGIiwiZmFtaWx5X25hbWUiOiJkd2YtdGVzdC1hbGwiLCJ0ZW5hbnQiOnsidGVuYW50SWQiOiJnZXNlcnZnRXVjIiwicmVzb3VyY2VzIjp7InNpdGVzIjpbIkFMTCJdfX0sImVtYWlsIjoiZHdmLmR3Zi10ZXN0LWFsbEBnZS5jb20ifQ.ZyC17HrpsIP_S5GQ5S7zZlFdxA75iKlKnKXsJk70FRkWGWWIwOpxIjiJe_Aj8I2zkfBQfjkuoKLIHECzK4p2rYWLVsIwaG6YX9cwFFftd_chpK_sqlw9HQejwf4q365cYzrGYuK2kJQ4ZcaazA4HozzcKP3RPJDYzAfEYS65IxXmVaaxPfF7AauQ6xlGOf8rgnzohtB5Ir-zVK8hN1pbwHNb-JG0csEpPjQ6XAI03Tfv4bfS6WsdDvQxhG1tkJ-S1gHHg_GVmbMh3cXRGQI1VVTJL8DMm2P_6OfgtTurjv0Joe0g9csLR58ybuePVGzC74FnMEt7bQ4g__TTTpYKHQ',
      },
      pathParameters: {
        taskId: '61bc549575afa9748879a613',
      },
      body: JSON.stringify({ description: 'Test17', title: 'Test17' }),
    })
    .expectResult((result) => {
      const res = JSON.parse(result.body);
      console.log('response', res);
      expect(res.message).toBe("Cannot read property 'tenant' of null");
      // changing it to .not.toBe will fail this expected failure scenario
    });
});
