/* test locally
sam local invoke GetErpCrew -e test-events/GetCrew.json --parameter-overrides FsFtrBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com FsDevBaseUrl=https://apis-intra-qa.rendigital.apps.ge.com
*/

import { Manage } from '@ge/serverless-orchestration';
import { buildAuthHeader, responses } from '@ge/serverless-utils';
import { requireNotEmpty } from '@ge/util/object-utils';

// TODO: reconcile this with crews handler once it is wired up fully
export const getCrew = async (event) => {
  try {
    console.debug('Getting crew');

    const { pathParameters } = event;
    const { crewId } = pathParameters || {};

    requireNotEmpty({ crewId });

    console.debug(`Getting crew with Id '${crewId}'`);

    const headers = buildAuthHeader(event);

    const response = await Manage.technician.getCrew({ crewId }, headers);

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
