import { ManageTransformer } from '@ge/serverless-models/src/rendigital/transformers';
import { Manage } from '@ge/serverless-orchestration/src/rendigital';

import { MockCrew } from '../../../../__mocks__/mwp';
import * as MockCrewRequest from '../../test-events/GetCrew.json';

import * as handler from './handler';

describe('Technicians', () => {
  describe('handler', () => {
    it('Gets crew', async () => {
      // stub out orchestration layer
      jest
        .spyOn(Manage.technician, 'getCrew')
        .mockImplementation(() => ManageTransformer.crewTransformer(MockCrew));

      const { body } = await handler.getCrew(MockCrewRequest);
      const { id, technicians } = JSON.parse(body);

      const { _id, members } = MockCrew;

      expect(_id).toBe(id);
      expect(technicians.length).toBe(members.length);
    });
  });
});
