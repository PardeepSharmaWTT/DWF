const { Manage } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');

export const getTaskTemplate = async ({ headers, queryStringParameters = {} }) => {
  let data = queryStringParameters;
  let response = '';
  try {
    let body = data.siteIds;
    const _headers = buildAuthHeader({ headers });
    let __headers = {
      'Content-Type': 'aplication/json',
      Authorization: _headers.Authorization,
    };

    response = await Manage.taskImport.getTaskTemplate({ headers: __headers, body });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const uploadTasks = async (event) => {
  try {
    let _headers = buildAuthHeader(event);
    let __headers = {
      'Content-Type': 'multipart/form-data; boundary="-divider-"',
      Authorization: _headers.Authorization,
      tenantId: _headers.tenantId,
      Accept: '*/*',
      'Accept-Encoding': 'gzip, deflate, br',
    };

    let { body } = event;
    const response = await Manage.taskImport.postTaskUpload({
      headers: __headers,
      body,
    });
    return responses.success(response);
  } catch (err) {
    console.log('error response-> ', err);
    return responses.error(err);
  }
};
