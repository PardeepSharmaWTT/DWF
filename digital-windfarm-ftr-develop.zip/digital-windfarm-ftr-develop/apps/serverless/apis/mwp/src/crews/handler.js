const { Common } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');

export const createCrew = async ({ headers, body: crew }) => {
  try {
    const parsedCrew = JSON.parse(crew);
    console.log('parsedCrew OBJECT', parsedCrew);
    const _headers = buildAuthHeader({ headers });
    const response = await Common.crews.create({ headers: _headers, crew: parsedCrew });
    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getCrews = async ({ headers, queryStringParameters }) => {
  const { serviceGroup, start, end } = queryStringParameters;
  try {
    const _headers = buildAuthHeader({ headers });
    const _params = {
      serviceGroup: serviceGroup ? serviceGroup : '',
      start: start,
      end: end,
    };
    console.log('Getting crews data', _params);

    const response = await Common.crews.get({
      headers: _headers,
      params: _params,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getCrew = async ({ headers, pathParameters }) => {
  const { crewId } = pathParameters;
  console.log('Getting getcrew ', crewId);
  try {
    const _headers = buildAuthHeader({ headers });
    const response = await Common.crews.getCrew({
      headers: _headers,
      params: { crewId },
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const editCrews = async ({ headers, pathParameters, body: crew }) => {
  const { crewId } = pathParameters;
  console.log('edit crews', crewId, crew);
  try {
    const _headers = buildAuthHeader({ headers });
    const response = await Common.crews.edit({
      headers: _headers,
      crewId,
      crew,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const deleteCrews = async ({ headers, pathParameters }) => {
  const { crewId } = pathParameters;
  console.log('Deleting task', crewId);
  try {
    const _headers = buildAuthHeader({ headers });
    const response = await Common.crews.deleteCrew({
      headers: _headers,
      crewId,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const deleteAllCrews = async ({ headers, queryStringParameters }) => {
  const { serviceGroup } = queryStringParameters;
  console.log('Deleting all crews', serviceGroup);
  try {
    const _headers = buildAuthHeader({ headers });
    const _params = {
      serviceGroup: serviceGroup,
    };
    const response = await Common.crews.deleteAllCrews({
      headers: _headers,
      params: _params,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
