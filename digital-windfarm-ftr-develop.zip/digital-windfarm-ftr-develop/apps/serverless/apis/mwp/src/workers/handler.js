const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  intercept,
  bodyParserInterceptor,
  responses,
} = require('@ge/serverless-utils');

export const getWorkers = intercept([bodyParserInterceptor], async ({ headers, body }) => {
  const _headers = buildAuthHeader({ headers });
  const { serviceGroupIds, types, sortKey, orderDirection, pageSize, pageIdx, start, end } = body || {};

  try {
    console.log('Getting workers data');

    let _params = {};
    const data = serviceGroupIds.split(',');
    const chunkSize = 80;
    let result = [];
    let response = {};
    for (let i = 0; i < data.length; i += chunkSize) {
      const chunk = data.slice(i, i + chunkSize).join(',');
      _params = {
        serviceGroupIds: chunk,
        types,
        sortKey,
        orderDirection,
        pageIdx,
        pageSize,
        ...(start && start),
        ...(end && end),
      };

      response = await Common.tasks.getAllWorkers({
        headers: _headers,
        params: _params,
      });
      result = result.concat(response.users);
    }
    const res = {
      users: result,
    };
    return responses.success(res);
  } catch (err) {
    return responses.error(err);
  }
});
