const { Common } = require('@ge/serverless-orchestration');
const { buildAuthHeader, responses } = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

export const getTaskSources = async ({ headers, queryStringParameters = {} }) => {
  const { language = 'en' } = queryStringParameters;
  const { assetType } = queryStringParameters || {};
  const { page } = queryStringParameters || {};

  try {
    console.log(`Getting task sources for ${assetType || 'ALL'} in ${language}`);

    const _headers = buildAuthHeader({ headers });
    const response = await Common.taskTemplate.getTaskSources({
      ...(assetType && { assetType }),
      ...(language && { language }),
      ...(page && { page }),
      headers: _headers,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getTaskWorkScopes = async ({ headers, queryStringParameters = {} }) => {
  const { language = 'en' } = queryStringParameters;
  const { assetType } = queryStringParameters || {};

  try {
    console.log(`Getting task work scopes for ${assetType || 'ALL'} in ${language}`);

    const _headers = buildAuthHeader({ headers });
    const response = await Common.taskTemplate.getTaskWorkScopes({
      ...(assetType && { assetType }),
      ...(language && { language }),
      headers: _headers,
    });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};

export const getTaskTemplates = async ({ headers, queryStringParameters = {} }) => {
  const { source } = queryStringParameters;

  try {
    requireNonNull({ source });
    console.log(`Getting task templates for type ${source}`);

    const _headers = buildAuthHeader({ headers });
    const response = await Common.taskTemplate.getTaskTemplates({ source, headers: _headers });

    return responses.success(response);
  } catch (err) {
    return responses.error(err);
  }
};
