import dayjs from 'dayjs';

import { DateTimeFormats } from '@ge/models/constants';

const { Common } = require('@ge/serverless-orchestration');
const {
  buildAuthHeader,
  intercept,
  bodyParserInterceptor,
  responses,
} = require('@ge/serverless-utils');
const { requireNonNull } = require('@ge/util/object-utils');

const TASK_STATUS =
  ';taskStatus!=completed;source=in=(realtimeCases,realtimeCasesFaulted,realtimeCasesSystem,realtimeCasesWarning,realtimeCasesTemporaryConfigChange)';

export const getNotCompletedTasks = async ({ headers, queryStringParameters }) => {
  const _headers = buildAuthHeader({ headers });
  const { startDate, endDate, status, pageIdx, pageSize, assetIds } = queryStringParameters || {};
  console.log(' Getting tasks with params: ', queryStringParameters);
  try {
    if (status && status.toLowerCase() !== 'notcompleted') {
      const response = await Common.tasks.getByStatus({
        headers: _headers,
        status,
        pageSize,
        pageIdx,
        assetIds,
      });
      return responses.success(response);
    }
    if (startDate && endDate) {
      const response = await Common.tasks.getCalendar({
        headers: _headers,
        startDate: dayjs(startDate).format(DateTimeFormats.ENDPOINT_PARAM),
        endDate: dayjs(endDate).format(DateTimeFormats.ENDPOINT_PARAM),
        pageSize,
        pageIdx,
        assetIds,
      });
      return responses.success(response);
    }
    let query = null;
    if (assetIds && assetIds.length > 0) query = 'assetKey=in=(' + assetIds + ')';
    query = query + TASK_STATUS;
    const params = { pageIdx, pageSize, query };
    const response = await Common.assetTasks.getNotCompletedTasksByAssetId({
      headers: _headers,
      params,
    });
    return responses.success(response);
  } catch (err) {
    console.error(err);
    return responses.error(err);
  }
};

export const postNotCompletedTasks = intercept(
  [bodyParserInterceptor],
  async ({ headers, body }) => {
    requireNonNull(headers);
    requireNonNull(body);

    const { startDate, endDate, status, pageIdx, pageSize, assetIds } = body || {};
    try {
      const _headers = buildAuthHeader({ headers });
      if (status && status.toLowerCase() !== 'notcompleted') {
        const response = await Common.tasks.getByStatus({
          headers: _headers,
          status,
          pageSize,
          pageIdx,
          assetIds,
        });
        return responses.success(response);
      }
      if (startDate && endDate) {
        const response = await Common.tasks.getCalendar({
          headers: _headers,
          startDate: dayjs(startDate).format(DateTimeFormats.ENDPOINT_PARAM),
          endDate: dayjs(endDate).format(DateTimeFormats.ENDPOINT_PARAM),
          pageSize,
          pageIdx,
          assetIds,
        });
        return responses.success(response);
      }
      let query = '';
      if (assetIds && assetIds.length > 0) query = 'assetKey=in=(' + assetIds + ')';
      query = query + TASK_STATUS;
      const params = { pageIdx, pageSize, query };
      const response = await Common.assetTasks.getNotCompletedTasksByAssetId({
        headers: _headers,
        params,
      });
      return responses.success(response);
    } catch (err) {
      console.error(err);
      return responses.error(err);
    }
  },
);
