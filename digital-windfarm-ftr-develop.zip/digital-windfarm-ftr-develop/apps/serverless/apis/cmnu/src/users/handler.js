const {
  parseJwt,
  sendResponse,
  updateItem,
  getHeader,
  getPrefs,
  getViewPrefs,
} = require('@ge/serverless-utils');

const { USERS_TABLE_NAME } = process.env;

exports.getUsersPrefs = async (event, context, callback) => {
  const prefs = await getPrefs(event);
  sendResponse(200, { prefs }, callback);
};

exports.getUsersViewPrefs = async (event, context, callback) => {
  const prefs = await getViewPrefs(event);
  sendResponse(200, { prefs }, callback);
};

exports.saveUsersPrefs = (event, context, callback) => {
  const parsedJwt = parseJwt(getHeader('Authorization', event.headers));
  const subject = parsedJwt.sub;
  const prefs = JSON.parse(event.body);

  if (prefs === null || typeof prefs === 'undefined' || prefs === '') {
    sendResponse(400, `No preferences defined for user: ${subject}`, callback);
    return;
  }

  let featurePrefs = {};
  const fprefs = prefs.featurePrefs;
  if (fprefs !== null && typeof fprefs !== 'undefined' && fprefs !== '') {
    featurePrefs = JSON.stringify(fprefs);
  }

  const params = {
    TableName: USERS_TABLE_NAME,
    Key: {
      ID: `USER#${subject}`,
    },
    UpdateExpression: 'set #LNG = :lng, #THM = :thm, #FEATURE = :feature',
    ExpressionAttributeNames: {
      '#LNG': 'USER_PREF_LNG',
      '#THM': 'USER_PREF_THM',
      '#FEATURE': 'USER_PREF_FEATURE',
    },
    ExpressionAttributeValues: {
      ':lng': prefs.language,
      ':thm': prefs.theme,
      ':feature': featurePrefs,
    },
  };

  console.log(`Updating prefs: ${JSON.stringify(params)}`);

  updateItem(params).then(() => {
    // Results are empty on a successful save.
    sendResponse(200, null, callback);
  });
};

exports.saveUsersViewPrefs = (event, context, callback) => {
  const parsedJwt = parseJwt(getHeader('Authorization', event.headers));
  const subject = parsedJwt.sub;
  const prefs = JSON.parse(event.body);

  if (prefs === null || typeof prefs === 'undefined' || prefs === '') {
    sendResponse(400, `No preferences defined for user: ${subject}`, callback);
    return;
  }

  let sitesFilter = [];
  let storageSitesFilter = [];
  const { currentView } = prefs;
  if (currentView !== null && typeof currentView !== 'undefined' && currentView !== '') {
    sitesFilter = currentView.sites;
    storageSitesFilter = currentView.storageSites;
  }

  const params = {
    TableName: USERS_TABLE_NAME,
    Key: {
      ID: `USER#${subject}`,
    },
    UpdateExpression: 'set #SITES = :sites, #STORAGE_SITES = :storageSites',
    ExpressionAttributeNames: {
      '#SITES': 'USER_PREF_SITES',
      '#STORAGE_SITES': 'USER_PREF_STORAGE_SITES',
    },
    ExpressionAttributeValues: {
      ':sites': sitesFilter,
      ':storageSites': storageSitesFilter,
    },
  };

  console.log(`Updating prefs: ${JSON.stringify(params)}`);

  updateItem(params).then(() => {
    // Results are empty on a successful save.
    sendResponse(200, null, callback);
  });
};
