// not cleaning this up because it's temporary
export const MockErpSubmitResponse = {
  "taskId": "1671678",
    "erpCurrentStatus": "IN_PROGRESS",                                      // Set as IN_PROGRESS during Create SR
    "erpBodyStatus": "",                                                    // Set empty during Create SR
    "errorDetails": [],                                                 // Set empty array during Create SR
    "erpMetadata": {
        "owner": "503191835",                                           // User SSO who created the SR
        "ownerName": "Rupert the Owl",                                      // User firstname lastname who created the SR
          
        "assetSerialNumber": "17131196",                                // Asset Serial Number of the turbine
        "tag": "GE_ONW_Colorado_Highlands_8412 | WP2_1",                // Site name | Turbine Name
          
        "srType": "FSA - Non PM",
        "srProblemSummary": "M3: Gearbox, Yaw, HPU",
        "severity": "Standard",
        "scadaFaultCode": "1",
        "srProblemCode": "ANEMWIND",
        "pacNumber": "",
        "majorCompSupplier": "ABB",
        "majorCompSN": "123",
        "description": "test",
        "quoteNumber": "",
        "laborDetails": [
            {
                "rowNumber": 1,
                "labortype": "Repair",
                "quantity": 2,
                "serviceActivity": "Labor"                              // Set as "Labor" always
            },
            {
                "rowNumber": 2,
                "labortype": "Troubleshoot",
                "quantity": 11,
                "serviceActivity": "Labor"
            }
        ],
       "techAssignments": ["503190670", "503190671"],
       "assignedTechEmailIds": [ "sivnagkumar.dayal@ge.com", "sankaranand.ms@ge.com"  ],
       "scheduledDate": [                                               // Current Time of Site Specific Timezone during Create SR
            "2020",
            "10",
            "28",
            "00",
            "00",
            "00",
            "000"
        ],
        "partDetails": [
            {
              
                "needByDate": "13-Apr-2022",
                "addressType": "A",
                "shippingAddress": "Default",
                "alternateAddress": "Chicago",
                "phoneNumber": "8939724270",
                "instructions": "Deliver to Jimmy",
                "parts": [
                    {
                        "rowNumber": "1",
                        "partNumber": "445W8601P001",
                        "partQuantity": 5,
                        "partName": "P1",
                        "serviceActivity": "COI",
                        "replenish": true, 
                        "ecoTurbineType" : "N",                   // Identify using assetSerialNumber - by hitting AssetService             
                        "priority": "DOWN TURBINE",
                    },
                    {
                        "rowNumber": "2",
                        "partNumber": "445W8601P002",
                        "partQuantity": 5,
                        "partName": "P1",
                        "serviceActivity": "COI",
                        "replenish": true, 
                        "ecoTurbineType" : "N",                        
                        "priority": "DOWN TURBINE",
                    }
                ]
               },
               {   
                "needByDate": "13-Apr-2022",
                "addressType": "A",
                "shippingAddress": "Default",
                "alternateAddress": "Chicago",
                "phoneNumber": "8939724270",
                "instructions": "Deliver to Jimmy",
                "parts": [
                    {
                        "rowNumber": "1",
                        "partNumber": "445W8601P001",
                        "partQuantity": 5,
                        "partName": "P1",
                        "serviceActivity": "COI",
                        "replenish": true, 
                        "ecoTurbineType" : "N",                      
                        "priority": "DOWN TURBINE",
                    }
                ],
               },
              ],  
            },
    };