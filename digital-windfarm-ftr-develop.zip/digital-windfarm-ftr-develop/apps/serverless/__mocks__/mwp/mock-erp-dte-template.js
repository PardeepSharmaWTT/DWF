// not cleaning this up because it's temporary
export const MockErpDteTemplate = {
  "tenantId": "dte-tenant_id-value",
  "erpSource": "DTE_MAXIMO",
  "templateHeaderCode": {
    "create" : "CREATE_WO",
    "edit" : "EDIT_WO"            
  },
  "sections": [
    {
      "orderNo": 1,
      "hidden": false,
      "collapsed": false,
      "fields": [
        {
          "type": "text",
          "bindingPropertyName": "shortDescription",
          "labelCode": "WO_SHORT_DESCRIPTION",
          "required": true,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "textarea",
          "bindingPropertyName": "longDescription",
          "labelCode": "WO_LONG_DESCRIPTION",
          "required": false,       
          "create" : {
              "readOnly": true,
              "hidden": false
          },
          "edit" : {
              "readOnly": true,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "location",
          "labelCode": "LOCATION",
          "values": "LOCATION_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "required": true,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "assetDescription",
          "labelCode": "ASSET_DESCRIPTION",
          "values": "ASSET_DESCRIPTION_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "parentName": "LOCATION_LIST",
          "required": false,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "workType",
          "labelCode": "WORK_TYPE",
          "values": "WORK_TYPE_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "required": true,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "subType",
          "labelCode": "SUB_TYPE",
          "values": "SUB_TYPE_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "parentName": "WORK_TYPE_LIST",
          "required": true,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "oemPlatform",
          "labelCode": "OEM_PLATFORM",
          "values": "OEM_PLATFORM_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "required": false,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "oemFaultCode",
          "labelCode": "OEM_FAULT_CODE",
          "values": "OEM_FAULT_CODE_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "parentName": "OEM_PLATFORM_LIST",
          "required": false,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "toolboxHardware",
          "labelCode": "TOOLBOX_HARDWARE",
          "values": "TOOLBOX_HARDWARE_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "required": false,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "diagAlarmCode",
          "labelCode": "DIAG_ALARM_CODE",
          "values": "DIAG_ALARM_CODE_LIST",
          "defaultSelection" : "PLEASE_SELECT",
          "parentName": "TOOLBOX_HARDWARE_LIST",
          "required": false,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "dropdown",
          "bindingPropertyName": "lead",
          "labelCode": "LEAD",
          "values": "LEAD_LIST_API",                                                                // To be fetched from different API on task svc
          "defaultSelection" : "PLEASE_SELECT",
          "required": false,       
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "radio",
          "bindingPropertyName": "safetyImpact",
          "labelCode": "SAFETY_IMPACT",
          "values": "YES_NO_LIST",                            
          "defaultSelection" : "NO",
          "required": true,        
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        },
        {
          "type": "radio",
          "bindingPropertyName": "environmentImpact",
          "labelCode": "EVNIRONMENT_IMPACT",
          "values": "YES_NO_LIST",                            
          "defaultSelection" : "NO",
          "required": true,        
          "create" : {
              "readOnly": false,
              "hidden": false
          },
          "edit" : {
              "readOnly": false,
              "hidden": false
          }
        }
      ]
    }
  ]
}