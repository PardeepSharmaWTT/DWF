export const MockErpDfsaTemplate = {
  tenantId: '58250e78-f5ac-46bd-99de-14db5e4b4e6d',
  erpSource: 'RACES',
  templateHeaderCode: {
    create: 'CREATE_SR',
    edit: 'EDIT_SR',
  },
  sections: [
    {
      sectionHeaderCode: 'SERVICE_REQUEST',
      orderNo: 1,
      hidden: false,
      collapsed: false,
      fields: [
        {
          type: 'text',
          bindingPropertyName: 'owner',
          labelCode: 'OWNER',
          custom: 'owner',
          required: true,
          create: {
            readOnly: true,
            hidden: false,
          },
          edit: {
            readOnly: true,
            hidden: false,
          },
        },
        {
          type: 'text',
          bindingPropertyName: 'assetSerialNumber',
          labelCode: 'TAG',
          custom: 'tag',
          required: true,
          create: {
            readOnly: true,
            hidden: false,
          },
          edit: {
            readOnly: true,
            hidden: false,
          },
        },
        {
          type: 'dropdown',
          bindingPropertyName: 'srType',
          labelCode: 'SR_TYPE',
          values: 'SR_TYPE_LIST',
          defaultSelection: 'WARRANTY_MCE',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'text',
          bindingPropertyName: 'srProblemSummary',
          labelCode: 'PROBLEM_SUMMARY',
          maxlength: 200,
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'dropdown',
          bindingPropertyName: 'severity',
          labelCode: 'SEVERITY',
          values: 'SEVERITY_LIST',
          defaultSelection: 'STANDARD',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'dropdown',
          bindingPropertyName: 'scadaFaultCode',
          labelCode: 'SCADA_FAULT_CODE',
          values: 'SCADA_FAULT_CODE_LIST',
          defaultSelection: 'PLEASE_SELECT',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'dropdown',
          bindingPropertyName: 'srProblemCode',
          labelCode: 'PROBLEM_CODE',
          values: 'PROBLEM_CODE_LIST',
          defaultSelection: 'PLEASE_SELECT',
          dependOn: 'SR_TYPE_LIST',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'text',
          bindingPropertyName: 'pacNumber',
          labelCode: 'PAC',
          maxlength: 17,
          required: false,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
          validator: '^\d{12}$',
        },
        {
          type: 'dropdown',
          bindingPropertyName: 'majorCompSupplier',
          labelCode: 'MAJOR_COMPONENT_SUPPLIER',
          values: 'MAJOR_COMPONENT_SUPPLIER_LIST',
          defaultSelection: 'PLEASE_SELECT',
          dependOn: 'SR_TYPE_LIST',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'text',
          bindingPropertyName: 'majorCompSN',
          labelCode: 'MAJOR_COMPONENT_SN',
          maxlength: 200,
          required: false,       
          create : {
              readOnly: false,
              hidden: false
          },
          edit : {
              readOnly: false,
              hidden: false
          }
        },
        {
          type: 'textarea',
          bindingPropertyName: 'description',
          labelCode: 'DESCRIPTION',
          maxlength: 2000,
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
          validator: '^[^@#$;]+$',
        },
      ],
    },
    {
      sectionHeaderCode: 'ASSIGNED_TECHS',
      orderNo: 2,
      hidden: false,
      collapsed: false,
      fields: [
        {
          type: 'technicians',
          labelCode: 'ASSIGNED_TECHNICIANS',
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
      ],
    },
    {
      sectionHeaderCode: 'CHARGES',
      orderNo: 3,
      hidden: false,
      collapsed: false,
      fields: [
        {
          type: 'labor_charges',
          labelCode: 'LABOR',
          laborTypeHeaderCode: 'LABOR_TYPE',
          quantityHeaderCode: 'QUANTITY_LABOR_HRS',
          repairLabelCode: 'REPAIR',
          troubleshootingLabelCode: 'TROUBLESHOOTING',
          troubleshootingNoteLabelCode: 'TROUBLESHOOTING_NOTE',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
      ],
    },
    {
      sectionHeaderCode: 'PARTS',
      orderNo: 4,
      hidden: false,
      collapsed: false,
      fields: [
        {
          type: 'parts',
          partNoHeaderCode: 'PART_NO',
          partNameHeaderCode: 'PART_NAME',
          quantityHeaderCode: 'PART_QUANTITY',
          serviceActivityHeaderCode: 'PART_SERVICE_ACTIVITY',
          placeOrderHeaderCode: 'PART_PLACE_ORDER',
          serviceActivityValues: 'SERVICE_ACTIVITY_LIST',
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
      ],
    },
    {
      sectionHeaderCode: null,
      orderNo: 5,
      hidden: false,
      collapsed: false,
      fields: [
        {
          type: 'dropdown',
          bindingPropertyName: 'priority',
          labelCode: 'SHIPPING_PRIORITY',
          values: 'SHIPPING_PRIORITY',
          defaultSelection: 'PLEASE_SELECT',
          dependOn: 'SR_TYPE_LIST',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'date',
          bindingPropertyName: 'needByDate',
          labelCode: 'NEED_BY_DATE',
          defaultDate: 'CURRENT_DATE',
          helpTextCode: 'NEED_BY_DATE_HELP',
          required: true,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'address',
          shippingAddressCode: 'SHIPPING_ADDRESS',
          alternateAddressCode: 'ALTERNATE_ADDRESS',
          defaultLabelCode: 'DEFAULT',
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
        {
          type: 'text',
          bindingPropertyName: 'phoneNumber',
          labelCode: 'PHONE',
          maxlength: 12,
          required: false,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
          validator: '^d{10}$',
        },
        {
          type: 'text',
          bindingPropertyName: 'instructions',
          labelCode: 'SHIP_TO_CONTACT_INSTRUCTIONS',
          maxlength: 250,
          required: false,
          create: {
            readOnly: false,
            hidden: false,
          },
          edit: {
            readOnly: false,
            hidden: false,
          },
        },
      ],
    },
  ],
};