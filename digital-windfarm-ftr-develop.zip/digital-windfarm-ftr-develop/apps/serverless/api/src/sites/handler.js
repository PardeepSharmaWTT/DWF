const mockAssets = require('@ge/mocks/dist/entities/assets').assets;
const mockSites = require('@ge/mocks/dist/entities/sites').sites;
const {
  buildResponse,
  getSitesFilter,
  includeMetrics,
  intercept,
  noMocksInterceptor,
} = require('@ge/serverless-utils');

exports.getSite = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;

  const site = mockSites.find((s) => s.id === id);

  return buildResponse(200, { site });
});

exports.getSiteAssets = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;
  const { queryStringParameters } = event;

  if (queryStringParameters && queryStringParameters.state) {
    const states = queryStringParameters.state.split(',');
    const siteAssets = mockAssets.filter(
      (asset) => asset.site.id === id && states.includes(asset.metrics.state),
    );

    return buildResponse(200, { assets: siteAssets });
  }
  const siteAssetsWithMetrics = mockAssets.filter((asset) => asset.site.id === id);
  return buildResponse(200, { assets: siteAssetsWithMetrics });
});

exports.getSites = intercept([noMocksInterceptor], async (event) => {
  const sitesToFilterOn = await getSitesFilter(event);
  // eslint-disable-next-line no-unused-vars
  const addMetrics = includeMetrics(event.queryStringParameters);

  let sites;
  if (sitesToFilterOn.length === 0) {
    sites = mockSites.slice(0, 100);
  } else {
    sites = mockSites.filter((aSite) => sitesToFilterOn.includes(aSite.id)).slice(0, 100);
  }

  // TODO: Trim site metrics

  const sitesResponse = {
    sites,
  };

  return buildResponse(200, sitesResponse);
});
