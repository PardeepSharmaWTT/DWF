const { metrics, toDayjs, QueryParams } = require('@ge/metrics');
const { responses } = require('@ge/serverless-utils');

export const getSiteAssetMetrics = (event) => {
  const { id: siteId } = event.pathParameters;
  const { interval, measure, start, end } = event.queryStringParameters;

  if (!measure) {
    return responses.error('Measure param is required.');
  }
  if (end && !start) {
    return responses.error('Cannot specify end time without start time.');
  }

  const params = new QueryParams(measure)
    .withField(measure)
    .withStart(toDayjs(start))
    .withEnd(toDayjs(end))
    .withAggregation(interval);

  return metrics.site
    .getSiteAssetMeasurement(siteId, params)
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
};

export const getSiteMetrics = (event) => {
  const { id: siteId } = event.pathParameters;
  const { interval, measure, start, end } = event.queryStringParameters;

  if (!measure) {
    return responses.error('Measure param is required.');
  }
  if (end && !start) {
    return responses.error('Cannot specify end time without start time.');
  }

  const params = new QueryParams(measure)
    .withField(measure)
    .withStart(toDayjs(start))
    .withEnd(toDayjs(end))
    .withAggregation(interval);

  return metrics.site
    .getSiteMeasurement(siteId, params)
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
};
