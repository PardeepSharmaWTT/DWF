const { path } = require('ramda');

const { monitorSitesTable } = require('@ge/mocks/dist/views/monitor/monitorSitesTable');
const { intercept, noMocksInterceptor, responses } = require('@ge/serverless-utils');

export const getMonitorSitesTable = intercept([noMocksInterceptor], (event) => {
  const queryStringParameters = event.queryStringParameters || {};
  const { sort, direction } = queryStringParameters;
  console.debug(`Getting monitor sites data with params ${sort}, ${direction}`);

  return Promise.resolve(sliceData(50, sort, direction))
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
});

const sliceData = (size, sort, direction) => {
  const { entities } = monitorSitesTable;
  const data = monitorSitesTable.data.sort(getSortFn(sort, direction, entities)).slice(0, size);
  const regions = data
    .map((d) => d.region.id)
    .reduce((acc, id) => ({ ...acc, [id]: entities.regions[id] }), {});
  const sites = data
    .map((d) => d.site.id)
    .reduce((acc, id) => ({ ...acc, [id]: entities.sites[id] }), {});

  console.debug(
    `Returned ${data.length} rows with ${Object.keys(regions).length} region and ${
      Object.keys(sites).length
    } site entities`,
  );

  return { data, entities: { regions, sites } };
};

const getSortFn = (sort, direction, entities) => (a, b) => {
  if (!sort) return 0;
  const sortPath = sort.split('.');
  if (!sortPath.length) return 0;

  let rhs;
  if (sortPath[0] === 'site') {
    const aVal = path(sortPath.slice(1), entities.sites[a.site.id]);
    const bVal = path(sortPath.slice(1), entities.sites[b.site.id]);
    rhs = compare(aVal, bVal);
  } else if (sortPath[0] === 'region') {
    const aVal = path(sortPath.slice(1), entities.regions[a.region.id]);
    const bVal = path(sortPath.slice(1), entities.regions[b.region.id]);
    rhs = compare(aVal, bVal);
  } else {
    const aVal = path(sortPath, a);
    const bVal = path(sortPath, b);
    rhs = compare(aVal, bVal);
  }
  return direction === 'desc' ? rhs * -1 : rhs;
};

const compare = (aVal, bVal) => {
  if (typeof aVal === 'number') {
    return aVal - bVal;
  }
  return aVal.localeCompare(bVal);
};
