const { siteManager } = require('@ge/mocks-logic');
const { intercept, noMocksInterceptor, responses } = require('@ge/serverless-utils');

export const getScheduledTasks = intercept([noMocksInterceptor], (event) => {
  const params = event.queryStringParameters || {};
  console.debug('Getting scheduled tasks');

  return Promise.resolve(siteManager.getScheduledTasks(params.type, params.ids))
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
});

export const getBacklogTasks = intercept([noMocksInterceptor], (event) => {
  const params = event.queryStringParameters || {};
  console.debug('Getting backlog tasks');

  return Promise.resolve(siteManager.getBacklogTasks(params.type, params.ids))
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
});

export const getTasks = intercept([noMocksInterceptor], () => {
  console.debug('Getting all tasks');

  return Promise.resolve(siteManager.getTasks())
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
});

export const getTechnicians = intercept([noMocksInterceptor], () => {
  console.debug('Getting technicians with availability');

  return Promise.resolve(siteManager.getTechnicians())
    .then((data) => responses.success(data))
    .catch((e) => responses.error(e));
});
