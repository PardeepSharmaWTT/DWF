const mockTickets = require('@ge/mocks/dist/entities/tickets').tickets;
const { buildResponse, intercept, noMocksInterceptor } = require('@ge/serverless-utils');

exports.getTicket = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;

  const mockTicket = mockTickets.find((ticket) => id === ticket.id);

  return buildResponse(200, { ticket: mockTicket });
});

exports.getTicketsByEvent = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;

  const ticketsWithEvent = mockTickets.filter((ticket) => ticket.event.id === id);

  const ticketsResponse = {
    tickets: ticketsWithEvent.slice(0, 100),
  };

  return buildResponse(200, ticketsResponse);
});

exports.getTickets = intercept([noMocksInterceptor], async () => {
  // Build the response object from the mock array
  const ticketsResponse = {
    tickets: mockTickets.slice(0, 100),
  };

  return buildResponse(200, ticketsResponse);
});
