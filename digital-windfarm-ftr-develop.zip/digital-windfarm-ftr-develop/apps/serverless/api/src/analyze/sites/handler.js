const { analyze } = require('@ge/mocks-logic');
const { intercept, noMocksInterceptor, responses } = require('@ge/serverless-utils');

export const getSiteIecCategory = intercept([noMocksInterceptor], (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { category },
  } = event;
  console.debug(`Getting IEC category ${category} for Site ${id}`);

  return Promise.resolve(analyze.getSiteIecCategory(id, category))
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});

export const getSiteCards = intercept([noMocksInterceptor], () => {
  console.debug('Getting all site KPI cards');

  return Promise.resolve(analyze.getSiteKpiCards())
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});

export const getSiteKpiData = intercept([noMocksInterceptor], (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { categories },
  } = event;
  const categoryArray = categories.split(',');
  console.debug(`Getting Site KPI data (${categoryArray.join(', ')}) for Site ${id}`);

  return Promise.resolve(analyze.getSiteKpiData(id, categoryArray))
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});

export const getSiteKpiDataByRegion = intercept([noMocksInterceptor], (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { categories = [] },
  } = event;
  const categoryArray = categories.split(',');

  console.debug(`Getting Site KPI data ${categoryArray.join(', ')} for Region ${id}`);

  return Promise.resolve(analyze.getSiteKpiByRegion(id, categoryArray))
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});

export const getSitePowerCurveByAsset = intercept([noMocksInterceptor], (event) => {
  const {
    pathParameters: { id },
  } = event;
  const { regression } = event.queryStringParameters || {};
  const regressionBool = regression === 'true';
  console.debug(`Getting asset${regressionBool ? ' regression ' : ' '}power curves for site ${id}`);

  return Promise.resolve(analyze.getSitePowerCurveByAsset(id, regressionBool))
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});

export const getConditionAggregates = intercept([noMocksInterceptor], (event) => {
  const {
    pathParameters: { id },
    queryStringParameters: { conditions },
  } = event;
  const conditionsArray = conditions.split(',');
  console.debug(`Getting Site condition data (${conditionsArray.join(', ')}) for Site ${id}`);
  return Promise.resolve(analyze.getSiteConditionAggregate(id, conditionsArray))
    .then((response) => responses.success(response))
    .catch((e) => responses.error(e));
});
