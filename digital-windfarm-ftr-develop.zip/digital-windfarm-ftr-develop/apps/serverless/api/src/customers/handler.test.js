/* eslint-disable no-unused-vars */
import { customers } from '@ge/mocks/dist/entities/customers';
import { buildResponse, EnvVar } from '@ge/serverless-utils';

import { getCustomers } from './handler';

const mockJwt =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJjb2duaXRvOmdyb3VwcyI6W119.PvuRLMwacbS7n3iCizBkavgyLV6KsKiMf6uqKZeaIkM';

const mockEvent = {
  headers: {
    Authorization: mockJwt,
  },
};

const mockResponse = buildResponse(200, { customers });

describe('Customers', () => {
  describe('handler', () => {
    it('should return mock customers', async () => {
      jest.spyOn(EnvVar, 'noMockData', 'get').mockReturnValue(false);

      expect(await getCustomers(mockEvent));
    });
  });
});
