const { customers } = require('@ge/mocks/dist/entities/customers');
const { buildResponse, intercept, noMocksInterceptor } = require('@ge/serverless-utils');

exports.getCustomers = intercept([noMocksInterceptor], async () => {
  const customersResponse = {
    customers,
  };

  return buildResponse(200, customersResponse);
});
