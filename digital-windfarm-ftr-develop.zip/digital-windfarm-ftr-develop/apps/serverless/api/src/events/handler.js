const mockEvents = require('@ge/mocks/dist/entities/events').events;
const {
  buildResponse,
  getSitesFilter,
  intercept,
  noMocksInterceptor,
} = require('@ge/serverless-utils');

exports.getEvent = intercept([noMocksInterceptor], async (event) => {
  const { id } = event.pathParameters;

  const mockEvent = mockEvents.find((e) => id === e.id);

  return buildResponse(200, { event: mockEvent });
});

exports.getEventHistory = intercept([noMocksInterceptor], async () => {
  // const { id } = event.pathParameters;

  const eventHistory = [];

  const historyResponse = {
    history: eventHistory,
  };

  return buildResponse(200, historyResponse);
});

exports.getEvents = intercept([noMocksInterceptor], async (event) => {
  const sitesToFilterOn = await getSitesFilter(event);
  let events;

  if (sitesToFilterOn.length === 0) {
    events = mockEvents.slice(0, 100);
  } else {
    events = mockEvents
      .filter((anEvent) => sitesToFilterOn.includes(anEvent.site.id))
      .slice(0, 100);
  }
  // Build the response object from the mock array
  const eventsResponse = {
    events,
  };

  return buildResponse(200, eventsResponse);
});
