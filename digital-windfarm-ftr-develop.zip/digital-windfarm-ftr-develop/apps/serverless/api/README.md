# AWS SAM API
This project contains all of the AWS SAM-specific logic for deploying services into an API Gateway -> AWS Cognito -> Lambda stack.

## Build
After you have installed all depedencies with `yarn`, run the following command to build the deployable assets:
```
yarn build
```
The output will be in the `/.aws-sam` folder, and will be automatically picked up by the SAM CLI package command.

To run your SAM project locally, you can run the build in "watch" mode with the command `yarn build:watch` to automatically rebuild the project on code changes and the build folder will always be kept up-to-date with the source tree.

## Test
Jest is installed as a test runner, and can be invoked using the following command:
```
yarn test
```
If you prefer to keep the test runner watching the codebase for changes, using the `yarn test:watch` command will re-run the suite on code changes.

## Lint
ESLint is configured to analyze all `.js` file extensions using the AirBnb base lint rules. You can run this locally before it goes into the pipeline (offenses will fail the build) by using the following command:
```
yarn lint
```
