# Cognito Pools for Authentication & Authorization

## Helpful Links
[Understanding Cognito OAuth Grants](https://aws.amazon.com/blogs/mobile/understanding-amazon-cognito-user-pool-oauth-2-0-grants)

## Setup a Cognito Pool

### Best Practice Findings:
    * Create a pool per company project (e.g. ge-digital-wind-farm)
    * User pool can support multiple app clients (e.g. web, mobile, etc.)
    * App clients can use specific OAuth scopes to narrow down capabilities (e.g. CRUD)
    * Users can be added to groups that may represent personas (e.g. roc-operator, customer, etc.)

### Create a Pool
1. AWS Console -> Cognito -> Manage User Pools -> Create a user pool
2. Step through settings with defaults except for:
   - Name: ge-dwf
   - Sign in with: 'Email address or phone number' and 'Allow email addresses'
   - Required attributes: 'name'
   - Do you want to allow users to sign themselves up?: 'Only allow administrators to create users'
3. Create Pool

### Add Users and Groups
1. Users and groups -> Groups -> Create group
   - Names: ceo_customer asset_manager roc_operator site_manager site_tech
   - Use defaults for all other attributes
2. Users and groups -> Users -> Create user
   - Username: email  (e.g. brett@cruxdigital.net)
   - Uncheck 'Send an invitation to this new user?'
   - Temporary password: (e.g. Testtest123!!)
   - Uncheck 'Mark phone number as verified?'
   - Email: email (e.g. brett@cruxdigital.net)

### Optional: Identity Provider Integration
TODO: How does is affect users and groups

### Add App Clients
*Note: Create an app client for each UI, device, and any other programmatic access of the API*
1. General settings -> App clients -> Add an app client
   - App client name: web-app
   - Uncheck 'Generate client secret' unless the client will be a device or programatic access
2. Note the 'App client id' to be used later

### Setup App Client
1. App integration -> App client settings
   - Check identity providers 'Cognito User Pool' and any others that apply
   - Assign a Callback URL for the web app main page (e.g. https://dmigtk6hw77pj.cloudfront.net)
   - Select "Authorized code grant"
   - Select "Client credentials" if the client allows a device or programatic access
   - Select OAuth Scopes: email, openid
2. Note the 'Callback URL' to be used later

### Optional: OAuth Scopes Setup
*Note: OAuth scopes allow a client restricted access to certain API operations (e.g. CRUD)*
1. App integration -> Resource servers -> Add a resource server
   - Name: ge-dwf-api
   - Identifier: ge-dwf-api
   - Scope: ```Name: turbine.advanced_ops``` ```Description: Allow a user to perform turbine operations```
2. App integration -> App client settings
   - Select "Authorized code grant"
   - Select the applicable scopes under "Allowed OAuth Scopes"

### Login Portal Setup
1. App integration -> Domain name
   - Add a domain prefix to the URL for the auto generated login screen
   - Example: https://ge-dwf.auth.us-west-2.amazoncognito.com
2. App integration -> UI customization
   - Add a logo for the login screen

### Test the login
```
https://<your_domain>/login?response_type=code&client_id=<your_app_client_id>&redirect_uri=<your_callback_url>
```
Example:
https://ge-dwf.auth.us-west-2.amazoncognito.com/login?response_type=code&client_id=sp4to4c48ob84dgbts1vvouv5&redirect_uri=https://dmigtk6hw77pj.cloudfront.net

Result: You should be logged in and redirected to the specified url with a code param that can be used to retrieve tokens

### Retrieve the tokens using the returned login code
*Note: The callback URL in the previous example will return the tokens in the console*
```
https://<your_domain>/oauth2/token
Header - Content-Type: application/x-www-form-urlencoded
Body - grant_type=authorization_code&code=<your_code>&client_id=<your_app_client_id>&redirect_uri=<your_callback_url>
```

### Inspect the JWT tokens for scopes and other attributes using a [JWT decoder](https://jwt.io)
*Note: The token of interest is the ```id_token```*

### Optional: Test Secured API Gateway call
*Note: An API Endpoint must be set up in API Gateway with a cognito authorizor (See below)*
```
curl -v -X GET -H 'content-type: application/json' -H 'Authorization: <your_id_token>' '<your_api_url>'
```
```
curl -v -X GET -H 'content-type: application/json' -H 'Authorization: zzz' 'https://dklvyu9i8l.execute-api.us-west-2.amazonaws.com/prod/test'
```

### Optional: Test token retrieval for devices and programatic access
*Note: 'Generate client secret' under Add App Clients must be selected and 'Client credentials' under Setup App Client must be selected*
```
curl -X POST --user <app client id>:<app client secret> 'https://<your_domain>/oauth2/token?grant_type=client_credentials' -H 'Content-Type: application/x-www-form-urlencoded'
```

## Setup a Secure API

### Lambda Function Setup
[Simple Proxy Tutorial](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-create-api-as-simple-proxy-for-lambda.html)
1. Lambda -> Create function
   - Name: secure-api-handler-test
   - Node.js 10.x

### API Gateway Setup
1. API Gateway -> Create API
   - Protocol: REST
   - New API
   - Name: secure-api-test
   - Endpoint Type: Regional
2. Actions -> Create Resource
   - Configure as proxy resource unchecked
   - Name: test  ResourcePath /test
3. Actions -> Create Method
   - ANY (for proxy - function will handle get, post, etc.) (Select check mark)
   - Lambda Function: secure-api-handler-test
   - Use Lambda Proxy Integration: checked
4. Authorizers -> Create New Authorizer
   - Name: Cognito_Authorizer
   - Type: Cognito
   - Cognito User Pool: ge-dwf
   - Token Source: Authorization
5. Refresh whole page
6. Resources -> ANY -> Method Request
   - Authorization: Cognito_Authorizer (Select check mark)
   - Optional: select OAuth scopes if some were defined
7. Actions -> Deploy API (prod)
8. Select endpoint method under prod to determine URI

